# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tools-visual.spec.js >> V01 public recipes keep pulse opt-in, selection visible and reduced motion still
- Location: tests/browser/tools-visual.spec.js:77:1

# Error details

```
Test timeout of 15000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 15000ms exceeded.
Call log:
  - waiting for getByRole('region', { name: '公共配方检查' }).locator('.sy-row')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner "导航面板" [ref=e2]:
    - link "Agent-Alfred 本地助手" [ref=e3] [cursor=pointer]:
      - /url: /overview
      - text: Agent-Alfred
      - generic [ref=e4]: 本地助手
    - navigation "主导航" [ref=e5]:
      - paragraph [ref=e6]: 工作区
      - link "总览" [ref=e7] [cursor=pointer]:
        - /url: /overview
      - link "收件箱" [ref=e8] [cursor=pointer]:
        - /url: /inbox
      - link "运行" [ref=e9] [cursor=pointer]:
        - /url: /runs
      - link "记忆" [ref=e10] [cursor=pointer]:
        - /url: /memory
      - paragraph [ref=e11]: Agent 配置
      - link "模型" [ref=e12] [cursor=pointer]:
        - /url: /models
      - link "连接" [ref=e13] [cursor=pointer]:
        - /url: /connections
      - link "行为" [ref=e14] [cursor=pointer]:
        - /url: /behaviour
      - link "工具" [ref=e15] [cursor=pointer]:
        - /url: /tools
      - paragraph [ref=e16]: 诊断
      - link "用量账本" [ref=e17] [cursor=pointer]:
        - /url: /ops
      - link "数据库" [ref=e18] [cursor=pointer]:
        - /url: /database
    - paragraph [ref=e19]: 本地优先 · 共享运行宿主
  - generic [ref=e20]:
    - generic "壳层状态与操作" [ref=e21]:
      - button "打开主对话" [expanded] [ref=e22] [cursor=pointer]
      - region "运行与连接摘要" [ref=e23]:
        - paragraph [ref=e24]: 尚未选择会话
    - main [ref=e25]:
      - heading "工具" [active] [level=1] [ref=e26]
      - generic [ref=e27]:
        - paragraph [ref=e28]: 配置：ok · 保存版本 0 · 生效：applied
        - status [ref=e29]: 当前目录已核对；连接观测、保存与生效分别显示。
        - status
        - paragraph [ref=e30]: MCP 目录：未配置服务器
        - generic [ref=e31]:
          - button "核对当前授权" [ref=e32] [cursor=pointer]
          - button "重新应用已保存授权" [ref=e33] [cursor=pointer]
          - link "连接、凭据与 MCP 维护" [ref=e34] [cursor=pointer]:
            - /url: /connections
        - paragraph [ref=e35]: 从 MainBar 明确提出工具请求；本页查看来源、能力和授权。人格 read_persona / update_persona 保留完整版本、覆盖限制与冲突，修改从下一 Run 生效。
        - generic [ref=e36]:
          - region "内置工具" [ref=e37]:
            - heading "内置工具" [level=2] [ref=e38]
            - paragraph [ref=e39]: builtin
            - paragraph
            - generic [ref=e40]:
              - article [ref=e41]:
                - heading "create_event" [level=3] [ref=e42]
                - paragraph [ref=e43]: 来源 builtin · 能力 create_event
                - paragraph [ref=e44]: Create a local calendar entry; time requires UTC offset.
                - generic "工具状态摘要" [ref=e45]:
                  - paragraph [ref=e46]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e47]: 本地工具，不需要外部授权
                  - paragraph [ref=e48]: 授权：不适用
                  - paragraph [ref=e49]: 模型暴露：real
                  - paragraph [ref=e50]: 阻止原因：无已报告阻止原因
                - generic [ref=e51]:
                  - button "展开详情" [ref=e52] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e53] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22create_event%22%5D
              - article [ref=e54]:
                - heading "create_skill" [level=3] [ref=e55]
                - paragraph [ref=e56]: 来源 builtin · 能力 create_skill
                - paragraph [ref=e57]: Create a new user Skill; requires restart to load. Existing user names are protected; builtin overrides need user confirmation.
                - generic "工具状态摘要" [ref=e58]:
                  - paragraph [ref=e59]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e60]: 本地工具，不需要外部授权
                  - paragraph [ref=e61]: 授权：不适用
                  - paragraph [ref=e62]: 模型暴露：real
                  - paragraph [ref=e63]: 阻止原因：无已报告阻止原因
                - generic [ref=e64]:
                  - button "展开详情" [ref=e65] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e66] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22create_skill%22%5D
              - article [ref=e67]:
                - heading "delete_memory" [level=3] [ref=e68]
                - paragraph [ref=e69]: 来源 builtin · 能力 delete_memory
                - paragraph [ref=e70]: Delete one explicit memory ID and version.
                - generic "工具状态摘要" [ref=e71]:
                  - paragraph [ref=e72]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e73]: 本地工具，不需要外部授权
                  - paragraph [ref=e74]: 授权：不适用
                  - paragraph [ref=e75]: 模型暴露：real
                  - paragraph [ref=e76]: 阻止原因：无已报告阻止原因
                - generic [ref=e77]:
                  - button "展开详情" [ref=e78] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e79] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22delete_memory%22%5D
              - article [ref=e80]:
                - heading "draft_message" [level=3] [ref=e81]
                - paragraph [ref=e82]: 来源 builtin · 能力 draft_message
                - paragraph [ref=e83]: Create a local Markdown draft; never send it.
                - generic "工具状态摘要" [ref=e84]:
                  - paragraph [ref=e85]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e86]: 本地工具，不需要外部授权
                  - paragraph [ref=e87]: 授权：不适用
                  - paragraph [ref=e88]: 模型暴露：real
                  - paragraph [ref=e89]: 阻止原因：无已报告阻止原因
                - generic [ref=e90]:
                  - button "展开详情" [ref=e91] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e92] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22draft_message%22%5D
              - article [ref=e93]:
                - heading "get_memory" [level=3] [ref=e94]
                - paragraph [ref=e95]: 来源 builtin · 能力 get_memory
                - paragraph [ref=e96]: Read one memory and its current version.
                - generic "工具状态摘要" [ref=e97]:
                  - paragraph [ref=e98]: 副作用：local_read · 可用性：configured
                  - paragraph [ref=e99]: 本地工具，不需要外部授权
                  - paragraph [ref=e100]: 授权：不适用
                  - paragraph [ref=e101]: 模型暴露：real
                  - paragraph [ref=e102]: 阻止原因：无已报告阻止原因
                - generic [ref=e103]:
                  - button "展开详情" [ref=e104] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e105] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22get_memory%22%5D
              - article [ref=e106]:
                - heading "query_events" [level=3] [ref=e107]
                - paragraph [ref=e108]: 来源 builtin · 能力 query_events
                - paragraph [ref=e109]: Query local calendar entries by absolute time.
                - generic "工具状态摘要" [ref=e110]:
                  - paragraph [ref=e111]: 副作用：local_read · 可用性：configured
                  - paragraph [ref=e112]: 本地工具，不需要外部授权
                  - paragraph [ref=e113]: 授权：不适用
                  - paragraph [ref=e114]: 模型暴露：real
                  - paragraph [ref=e115]: 阻止原因：无已报告阻止原因
                - generic [ref=e116]:
                  - button "展开详情" [ref=e117] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e118] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22query_events%22%5D
              - article [ref=e119]:
                - heading "query_memory" [level=3] [ref=e120]
                - paragraph [ref=e121]: 来源 builtin · 能力 query_memory
                - paragraph [ref=e122]: Find explicit memory targets; clarify ambiguous matches.
                - generic "工具状态摘要" [ref=e123]:
                  - paragraph [ref=e124]: 副作用：local_read · 可用性：configured
                  - paragraph [ref=e125]: 本地工具，不需要外部授权
                  - paragraph [ref=e126]: 授权：不适用
                  - paragraph [ref=e127]: 模型暴露：real
                  - paragraph [ref=e128]: 阻止原因：无已报告阻止原因
                - generic [ref=e129]:
                  - button "展开详情" [ref=e130] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e131] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22query_memory%22%5D
              - article [ref=e132]:
                - heading "read_persona" [level=3] [ref=e133]
                - paragraph [ref=e134]: 来源 builtin · 能力 read_persona
                - paragraph [ref=e135]: Read the complete effective persona and its version.
                - generic "工具状态摘要" [ref=e136]:
                  - paragraph [ref=e137]: 副作用：local_read · 可用性：configured
                  - paragraph [ref=e138]: 本地工具，不需要外部授权
                  - paragraph [ref=e139]: 授权：不适用
                  - paragraph [ref=e140]: 模型暴露：real
                  - paragraph [ref=e141]: 阻止原因：无已报告阻止原因
                - generic [ref=e142]:
                  - button "展开详情" [ref=e143] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e144] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22read_persona%22%5D
              - article [ref=e145]:
                - heading "save_fact" [level=3] [ref=e146]
                - paragraph [ref=e147]: 来源 builtin · 能力 save_fact
                - paragraph [ref=e148]: Save a fact only when the user explicitly asks to save it.
                - generic "工具状态摘要" [ref=e149]:
                  - paragraph [ref=e150]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e151]: 本地工具，不需要外部授权
                  - paragraph [ref=e152]: 授权：不适用
                  - paragraph [ref=e153]: 模型暴露：real
                  - paragraph [ref=e154]: 阻止原因：无已报告阻止原因
                - generic [ref=e155]:
                  - button "展开详情" [ref=e156] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e157] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22save_fact%22%5D
              - article [ref=e158]:
                - heading "update_memory" [level=3] [ref=e159]
                - paragraph [ref=e160]: 来源 builtin · 能力 update_memory
                - paragraph [ref=e161]: Update one memory using its observed version.
                - generic "工具状态摘要" [ref=e162]:
                  - paragraph [ref=e163]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e164]: 本地工具，不需要外部授权
                  - paragraph [ref=e165]: 授权：不适用
                  - paragraph [ref=e166]: 模型暴露：real
                  - paragraph [ref=e167]: 阻止原因：无已报告阻止原因
                - generic [ref=e168]:
                  - button "展开详情" [ref=e169] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e170] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22update_memory%22%5D
              - article [ref=e171]:
                - heading "update_persona" [level=3] [ref=e172]
                - paragraph [ref=e173]: 来源 builtin · 能力 update_persona
                - paragraph [ref=e174]: Replace the managed persona using the read version. Preserve instructions the user did not ask to change. Next Run applies it.
                - generic "工具状态摘要" [ref=e175]:
                  - paragraph [ref=e176]: 副作用：local_write · 可用性：configured
                  - paragraph [ref=e177]: 本地工具，不需要外部授权
                  - paragraph [ref=e178]: 授权：不适用
                  - paragraph [ref=e179]: 模型暴露：real
                  - paragraph [ref=e180]: 阻止原因：无已报告阻止原因
                - generic [ref=e181]:
                  - button "展开详情" [ref=e182] [cursor=pointer]
                  - link "查看包含该工具的运行" [ref=e183] [cursor=pointer]:
                    - /url: /ops?tool=%5B%22builtin%22%2C%22update_persona%22%5D
          - region "集成 · tavily" [ref=e184]:
            - heading "集成 · tavily" [level=2] [ref=e185]
            - paragraph [ref=e186]: tavily
            - paragraph
            - article [ref=e188]:
              - heading "web_search" [level=3] [ref=e189]
              - paragraph [ref=e190]: 来源 tavily · 能力 web_search
              - paragraph [ref=e191]: 搜索网络并返回外部来源标题、链接与片段。
              - generic "工具状态摘要" [ref=e192]:
                - paragraph [ref=e193]: 副作用：external · 可用性：unconfigured
                - paragraph [ref=e194]: 连接观测：unconfigured
                - paragraph [ref=e195]: 已保存授权：unset · 实际应用：applied
                - paragraph [ref=e196]: 模型暴露：guidance
                - paragraph [ref=e197]: 阻止原因：configuration_required
              - generic [ref=e198]:
                - button "展开详情" [ref=e199] [cursor=pointer]
                - link "查看包含该工具的运行" [ref=e200] [cursor=pointer]:
                  - /url: /ops?tool=%5B%22tavily%22%2C%22web_search%22%5D
                - link "连接维护" [ref=e201] [cursor=pointer]:
                  - /url: /connections
  - region "MainBar" [ref=e202]:
    - generic [ref=e203]:
      - heading "主对话" [level=2] [ref=e204]
      - button "收起主对话" [ref=e205] [cursor=pointer]
    - generic [ref=e206]:
      - generic [ref=e207]: 尚未选择会话
      - button "新建会话" [ref=e208] [cursor=pointer]
    - region "主对话" [ref=e209]
    - generic [ref=e210]:
      - generic [ref=e211]: 消息
      - textbox "消息" [disabled] [ref=e212]:
        - /placeholder: 写下消息；/skills 指定流程…
      - button "发送" [disabled] [ref=e213]
    - paragraph [ref=e214]: 请显式新建或继续会话。
  - status [ref=e215]: 就绪
  - alert [ref=e216]
```

# Test source

```ts
  2   | import {memoryServer} from './memory-server.js';
  3   | import {writeFile} from 'node:fs/promises';
  4   | 
  5   | test('S07 four viewports, shell and measured central boundaries retain full text and keyboard controls',async({browser},info)=>{
  6   |   test.setTimeout(45000);
  7   |   const server=await memoryServer({script:'tests/browser/tools_server.py'}),observations=[];
  8   |   try {
  9   |     for(const [width,height] of [[1440,900],[1280,800],[390,844],[320,800]]) {
  10  |       const context=await browser.newContext({viewport:{width,height},hasTouch:width<1100,deviceScaleFactor:1,reducedMotion:'no-preference'});
  11  |       try {
  12  |         const page=await context.newPage(),failed=[];
  13  |         page.on('requestfailed',request=>failed.push(request.url()));
  14  |         await page.goto(server.origin+'/tools');
  15  |         await expect(page.getByText('当前目录已核对；连接观测、保存与生效分别显示。')).toBeVisible();
  16  |         await page.screenshot({path:info.outputPath(`tools-normal-${width}.png`)});
  17  |         const integration=page.getByRole('region',{name:'集成 · tavily',exact:true});
  18  |         await expect(integration).toContainText('web_search');
  19  |         const row=integration.locator('article');
  20  |         const toggle=row.getByRole('button',{name:'展开详情',exact:true});
  21  |         await toggle.focus();await page.keyboard.press('Enter');
  22  |         await row.getByRole('combobox').selectOption('allowed');
  23  |         await row.getByRole('button',{name:'收起详情',exact:true}).click();
  24  |         await expect(row.getByLabel('工具状态摘要')).toContainText('未保存草稿：allowed');
  25  |         await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  26  |         await page.locator('#mainbar-title').focus();await page.keyboard.press('Escape');
  27  |         await expect(row.getByLabel('工具状态摘要')).toContainText('未保存草稿：allowed');
  28  |         const long=page.locator('article').filter({has:page.getByRole('heading',{name:'read_persona_looks_builtin',exact:true})});
  29  |         await expect(page.getByRole('region',{name:'内置工具',exact:true}).getByRole('heading',{name:'read_persona_looks_builtin',exact:true})).toHaveCount(0);
  30  |         await long.getByRole('button',{name:'展开详情',exact:true}).click();
  31  |         await expect(long.locator('.tool-description')).toContainText('完整描述结束标识。');
  32  |         await expect(long.locator('.tool-detail .tool-identity')).toContainText('同名前缀'.repeat(40));
  33  |         await long.getByRole('button',{name:'收起详情',exact:true}).focus();
  34  |         await page.screenshot({path:info.outputPath(`tools-long-draft-${width}.png`)});
  35  |         const metrics=await page.evaluate(()=>({
  36  |           viewport:[innerWidth,innerHeight],touch:navigator.maxTouchPoints,bodyOverflow:document.documentElement.scrollWidth-innerWidth,
  37  |           central:document.querySelector('.page-body').getBoundingClientRect().width,
  38  |           focusOutline:getComputedStyle(document.activeElement).outlineWidth,
  39  |           fonts:Object.fromEntries([['name','.tool-row h3'],['identity','.tool-identity'],['body','.tool-description'],['button','.tool-row button']].map(([role,selector])=>[role,getComputedStyle(document.querySelector(selector)).fontSize])),
  40  |           color:getComputedStyle(document.querySelector('.tools-page')).color,background:getComputedStyle(document.body).backgroundColor,
  41  |           transitions:[...document.querySelectorAll('.tools-page *')].flatMap(n=>[null,'::before','::after'].map(pseudo=>getComputedStyle(n,pseudo))).filter(style=>style.transitionDuration!=='0s').map(style=>({duration:style.transitionDuration,property:style.transitionProperty})),
  42  |         }));
  43  |         expect(metrics.bodyOverflow).toBeLessThanOrEqual(0);
  44  |         expect(metrics.fonts).toEqual({name:'12.5px',identity:'11px',body:'13px',button:'11.5px'});
  45  |         for(const transition of metrics.transitions){expect(transition.property).toBe('opacity');expect(Number.parseFloat(transition.duration)).toBeLessThanOrEqual(.18);}
  46  |         expect(metrics.focusOutline).toBe('3px');expect(failed).toEqual([]);
  47  |         observations.push(metrics);
  48  |       }finally{await context.close();}
  49  |     }
  50  |     const context=await browser.newContext({viewport:{width:1440,height:900}});
  51  |     try {
  52  |       const page=await context.newPage();await page.goto(server.origin+'/tools');
  53  |       await expect(page.getByRole('region',{name:'内置工具',exact:true})).toBeVisible();
  54  |       for(const width of [1099,1100]) {
  55  |         await page.setViewportSize({width,height:900});
  56  |         await expect.poll(()=>page.locator('.site-header').evaluate(n=>n.getBoundingClientRect().width)).toBe(width===1100?232:0);
  57  |         const geometry=await page.evaluate(()=>({viewport:innerWidth,nav:document.querySelector('.site-header').getBoundingClientRect().width,mainbar:document.querySelector('#mainbar').getBoundingClientRect().width,central:document.querySelector('.page-body').getBoundingClientRect().width}));
  58  |         if(width===1100){expect(geometry.nav).toBe(232);expect(geometry.mainbar).toBe(320);}
  59  |         await page.screenshot({path:info.outputPath(`tools-shell-${width}.png`)});observations.push(geometry);
  60  |       }
  61  |       await page.setViewportSize({width:1440,height:900});
  62  |       for(const target of [679,680]) {
  63  |         const current=await page.locator('.page-body').boundingBox();
  64  |         await page.setViewportSize({width:page.viewportSize().width+target-current.width,height:900});
  65  |         const measured=await page.locator('.page-body').boundingBox();expect(measured.width).toBe(target);
  66  |         const columns=await page.locator('.tool-status').first().evaluate(n=>getComputedStyle(n).gridTemplateColumns.split(' ').length);
  67  |         expect(columns).toBe(target===679?1:2);
  68  |         await page.screenshot({path:info.outputPath(`tools-central-${target}.png`)});observations.push({central:measured.width,viewport:page.viewportSize(),columns});
  69  |       }
  70  |     } finally {await context.close();}
  71  |     const evidence=JSON.stringify({browser:browser.version(),observations,native_zoom:'NOT RUN — coordinator',native_ime:'NOT RUN — coordinator',mobile:'Chromium viewport/touch simulation only',bfcache:'historical BLOCKED preserved'},null,2);
  72  |     await writeFile(info.outputPath('geometry-fonts-and-scope.json'),evidence);
  73  |     await info.attach('geometry-fonts-and-scope',{body:evidence,contentType:'application/json'});
  74  |   } finally {await server.close();}
  75  | });
  76  | 
  77  | test('V01 public recipes keep pulse opt-in, selection visible and reduced motion still',async({page})=>{
  78  |   await page.emulateMedia({reducedMotion:'no-preference'});
  79  |   await page.goto('/tools');
  80  |   // A consumer fixture exercises public CSS without binding production state.
  81  |   await page.locator('#page').evaluate(host=>{
  82  |     const fixture=document.createElement('section');fixture.setAttribute('aria-label','公共配方检查');fixture.className='sy-panel';
  83  |     fixture.innerHTML=`<header class="sy-panel-header"><h2 class="sy-panel-eyebrow">公共配方</h2></header>
  84  |       <div class="sy-panel-body">
  85  |         <span class="sy-status-dot sy-tone-success sy-pulse" aria-hidden="true" data-dot="pulsing"></span><span>已连接（测试事实）</span>
  86  |         <span class="sy-status-dot" aria-hidden="true" data-dot="static"></span><span>未知（测试事实）</span>
  87  |         <p class="sy-tone-error">失败（测试事实）</p>
  88  |         <button class="sy-tab" aria-pressed="false">查看测试类别</button>
  89  |         <div class="sy-row" data-selected="false"><span class="sy-row-content">运行摘要（测试事实）</span><span class="sy-row-meta">回复完成 · 未保存</span></div>
  90  |       </div>`;
  91  |     host.replaceChildren(fixture);
  92  |   });
  93  |   const fixture=page.getByRole('region',{name:'公共配方检查'}),tab=fixture.getByRole('button',{name:'查看测试类别'}),row=fixture.locator('.sy-row');
  94  |   const styles=()=>fixture.evaluate(host=>{
  95  |     const dot=getComputedStyle(host.querySelector('[data-dot=pulsing]')),staticDot=getComputedStyle(host.querySelector('[data-dot=static]'));
  96  |     const selected=['.sy-tab','.sy-row'].map(selector=>{const style=getComputedStyle(host.querySelector(selector),'::before');return {opacity:style.opacity,property:style.transitionProperty,duration:style.transitionDuration};});
  97  |     return {pulse:{name:dot.animationName,duration:dot.animationDuration,repeat:dot.animationIterationCount},static:staticDot.animationName,selected};
  98  |   });
  99  |   const normal=await styles();
  100 |   expect(normal.pulse).toEqual({name:'sy-pulse',duration:'1.4s',repeat:'infinite'});expect(normal.static).toBe('none');
  101 |   expect(normal.selected).toEqual([{opacity:'0',property:'opacity',duration:'0.18s'},{opacity:'0',property:'opacity',duration:'0.18s'}]);
> 102 |   await tab.evaluate(node=>node.setAttribute('aria-pressed','true'));await row.evaluate(node=>node.dataset.selected='true');
      |                                                                                ^ Error: locator.evaluate: Test timeout of 15000ms exceeded.
  103 |   await expect.poll(async()=>{const measured=await styles();return measured.selected.map(style=>style.opacity);}).toEqual(['1','1']);
  104 |   await tab.focus();expect(await tab.evaluate(node=>getComputedStyle(node).outlineWidth)).toBe('3px');
  105 |   await expect(fixture.getByText('回复完成 · 未保存',{exact:true})).toBeVisible();
  106 |   expect(await fixture.locator('.sy-tone-error').evaluate(node=>getComputedStyle(node).color)).toBe('rgb(255, 143, 155)');
  107 |   await page.emulateMedia({reducedMotion:'reduce'});
  108 |   const reduced=await styles();expect(reduced.pulse.name).toBe('none');expect(reduced.static).toBe('none');
  109 |   expect(reduced.selected.map(style=>({opacity:style.opacity,duration:style.duration}))).toEqual([{opacity:'1',duration:'0s'},{opacity:'1',duration:'0s'}]);
  110 |   expect(await fixture.evaluate(host=>host.getAnimations({subtree:true}).length)).toBe(0);
  111 |   await expect(fixture.getByText('已连接（测试事实）',{exact:true})).toBeVisible();
  112 | });
  113 | 
```