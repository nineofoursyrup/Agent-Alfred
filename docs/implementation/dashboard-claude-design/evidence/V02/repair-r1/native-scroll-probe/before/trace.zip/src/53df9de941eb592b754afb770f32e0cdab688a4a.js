import {readFileSync} from 'node:fs';
import {test,expect} from '@playwright/test';
import {memoryServer} from './memory-server.js';

async function observeStream(page) {
  await page.addInitScript(()=>{
    const Native=window.EventSource;window.sessionActionStreams=[];
    window.EventSource=class extends Native {
      constructor(url){super(url);window.sessionActionStreams.push(this);}
    };
  });
}
async function selected(page) {
  return page.evaluate(()=>sessionStorage.getItem('alfred.session'));
}
async function runtime(page) {
  return page.evaluate(async()=>(await import('/assets/app.js')).dashboard.runtime());
}
async function setup(page,origin) {
  await observeStream(page);await page.goto(origin+'/inbox');
  const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/sessions'&&r.request().method()==='POST');
  await page.getByRole('button',{name:'新建会话',exact:true}).click();
  expect((await response).status()).toBe(201);
  await expect(page.getByRole('textbox',{name:'消息',exact:true})).toBeEnabled();
  await expect.poll(async()=>(await runtime(page)).connected).toBe(true);
  return selected(page);
}
// Hold only a genuine successful HTTP receipt. The creation, Session identity,
// Host state and later recording are always produced by the real service.
async function holdCreate(page) {
  let release,received,delivered;
  const gate=new Promise(resolve=>release=resolve),ready=new Promise(resolve=>received=resolve),done=new Promise(resolve=>delivered=resolve);
  let body;
  await page.route('**/api/sessions',async route=>{
    const response=await route.fetch();expect(response.status()).toBe(201);
    body=await response.json();received();await gate;
    await route.fulfill({response}).catch(()=>{});delivered();
  },{times:1});
  return {ready,get body(){return body;},async release(){release();await done;}};
}
async function oneStream(page) {
  expect(await page.evaluate(()=>window.sessionActionStreams.filter(source=>source.readyState!==EventSource.CLOSED).length)).toBe(1);
}

for(const viewport of [{width:1440,height:360}])test(`V02 native scroll completion probe at ${viewport.width}x${viewport.height}`,async({page},testInfo)=>{
  const server=await memoryServer({script:'tests/browser/overview_server.py'});let held;
  try {
    if(process.env.V02_PROBE_CSS==='before')await page.route('**/assets/app.css',route=>route.fulfill({contentType:'text/css',body:readFileSync('.scratch/v02-review-repair-01/src/agent_alfred/ops/static/app.css','utf8')}));
    await page.setViewportSize(viewport);await observeStream(page);await page.goto(server.origin+'/inbox');
    if(viewport.width<1100)await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    await page.getByRole('button',{name:'新建会话',exact:true}).click();
    const input=page.getByRole('textbox',{name:'消息',exact:true}),send=page.getByRole('button',{name:'发送',exact:true});
    await expect(input).toBeEnabled();await expect.poll(async()=>(await runtime(page)).connected).toBe(true);
    const a=await selected(page);await page.getByRole('button',{name:'刷新会话',exact:true}).click();await expect(page.locator('.inbox-rows article').first()).toBeVisible();await input.fill('原会话草稿');
    const posts=[];page.on('request',request=>{if(request.method()==='POST')posts.push(new URL(request.url()).pathname);});
    held=await holdCreate(page);await page.getByRole('button',{name:'新建会话',exact:true}).click();await held.ready;
    await input.fill('201 回执等待期间输入的新草稿');await input.evaluate(element=>element.setSelectionRange(2,8));
    await expect(input).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});
    const b=held.body.session_id;await held.release();
    const receipt=page.getByRole('region',{name:'新建会话回执',exact:true});await expect(receipt).toContainText(b);await expect(receipt).toContainText('已有新的页面或阅读意图');
    await expect(input).toBeFocused();expect(await input.evaluate(element=>[element.selectionStart,element.selectionEnd])).toEqual([2,8]);
    await expect(input).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});
    await expect(input).toHaveValue('201 回执等待期间输入的新草稿');expect(await selected(page)).toBe(a);
    await expect(send).toBeEnabled();await expect(page.getByRole('button',{name:'收起主对话',exact:true})).toBeInViewport({ratio:1});
    await page.screenshot({path:testInfo.outputPath('receipt-before-scroll.png')});
    const status=page.locator('#shell-status'),open=receipt.getByRole('button',{name:'打开已创建会话',exact:true}),inspect=receipt.getByRole('link',{name:'查看已创建会话',exact:true});
    await expect(page.locator('.inbox-rows article').first()).toBeVisible();
    await page.evaluate(()=>{window.v02FirstScroll=new Promise(resolve=>{for(const id of ['page','shell-status'])document.getElementById(id).addEventListener('scroll',()=>resolve(id),{once:true});});});
    const statusBox=await status.boundingBox();await page.mouse.move(statusBox.x+statusBox.width/2,statusBox.y+statusBox.height/2);await page.mouse.wheel(0,1200);
    const scroller=await page.evaluate(async()=>{const id=await window.v02FirstScroll;await new Promise(requestAnimationFrame);await new Promise(requestAnimationFrame);return id;});
    const observation=await page.evaluate(()=>Object.fromEntries(['page','shell-status'].map(id=>{const n=document.getElementById(id);return [id,{clientHeight:n.clientHeight,scrollHeight:n.scrollHeight,scrollTop:n.scrollTop}];})));
    console.log('v02-native-scroll',JSON.stringify({scroller,observation}));
    await testInfo.attach('native-scroll-observation',{body:JSON.stringify({scroller,observation},null,2),contentType:'application/json'});
    await page.screenshot({path:testInfo.outputPath('receipt-after-native-scroll.png')});
    await expect(open).toBeInViewport({ratio:1});await expect(inspect).toBeInViewport({ratio:1});
    await expect(input).toBeFocused();expect(await input.evaluate(element=>[element.selectionStart,element.selectionEnd])).toEqual([2,8]);
    await page.screenshot({path:testInfo.outputPath('receipt-after-wheel.png')});
    // Reach Send and receipt actions with real keyboard input; no focus repair.
    await page.keyboard.press('Tab');await expect(send).toBeFocused();await expect(send).toBeInViewport({ratio:1});
    await send.click({trial:true});
    for(let step=0;step<12&&!(await inspect.evaluate(element=>element===document.activeElement));step++)await page.keyboard.press('Shift+Tab');
    await expect(inspect).toBeFocused();await expect(inspect).toBeInViewport({ratio:1});
    await page.keyboard.press('Shift+Tab');await expect(open).toBeFocused();await expect(open).toBeInViewport({ratio:1});
    await page.getByRole('button',{name:'收起主对话',exact:true}).click();await expect(page.locator('#mainbar')).toBeHidden();
    if(viewport.width<1100){await page.locator('#shell-toolbar [data-open-panel="navigation"]').click();await expect(page.getByRole('navigation',{name:'主导航',exact:true}).getByRole('link',{name:'收件箱',exact:true})).toBeInViewport({ratio:1});}
    expect(posts).toEqual(['/api/sessions']);await oneStream(page);
  } finally {if(held)await held.release();await server.close();}
});

