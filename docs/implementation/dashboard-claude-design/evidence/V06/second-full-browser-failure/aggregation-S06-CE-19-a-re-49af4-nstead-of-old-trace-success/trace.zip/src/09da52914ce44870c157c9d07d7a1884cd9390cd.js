import {observeTopology} from './topology-observation.js';
import {test, expect} from '@playwright/test';
import {memoryServer, api} from './memory-server.js';

test('aggregation CE-02/04/14: Behaviour to same Session, refresh and restart', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/routing_server.py'});
  try {
    await page.goto(server.origin + '/behaviour');
    await page.getByRole('button',{name:'新建会话',exact:true}).click();
    await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    await page.getByRole('textbox',{name:'消息',exact:true}).fill('hello history');
    await page.getByRole('button',{name:'发送',exact:true}).click();
    await expect(page.locator('#messages').getByText('离线路由回复')).toBeVisible();
    await page.getByRole('button',{name:'刷新会话',exact:true}).click();
    const session = await page.evaluate(() => sessionStorage.getItem('alfred.session'));
    await page.getByRole('combobox',{name:'目标会话'}).selectOption(session);
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('整理本会话');
    await page.getByRole('textbox',{name:'聚合关键词',exact:true}).fill('hello');
    await page.getByRole('checkbox',{name:'语义记忆',exact:true}).uncheck();
    await page.getByRole('checkbox',{name:'情景记忆',exact:true}).uncheck();
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿'})).toBeVisible();
    await expect(page.locator('#messages').getByText('会话窗口 H1',{exact:true})).toBeVisible();
    await page.reload();
    await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿'})).toBeVisible();
    await server.restart();
    await page.reload();
    await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿'})).toBeVisible();
    const form = page.getByRole('region',{name:'手动聚合'});
    await form.getByRole('combobox',{name:'目标会话'}).selectOption(session);
    await form.getByRole('textbox',{name:'聚合目标',exact:true}).fill('无来源');
    for (const name of ['语义记忆','情景记忆','会话窗口']) await form.getByRole('checkbox',{name,exact:true}).uncheck();
    await form.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.locator('#messages').getByText('未选择来源',{exact:true})).toBeVisible();
    const other = await api(page.request,server.origin);
    const runs = await other.get('/api/runs?filter=chat&limit=25');
    expect(runs.body.runs.filter(r => r.purpose === 'aggregation')).toHaveLength(2);
  } finally { await server.close(); }
});

async function acceptedRun(response, payload) {
  const body = await response.json();
  expect(response.status(), JSON.stringify({body, payload})).toBe(202);
  expect(body).toMatchObject({run_id:expect.any(String), session_id:expect.any(String)});
  return body;
}

async function prepareDraft(page, server, beforeCreate = async () => {}) {
  await page.goto(server.origin + '/behaviour');
  const other = await api(page.request, server.origin);
  const saved = await other.command({operation_id:'seed',kind:'semantic',action:'save',payload:{subject:'me',fact:'coffee source'}});
  expect(saved.status).toBe(200);
  await beforeCreate();
  const created = page.waitForResponse(r => r.url().endsWith('/api/sessions') && r.request().method() === 'POST');
  await page.getByRole('button',{name:'新建会话',exact:true}).click();
  const response = await created;
  const body = await response.json();
  expect(response.status(), JSON.stringify(body)).toBe(201);
  expect(body.session_id).toEqual(expect.any(String));
  const session = body.session_id;
  await expect.poll(() => page.evaluate(() => sessionStorage.getItem('alfred.session'))).toBe(session);
  await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  await page.getByRole('button',{name:'刷新会话',exact:true}).click();
  await page.getByRole('combobox',{name:'目标会话'}).selectOption(session);
  await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('draft goal');
  await page.getByRole('textbox',{name:'聚合关键词',exact:true}).fill('coffee');
  await page.getByRole('checkbox',{name:'情景记忆',exact:true}).uncheck();
  await page.getByRole('checkbox',{name:'会话窗口',exact:true}).uncheck();
  return {other, session, memoryId:saved.body.result.memory_id};
}

test('S06 CE-18/19: a fresh form never adopts another aggregation terminal projection', async ({page},testInfo) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    await prepareDraft(page,server);
    await server.send('fail-recording');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.getByText('草稿未保存，请查看运行记录状态。',{exact:true})).toBeVisible();
    await page.getByText('草稿未保存，请查看运行记录状态。',{exact:true}).scrollIntoViewIfNeeded();await page.screenshot({path:testInfo.outputPath('aggregation-recording-failed.png')});
    await page.reload();
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    const form = page.getByRole('region',{name:'手动聚合',exact:true});
    await expect(form.getByText('尚未提交聚合请求。',{exact:true})).toBeVisible();
    await expect(form.getByRole('heading',{name:'聚合草稿',exact:true})).toHaveCount(0);
    await expect(form.getByRole('button',{name:'语义记忆 S1',exact:true})).toHaveCount(0);
  } finally {await server.close();}
});

test('aggregation CE-08/11: candidate hidden, recording pending busy and failed recovery', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {other, session} = await prepareDraft(page,server);
    await server.send('hold-model');
    await server.send('hold-recording');
    await server.send('fail-recording');
    const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const response = await accepted;
    expect(response.status()).toBe(202);
    const {run_id} = await response.json();
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeDisabled();
    await expect(page.locator('#messages')).not.toContainText('不得展示的候选流');
    await observeTopology(page); // #75 CE-07: real model is still held.
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeDisabled();
    const mutation = await other.command({operation_id:'busy',kind:'semantic',action:'save',payload:{subject:'x',fact:'y'}});
    expect(mutation.status).toBe(409);
    await server.send('release-model');
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    await observeTopology(page); // #75 CE-07: real recording is still held.
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeDisabled();
    const {csrf_token} = await (await page.request.get(server.origin+'/api/entry')).json();
    const again = await page.request.post(server.origin+'/api/runs',{headers:{'x-agent-alfred-csrf':csrf_token},data:{purpose:'aggregation',session_id:session,message:'again',keywords:'coffee',sources:['semantic']}});
    expect(again.status()).toBe(409);
    await server.send('release-recording');
    await expect(page.getByText('草稿未保存，请查看运行记录状态。')).toBeVisible();
    await page.reload();
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿'})).toBeVisible();
    await server.send('repair-recording');
    await server.restart();
    await page.reload();
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toHaveCount(0);
    const runs = await (await api(page.request,server.origin)).get('/api/runs?filter=chat&limit=25');
    expect(runs.body.runs.find(r => r.run_id === run_id).outcome).toBe('interrupted');
  } finally { await server.close(); }
});

test('aggregation CE-08: dropped accepted response does not resubmit or move Session', async ({page}) => {
  await page.clock.install();
  await page.clock.pauseAt(new Date());
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {session} = await prepareDraft(page,server);
    await page.getByRole('button',{name:'新建会话',exact:true}).click();
    await expect.poll(() => page.evaluate(() => sessionStorage.getItem('alfred.session'))).not.toBe(session);
    const second = await page.evaluate(() => sessionStorage.getItem('alfred.session'));
    expect(second).not.toBe(session);
    // Keep admission uncertainty observable before a real terminal projection
    // legitimately advances MainBar to recording_pending.
    await server.send('hold-model');
    await server.send('hold-recording');
    await page.clock.runFor(701); // Observe the real connected/idle state before submit.
    let sent = 0;
    let accepted;
    await page.route('**/api/runs', async route => {
      if (route.request().method() !== 'POST') return route.continue();
      sent++;
      const response = await route.fetch();
      accepted = await acceptedRun(response, route.request().postDataJSON());
      await route.abort();
    });
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.getByText(/准入未确认；请查看已有运行/)).toBeVisible();
    const draft=page.getByRole('region',{name:'手动聚合',exact:true}).locator('.behaviour-draft');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('unknown successor');
    await expect(draft).toHaveAttribute('data-dirty','true');
    await page.getByRole('link',{name:'运行',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByRole('button',{name:'留在此页',exact:true}).click();
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('draft goal');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await server.send('wait-stream');
    expect(accepted.session_id).toBe(session);
    expect(sent).toBe(1);
    expect(await page.evaluate(() => sessionStorage.getItem('alfred.session'))).toBe(second);
    await expect(page.getByRole('combobox',{name:'目标会话'})).toHaveValue(session);
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeDisabled();
    await server.send('release-model');
    await expect(page.getByRole('region',{name:'当前运行'}).getByRole('link',{name:'查看当前运行'})).toHaveAttribute('href',new RegExp(`/runs/${accepted.run_id}\\?`));
    expect(await page.evaluate(() => sessionStorage.getItem('alfred.session'))).toBe(second);
    // CI-01 / #75 CE-07: let the real recording projection arrive, then
    // deterministically execute the form's next observation poll.
    await expect(page.getByRole('region',{name:'当前运行',exact:true})).toContainText('正在保存');
    await page.clock.runFor(701);
    await expect(page.getByText(/准入未确认；请查看已有运行/)).toBeVisible();
    await observeTopology(page); // #75 CE-07: accepted 202 was lost; same request.
    await page.clock.runFor(1401);
    await expect(page.getByText(/准入未确认；请查看已有运行/)).toBeVisible();
    await expect(page.getByRole('link',{name:'查看已有运行',exact:true})).toBeVisible();
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeDisabled();
    expect(sent).toBe(1);
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toHaveCount(0);
    await page.reload();
    expect(await page.evaluate(() => sessionStorage.getItem('alfred.session'))).toBe(second);
    const other = await api(page.request,server.origin);
    const pending = await other.get('/api/runs?filter=chat&limit=25');
    expect(pending.status, JSON.stringify(pending)).toBe(200);
    expect(pending.body.non_terminal).toMatchObject({run_id:accepted.run_id, session_id:session});
    expect(pending.body.runs.some(r => r.run_id === accepted.run_id)).toBe(false);
    await server.send('release-recording');
    let runs;
    await expect.poll(async () => {
      runs = await other.get('/api/runs?filter=chat&limit=25');
      expect(runs.status, JSON.stringify(runs)).toBe(200);
      return runs.body.runs.find(r => r.run_id === accepted.run_id);
    }).toMatchObject({run_id:accepted.run_id, phase:'finished', outcome:'completed'});
    const drafts = runs.body.runs.filter(r => r.purpose === 'aggregation');
    expect(drafts).toHaveLength(1);
    expect(drafts[0].run_id).toBe(accepted.run_id);
    expect(drafts[0].session_id).toBe(session);
    expect(sent).toBe(1);
  } finally { await server.close(); }
});


test('aggregation CE-11: invalid streamed candidate never becomes a draft', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {other} = await prepareDraft(page,server);
    await server.send('invalid-model');
    await server.send('hold-model');
    const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const {run_id} = await acceptedRun(await accepted);
    await expect(page.locator('#messages')).not.toContainText('不得展示的候选流');
    await server.send('release-model');
    await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+run_id)).body.memory?.aggregation?.error).toBe('invalid_draft_reference');
    await page.reload();
    await expect(page.locator('#messages')).not.toContainText('无效候选');
    await expect(page.locator('#messages')).not.toContainText('不得展示的候选流');
    await page.screenshot({path:'tmp/agent-work/issue-27/behaviour.png',fullPage:true});
  } finally { await server.close(); }
});


test('aggregation CE-12: real HTTP forgetting keeps draft and disables source', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {other, memoryId} = await prepareDraft(page,server);
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeEnabled();
    const gone = await other.command({operation_id:'delete-source',kind:'semantic',action:'delete',expected_version:1,payload:{id:memoryId}});
    expect(gone.status).toBe(200);
    expect(gone.body.result.status).toBe('deleted');
    expect(gone.body.forgetting.state).toBe('complete');
    await page.reload();
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    await expect(page.locator('#messages').getByText('语义记忆 S1 · 不可用',{exact:true})).toBeVisible();
    await expect(page.locator('#messages')).not.toContainText('coffee source');
  } finally { await server.close(); }
});

test('S06/S03: retiring Behaviour and Run owners clears their opened aggregation source',async({page})=>{
  const server=await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {other}=await prepareDraft(page,server);
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const form=page.getByRole('region',{name:'手动聚合',exact:true});
    await expect(form.getByText('本次聚合已结束；草稿请在目标会话查看。',{exact:true})).toBeVisible();
    await form.getByRole('button',{name:'语义记忆 S1',exact:true}).click();
    await expect(form.getByText('coffee source',{exact:true})).toBeVisible();
    const formSource=await form.getByText('coffee source',{exact:true}).elementHandle();
    await form.getByRole('link',{name:'查看同一运行与资料',exact:true}).click();
    await expect(page).toHaveURL(/\/runs\//);
    expect(await formSource.evaluate(element=>({connected:element.isConnected,text:element.textContent}))).toEqual({connected:false,text:''});
    const detail=page.getByRole('region',{name:'运行过程',exact:true});
    await detail.getByRole('button',{name:'语义记忆 S1',exact:true}).click();
    await expect(detail.getByText('coffee source',{exact:true})).toBeVisible();
    const runSource=await detail.getByText('coffee source',{exact:true}).elementHandle();
    await page.getByRole('link',{name:'行为',exact:true}).click();await expect(page).toHaveURL(/\/behaviour$/);
    expect(await runSource.evaluate(element=>({connected:element.isConnected,text:element.textContent}))).toEqual({connected:false,text:''});
    await expect(page.getByRole('region',{name:'手动聚合',exact:true}).getByText('尚未提交聚合请求。',{exact:true})).toBeVisible();
    expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(item=>item.purpose==='aggregation')).toHaveLength(1);
  }finally{await server.close();}
});


test('aggregation CE-14: every source combination through Behaviour', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/routing_server.py'});
  try {
    const {other} = await prepareDraft(page,server);
    const episode = await other.command({operation_id:'episode',kind:'episodic',action:'save',payload:{summary:'coffee episode',occurred_at:'2026-09-14T10:00:00+08:00',occurred_until:null}});
    expect(episode.status).toBe(200);
    await page.getByRole('textbox',{name:'消息',exact:true}).fill('history coffee');
    await page.getByRole('button',{name:'发送',exact:true}).click();
    await expect(page.locator('#messages').getByText('离线路由回复')).toBeVisible();
    const names = ['语义记忆','情景记忆','会话窗口'];
    for (let bits=1;bits<8;bits++) {
      await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeEnabled();
      for (let i=0;i<3;i++) await page.getByRole('checkbox',{name:names[i],exact:true}).setChecked(Boolean(bits & (1<<i)));
      const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
      await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
      const {run_id} = await acceptedRun(await accepted);
      await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+run_id)).body.memory?.aggregation?.graph_result).toBe('Completed');
      const facts = (await other.get('/api/run-evidence?run_id='+run_id)).body.memory.aggregation;
      expect(facts.provided).toHaveLength(names.filter((_,i)=>bits & (1<<i)).length);
      expect(facts.steps).toHaveLength(1);
    }
    await page.screenshot({path:'tmp/agent-work/issue-27/aggregation-combinations.png',fullPage:true});
  } finally { await server.close(); }
});

for (const surface of ['mainbar','behaviour','runs']) for (const timing of ['opened','late']) {
  test(`STD-01/SPEC-01: ${surface} clears offline sources and ${timing} reads on delete`, async ({page}) => {
    const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
    let release = () => {};
    let releaseVerification = () => {};
    try {
      const {other,memoryId} = await prepareDraft(page,server);
      const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
      await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
      const {run_id} = await acceptedRun(await accepted);
      await expect(page.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeEnabled();
      let verificationState;
      let verificationArrived;
      if (surface === 'runs') {
        // A new page may render historical references before MemorySync has
        // verified the live revision. Hold the real response at that boundary.
        const verification = new Promise(resolve => {releaseVerification=resolve;});
        let observed;
        verificationArrived = new Promise(resolve => {observed=resolve;});
        await page.route('**/api/memory/state',async route=>{
          const response=await route.fetch();
          expect(response.status()).toBe(200);
          verificationState=await response.json();
          expect(verificationState).toMatchObject({
            process_instance_id:expect.any(String),memory_revision:expect.any(Number),
          });
          observed();await verification;await route.fulfill({response});
        });
        await page.goto(server.origin+'/runs/'+run_id);
      }
      const area = surface === 'mainbar' ? page.locator('#messages') : surface === 'behaviour' ? page.getByRole('region',{name:'手动聚合',exact:true}) : page.getByRole('region',{name:'运行过程',exact:true});
      if (surface !== 'mainbar') {
        const collapse=page.getByRole('button',{name:'收起主对话',exact:true});
        if (await collapse.isVisible()) await collapse.click();
      }
      const source = area.getByRole('button',{name:'语义记忆 S1',exact:true});
      let reads=0;
      page.on('request',request=>{
        if (request.url().includes('/api/memory/record?')) reads++;
      });
      if (surface === 'runs') {
        await verificationArrived;
        await source.click();
        await expect(area.getByText('离线或无法核验，原资料已隐藏。',{exact:true})).toBeVisible();
        await expect(area.getByText('coffee source',{exact:true})).toHaveCount(0);
        expect(reads).toBe(0);
        releaseVerification();
        await expect(area.getByText('资料已变化，请重新查看。',{exact:true})).toBeVisible();
        await page.unroute('**/api/memory/state');
      }
      const firstRead=page.waitForResponse(response=>{
        const url=new URL(response.url());
        return url.pathname==='/api/memory/record' && url.searchParams.get('id')===memoryId;
      });
      await source.click();
      const recordResponse=await firstRead;
      expect(recordResponse.status()).toBe(200);
      const record=await recordResponse.json();
      expect(record.record).toMatchObject({id:memoryId,record_version:1,fact:'coffee source'});
      if (surface === 'runs') expect(record.memory_revision).toBe(verificationState.memory_revision);
      expect(reads).toBe(1);
      await expect(area.getByText('coffee source',{exact:true})).toBeVisible();
      await page.evaluate(() => window.dispatchEvent(new Event('offline')));
      await expect(area.getByText('coffee source',{exact:true})).toHaveCount(0);
      await page.evaluate(() => window.dispatchEvent(new Event('online')));
      // The stream reconnects before MemorySync verifies its persisted revision.
      await expect(area.getByText('资料已变化，请重新查看。',{exact:true})).toBeVisible();
      await source.click();
      await expect(area.getByText('coffee source',{exact:true})).toBeVisible();
      let captured;
      const started = new Promise(resolve => { captured=resolve; });
      const delayed = new Promise(resolve => { release=resolve; });
      if (timing === 'late') await page.route('**/api/memory/record?*',async route => {
        const response=await route.fetch(); captured(); await delayed;
        await route.fulfill({response});
      });
      let responseDone;
      if (timing === 'late') {
        responseDone = page.waitForResponse(r => r.url().includes('/api/memory/record?'));
        await source.click();
        await started;
      }
      const gone=await other.command({operation_id:'late-delete',kind:'semantic',action:'delete',expected_version:1,payload:{id:memoryId}});
      expect(gone.status).toBe(200);
      expect(gone.body.forgetting.state).toBe('complete');
      release();
      if (responseDone) {
        await (await responseDone).finished();
        // Browser task barrier after the entire old response is delivered.
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      }
      await expect(area.getByText('coffee source',{exact:true})).toHaveCount(0);
      await expect(area).toContainText(/不可用|已变化|无法核验/);
      await page.unroute('**/api/memory/record?*');
      await page.goto(server.origin+'/behaviour');
      const expand=page.locator('#shell-toolbar [data-open-panel="mainbar"]');
      if(await expand.isVisible()) await expand.click();
      await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toBeVisible();
    } finally { release(); releaseVerification(); await server.close(); }
  });
}


test('SPEC-03 CE-08: accepted POST remains fixed while response waits and Session/form change', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  let release = () => {};
  try {
    const {other,session} = await prepareDraft(page,server);
    let acknowledge;
    const accepted = new Promise(resolve => { acknowledge=resolve; });
    const delayed = new Promise(resolve => { release=resolve; });
    const submitted=[];
    await page.route('**/api/runs',async route => {
      if(route.request().method() !== 'POST') return route.continue();
      submitted.push(route.request().postDataJSON());
      const response=await route.fetch();
      acknowledge(await acceptedRun(response, route.request().postDataJSON()));
      await delayed;
      await route.fulfill({response});
    });
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const {run_id} = await accepted;
    await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+run_id)).body.memory?.aggregation?.graph_result).toBe('Completed');
    // The real server has accepted/completed A, but its HTTP acceptance has
    // not reached the form. All following changes occur with that POST pending.
    const draft=page.getByRole('region',{name:'手动聚合',exact:true}).locator('.behaviour-draft');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('textbox',{name:'聚合关键词',exact:true}).fill('NEXT_KEYWORDS');
    await expect(draft).toHaveAttribute('data-dirty','true');
    await page.getByRole('textbox',{name:'聚合关键词',exact:true}).fill('coffee');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('checkbox',{name:'语义记忆',exact:true}).uncheck();
    await expect(draft).toHaveAttribute('data-dirty','true');
    await page.getByRole('checkbox',{name:'语义记忆',exact:true}).check();
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('button',{name:'新建会话',exact:true}).click();
    await expect.poll(() => page.evaluate(() => sessionStorage.getItem('alfred.session'))).not.toBe(session);
    const second=await page.evaluate(() => sessionStorage.getItem('alfred.session'));
    await page.getByRole('button',{name:'刷新会话',exact:true}).click();
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('combobox',{name:'目标会话'}).selectOption(second);
    await expect(draft).toHaveAttribute('data-dirty','true');
    await page.getByRole('combobox',{name:'目标会话'}).selectOption(session);
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('combobox',{name:'目标会话'}).selectOption(second);
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('CHANGED_GOAL');
    await page.getByRole('textbox',{name:'聚合关键词',exact:true}).fill('CHANGED_KEYWORDS');
    await page.getByRole('checkbox',{name:'语义记忆',exact:true}).uncheck();
    const delivered=page.waitForResponse(r=>r.url().endsWith('/api/runs') && r.request().method()==='POST');
    release(); await (await delivered).finished();
    await expect(page.getByText('本次聚合已结束；草稿请在目标会话查看。')).toBeVisible();
    const facts=(await other.get('/api/run-evidence?run_id='+run_id)).body.memory.aggregation;
    expect(facts.request).toEqual({session_id:session,goal:'draft goal',keywords:'coffee',sources:['semantic']});
    expect(submitted).toEqual([{purpose:'aggregation',session_id:session,message:'draft goal',keywords:'coffee',sources:['semantic']}]);
    expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(r=>r.purpose==='aggregation')).toHaveLength(1);
    await expect(page.locator('#messages')).not.toContainText('已验证草稿');
    await expect(page.getByRole('textbox',{name:'聚合目标',exact:true})).toHaveValue('CHANGED_GOAL');
    await page.getByRole('button',{name:'切换到此会话并查看草稿',exact:true}).click();
    await expect.poll(()=>page.evaluate(()=>sessionStorage.getItem('alfred.session'))).toBe(session);
    await expect(page.locator('#messages').getByText('已验证草稿 [[S1]]',{exact:true})).toHaveCount(1);
    await expect(page.getByRole('textbox',{name:'聚合目标',exact:true})).toHaveValue('CHANGED_GOAL');
  } finally { release(); await server.close(); }
});

test('SPEC-03 CE-11: partial stream transport failure preserves aborted Attempt without a draft', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  try {
    const {other} = await prepareDraft(page,server);
    await server.send('fail-model'); await server.send('hold-model');
    const accepted=page.waitForResponse(r=>r.url().endsWith('/api/runs') && r.request().method()==='POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const {run_id}=await acceptedRun(await accepted);
    await server.send('wait-stream');
    await expect(page.locator('#messages')).not.toContainText('不得展示的候选流');
    await server.send('release-model');
    await expect.poll(async () => (await other.get('/api/runs?filter=chat&limit=25')).body.runs.find(r=>r.run_id===run_id)?.outcome).toBe('failed');
    const evidence=(await other.get('/api/run-evidence?run_id='+run_id)).body;
    expect(evidence.memory.aggregation.reply_disposition).toBe('no_reply');
    expect(evidence.memory.aggregation.steps).toHaveLength(1);
    expect(evidence.memory.aggregation.fallback.decision).toBe('blocked');
    // Read actual persisted AttemptAborted evidence from the real trace bundle.
    const {readFile,readdir}=await import('node:fs/promises');
    const {join}=await import('node:path');
    const files=await readdir(join(server.directory,'traces'),{recursive:true});
    let trace='';
    for(const file of files.filter(f=>f.endsWith('.jsonl'))) trace+=await readFile(join(server.directory,'traces',file),'utf8');
    expect(trace).toContain('attempt.aborted');
    expect(trace).toContain('stream_disconnected');
    expect(trace).toContain('不得展示的候选流');
    await page.reload();
    await expect(page.locator('#messages')).not.toContainText('不得展示的候选流');
    await expect(page.locator('#messages')).not.toContainText('已验证草稿');
    await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿',exact:true})).toHaveCount(0);
  } finally { await server.close(); }
});

for (const rounds of [0, 1, 3]) {
  test(`SPEC-07 rounds=${rounds}: real history exclusion in Behaviour, MainBar and Run`, async ({page}) => {
    const {spawn} = await import('node:child_process');
    const server = await memoryServer({script:'tests/browser/routing_server.py', spawnProcess: (command, args) => spawn(command, [...args, '--working-memory-rounds', String(rounds)])});
    try {
      await page.goto(server.origin+'/behaviour');
      await page.getByRole('button',{name:'新建会话',exact:true}).click();
      await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
      const other = await api(page.request,server.origin);
      const history = [];
      for (const text of ['old history question','new history question']) {
        await page.getByRole('textbox',{name:'消息',exact:true}).fill(text);
        const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method()==='POST');
        await page.getByRole('button',{name:'发送',exact:true}).click();
        const response = await accepted;
        expect(response.status()).toBe(202);
        const {run_id} = await response.json();
        history.push(run_id);
        await expect.poll(async () => (await other.get('/api/runs?filter=chat&limit=25')).body.runs.find(r => r.run_id===run_id)?.outcome).toBe('completed');
      }
      await page.getByRole('button',{name:'刷新会话',exact:true}).click();
      const session = await page.evaluate(() => sessionStorage.getItem('alfred.session'));
      const form = page.getByRole('region',{name:'手动聚合',exact:true});
      await form.getByRole('combobox',{name:'目标会话'}).selectOption(session);
      await form.getByRole('textbox',{name:'聚合目标',exact:true}).fill('history goal');
      for (const name of ['语义记忆','情景记忆']) await form.getByRole('checkbox',{name,exact:true}).uncheck();
      const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method()==='POST');
      await form.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
      const response = await accepted;
      expect(response.status()).toBe(202);
      const {run_id} = await response.json();
      await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+run_id)).body.memory?.aggregation?.graph_result).toBe(rounds ? 'Completed' : 'NoAction');
      const evidence = await other.get('/api/run-evidence?run_id='+run_id);
      expect(evidence.status).toBe(200);
      const facts = evidence.body.memory.aggregation;
      const provided = Math.min(2,rounds);
      expect(facts.sources.history).toMatchObject({candidate_count:2,approved_count:2,round_excluded:2-provided,capacity_excluded:0,request_excluded:0,actual_input_count:provided});
      expect((facts.provided || []).map(r => r.run_id)).toEqual(provided ? history.slice(-provided) : []);
      const text = `会话窗口：已读取；实际提供 ${provided}；容量排除 0；轮数排除 ${2-provided}；许可排除 0；未取完状态 none`;
      await expect(form.getByText(text,{exact:true})).toBeVisible();
      await expect(page.locator('#messages').getByText(text,{exact:true})).toBeVisible();
      if (rounds === 0) {
        expect(facts.reason_code).toBe('capacity_excluded_all');
        expect(facts.steps).toHaveLength(0);
        expect(evidence.body.memory.input_attempts).toHaveLength(0);
        expect(evidence.body.attempts).toHaveLength(0);
        await expect(form.getByText('容量导致无可用资料',{exact:true})).toBeVisible();
        await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿',exact:true})).toHaveCount(0);
        await expect(page.locator('#messages').getByText('离线路由回复',{exact:true})).toHaveCount(2);
      } else {
        expect(facts.steps).toHaveLength(1);
        await expect(page.locator('#messages').getByRole('heading',{name:'聚合草稿',exact:true})).toBeVisible();
      }
      await page.reload();
      await expect(page.locator('#messages').getByText(text,{exact:true})).toBeVisible();
      await page.goto(server.origin+'/runs/'+run_id);
      const area = page.getByRole('region',{name:'运行过程',exact:true});
      await expect(area.getByText(text,{exact:true})).toBeVisible();
      if (rounds === 0) await expect(area.getByText('容量导致无可用资料',{exact:true})).toBeVisible();
    } finally {await server.close();}
  });
}


async function deliverSessionList(page, release) {
  const delivered = page.waitForResponse(r => r.url().includes('/api/sessions?') && r.request().method() === 'GET');
  release();
  await (await delivered).finished();
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
}

test('CI-01: delayed initial Session list cannot erase a newer selected target', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  let release = () => {};
  try {
    let first = true, captured, finished;
    const received = new Promise(resolve => { captured = resolve; });
    const settled = new Promise(resolve => { finished = resolve; });
    const held = new Promise(resolve => { release = resolve; });
    await page.route('**/api/sessions?*', async route => {
      if (!first) return route.continue();
      first = false;
      const response = await route.fetch();
      expect(response.status()).toBe(200);
      expect((await response.json()).sessions).toEqual([]);
      captured(); await held; await route.fulfill({response}).catch(() => {}); finished();
    });
    const {other, session} = await prepareDraft(page, server, () => received);
    await expect(page.getByRole('combobox',{name:'目标会话'})).toHaveValue(session);
    // Refresh cancels the superseded GET. Await the intercepted response's
    // completion, since an aborted fetch correctly emits no browser response.
    release(); await settled;
    // Keep the original HTTP acceptance assertion as well as the selected value.
    const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const response = await accepted, body = await response.json();
    expect(response.status(), JSON.stringify({body,payload:response.request().postDataJSON()})).toBe(202);
    expect(response.request().postDataJSON().session_id).toBe(session);
    await expect(page.getByRole('combobox',{name:'目标会话'})).toHaveValue(session);
    await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+body.run_id)).body.memory?.aggregation?.graph_result).toBe('Completed');
    expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(r => r.purpose === 'aggregation')).toHaveLength(1);
  } finally { release(); await server.close(); }
});

test('CI-01: an in-flight Session refresh preserves the latest user selection', async ({page}) => {
  const server = await memoryServer({script:'tests/browser/aggregation_server.py'});
  let release = () => {};
  try {
    const {other, session} = await prepareDraft(page, server);
    const created = page.waitForResponse(r => r.url().endsWith('/api/sessions') && r.request().method() === 'POST');
    await page.getByRole('button',{name:'新建会话',exact:true}).click();
    const response = await created;
    expect(response.status()).toBe(201);
    const second = (await response.json()).session_id;
    const refreshed = page.waitForResponse(r => r.url().includes('/api/sessions?'));
    await page.getByRole('button',{name:'刷新会话',exact:true}).click();
    await (await refreshed).finished();
    const target = page.getByRole('combobox',{name:'目标会话'});
    await target.selectOption(session);
    let captured;
    const received = new Promise(resolve => { captured = resolve; });
    const held = new Promise(resolve => { release = resolve; });
    await page.route('**/api/sessions?*', async route => {
      const response = await route.fetch();
      expect(response.status()).toBe(200);
      expect((await response.json()).sessions.map(s => s.session_id)).toEqual(expect.arrayContaining([session,second]));
      captured(); await held; await route.fulfill({response});
    });
    await page.getByRole('button',{name:'刷新会话',exact:true}).click();
    await received;
    await target.selectOption(second);
    await deliverSessionList(page, release);
    await expect(target).toHaveValue(second);
    const accepted = page.waitForResponse(r => r.url().endsWith('/api/runs') && r.request().method() === 'POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const result = await accepted, body = await result.json();
    expect(result.status(), JSON.stringify({body,payload:result.request().postDataJSON()})).toBe(202);
    expect(body.session_id).toBe(second);
    await expect.poll(async () => (await other.get('/api/run-evidence?run_id='+body.run_id)).body.memory?.aggregation?.request?.session_id).toBe(second);
  } finally { release(); await server.close(); }
});

test('S06 CE-19: a retained failed-recording form uses the restarted Run outcome instead of old trace success',async({page})=>{
  const server=await memoryServer({script:'tests/browser/aggregation_server.py'});
  const posts=[];page.on('request',r=>{if(r.method()==='POST'&&r.url().endsWith('/api/runs'))posts.push(r.postDataJSON());});
  try {
    await prepareDraft(page,server);await server.send('fail-recording');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    await expect(page.getByText('草稿未保存，请查看运行记录状态。',{exact:true})).toBeVisible();
    const form=page.getByRole('region',{name:'手动聚合',exact:true});
    await form.getByRole('textbox',{name:'聚合目标',exact:true}).fill('重启后仍应保留的新目标');
    const prior=(await(await page.request.get(server.origin+'/api/entry')).json()).instance_id;
    const changed=page.waitForResponse(async r=>r.url().endsWith('/api/entry')&&r.ok()&&(await r.json()).instance_id!==prior);
    await server.send('repair-recording');await server.restart();await changed;
    await form.getByRole('button',{name:'重新核对本次运行',exact:true}).click();
    await expect(form.getByText(/本次运行已中断（interrupted）/)).toBeVisible();
    await expect(form.getByRole('heading',{name:'聚合草稿',exact:true})).toHaveCount(0);
    await expect(form.getByRole('textbox',{name:'聚合目标',exact:true})).toHaveValue('重启后仍应保留的新目标');
    await expect(form.getByRole('button',{name:'生成聚合草稿',exact:true})).toBeEnabled();expect(posts).toHaveLength(1);
  }finally{await server.close();}
});

test('S06 CE-24/27: leaving a form with an accepted delayed POST retires only its UI owner',async({page})=>{
  const server=await memoryServer({script:'tests/browser/aggregation_server.py'});
  let release=()=>{};
  try {
    const {other,session}=await prepareDraft(page,server);let accepted,finished;
    const submitted=new Promise(resolve=>accepted=resolve),settled=new Promise(resolve=>finished=resolve),gate=new Promise(resolve=>release=resolve);
    const posts=[];
    await page.route('**/api/runs',async route=>{
      if(route.request().method()!=='POST')return route.continue();
      posts.push(route.request().postDataJSON());const response=await route.fetch();accepted(await acceptedRun(response));
      await gate;await route.fulfill({response}).catch(()=>{});finished();
    });
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();const {run_id}=await submitted;
    const draft=page.getByRole('region',{name:'手动聚合',exact:true}).locator('.behaviour-draft');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('提交后新增的草稿');
    await expect(draft).toHaveAttribute('data-dirty','true');
    await page.getByRole('link',{name:'运行',exact:true}).click();await page.getByRole('button',{name:'留在此页',exact:true}).click();
    await expect(page.getByRole('textbox',{name:'聚合目标',exact:true})).toHaveValue('提交后新增的草稿');
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('draft goal');
    await expect(draft).toHaveAttribute('data-dirty','false');
    await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('提交后新增的草稿');
    await page.getByRole('link',{name:'运行',exact:true}).click();await page.getByRole('button',{name:'放弃并离开',exact:true}).click();
    await expect(page).toHaveURL(/\/runs$/);release();await settled;
    await expect(page.getByRole('region',{name:'手动聚合',exact:true})).toHaveCount(0);
    await expect.poll(async()=>(await other.get('/api/run-evidence?run_id='+run_id)).body.memory?.aggregation?.graph_result).toBe('Completed');
    expect(posts).toEqual([{purpose:'aggregation',session_id:session,message:'draft goal',keywords:'coffee',sources:['semantic']}]);
    expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(item=>item.purpose==='aggregation')).toHaveLength(1);
    await page.getByRole('link',{name:'行为',exact:true}).click();
    const form=page.getByRole('region',{name:'手动聚合',exact:true});await expect(form.getByRole('textbox',{name:'聚合目标',exact:true})).toHaveValue('');
    await expect(form.getByText('尚未提交聚合请求。',{exact:true})).toBeVisible();
  }finally{release();await server.close();}
});

for(const outcome of ['accepted','rejected']) {
  test(`S06-ST-01: aggregation ${outcome} delayed receipt separates submitted inputs from confirmation`,async({page})=>{
    const server=await memoryServer({script:'tests/browser/aggregation_server.py'});
    let release=()=>{};
    try {
      const {other,session}=await prepareDraft(page,server);
      if(outcome==='rejected')await page.getByRole('textbox',{name:'聚合目标',exact:true}).fill('');
      let accepted,finished;
      const submitted=new Promise(resolve=>accepted=resolve),settled=new Promise(resolve=>finished=resolve),gate=new Promise(resolve=>release=resolve);
      const posts=[];
      await page.route('**/api/runs',async route=>{
        if(route.request().method()!=='POST')return route.continue();
        posts.push(route.request().postDataJSON());const response=await route.fetch();accepted({status:response.status(),body:await response.json()});
        await gate;await route.fulfill({response}).catch(()=>{});finished();
      });
      await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();const receipt=await submitted;
      expect(receipt.status).toBe(outcome==='accepted'?202:400);
      const form=page.getByRole('region',{name:'手动聚合',exact:true}),draft=form.locator('.behaviour-draft');
      await expect(draft).toHaveAttribute('data-dirty','false');await expect(form.getByText('正在提交…',{exact:true})).toBeVisible();
      await expect(form.getByText(/本次 Run：/)).toHaveCount(0);
      if(outcome==='rejected') {
        expect(receipt.body.code).toBe('empty_message');release();await settled;
        await expect(form.getByText('未提交：empty_message；表单已保留。',{exact:true})).toBeVisible();
        await expect(draft).toHaveAttribute('data-dirty','true');
        await page.getByRole('link',{name:'运行',exact:true}).click();await expect(page.getByRole('dialog')).toBeVisible();
        await page.getByRole('button',{name:'留在此页',exact:true}).click();
        expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(item=>item.purpose==='aggregation')).toHaveLength(0);
      } else {
        expect(receipt.body.session_id).toBe(session);
        await page.getByRole('link',{name:'运行',exact:true}).click();await expect(page).toHaveURL(/\/runs$/);
        await expect(page.getByRole('dialog')).toHaveCount(0);release();await settled;
        await expect.poll(async()=>(await other.get('/api/run-evidence?run_id='+receipt.body.run_id)).body.memory?.aggregation?.graph_result).toBe('Completed');
        expect((await other.get('/api/runs?filter=chat&limit=25')).body.runs.filter(item=>item.purpose==='aggregation')).toHaveLength(1);
      }
      expect(posts).toHaveLength(1);expect(posts[0].session_id).toBe(session);
    } finally {release();await server.close();}
  });
}

test('S11 one real forgetting event retires hidden Run, aggregation, Overview and Database owners',async({page,context})=>{
  const server=await memoryServer({script:'tests/browser/aggregation_server.py'});
  let releaseDatabase=()=>{},releaseCounts=()=>{};
  const others=[];
  try{
    const {other,memoryId}=await prepareDraft(page,server);
    const accepted=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/runs'&&r.request().method()==='POST');
    await page.getByRole('button',{name:'生成聚合草稿',exact:true}).click();
    const {run_id}=await acceptedRun(await accepted);
    const form=page.getByRole('region',{name:'手动聚合',exact:true,includeHidden:true});
    await expect(form.getByText('本次聚合已结束；草稿请在目标会话查看。',{exact:true})).toBeVisible();
    await page.getByRole('button',{name:'收起主对话',exact:true}).click();
    await form.getByRole('button',{name:'语义记忆 S1',exact:true}).click();
    await expect(form.getByText('coffee source',{exact:true})).toBeVisible();
    await page.setViewportSize({width:390,height:844});
    await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    const run=await context.newPage();others.push(run);await run.setViewportSize({width:390,height:844});
    await run.goto(server.origin+'/runs/'+run_id);
    const process=run.getByRole('region',{name:'运行过程',exact:true,includeHidden:true});
    await process.getByRole('button',{name:'语义记忆 S1',exact:true}).click();
    await expect(process.getByText('coffee source',{exact:true})).toBeVisible();
    await run.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    const overview=await context.newPage();others.push(overview);await overview.setViewportSize({width:390,height:844});
    await overview.goto(server.origin+'/overview');const counts=overview.getByLabel('当前记忆条目数');
    await expect(counts).toContainText('语义 1 条');
    let countsArrived;const countsReceived=new Promise(resolve=>countsArrived=resolve),countsGate=new Promise(resolve=>releaseCounts=resolve);
    await overview.route('**/api/overview/memory-counts?**',async route=>{const response=await route.fetch();countsArrived();await countsGate;await route.fulfill({response});});
    await overview.getByRole('button',{name:'刷新记忆计数',exact:true}).click();await countsReceived;
    await overview.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    const database=await context.newPage();others.push(database);await database.setViewportSize({width:390,height:844});
    await database.goto(server.origin+'/database');await expect(database.getByText('可执行',{exact:true})).toBeVisible();
    await database.getByRole('textbox',{name:'SQL',exact:true}).fill('SELECT fact FROM diag_facts');
    await database.getByRole('button',{name:'执行',exact:true}).click();
    await expect(database.getByRole('region',{name:'查询结果',exact:true})).toContainText('coffee source');
    await expect(database.getByRole('button',{name:'复制本页结果',exact:true})).toBeEnabled();
    let queryArrived;const queryReceived=new Promise(resolve=>queryArrived=resolve),queryGate=new Promise(resolve=>releaseDatabase=resolve);
    await database.route('**/api/database/queries/*/execute',async route=>{const response=await route.fetch();queryArrived();await queryGate;await route.fulfill({response});});
    await database.getByRole('button',{name:'执行',exact:true}).click();await queryReceived;
    await database.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
    const deletion=await other.command({operation_id:'S11-fanout-delete',kind:'semantic',action:'delete',payload:{id:memoryId},expected_version:1});
    expect(deletion.status).toBe(200);expect(deletion.body.forgetting.state).toBe('complete');
    await expect(form.getByText('coffee source',{exact:true})).toHaveCount(0);
    await expect(process.getByText('coffee source',{exact:true})).toHaveCount(0);
    await expect(counts).not.toContainText('语义 1 条');
    await expect(database.getByRole('button',{name:'复制本页结果',exact:true,includeHidden:true})).toBeDisabled();
    const verified=await other.get('/api/database');expect(verified.status).toBe(200);
    await expect(database.getByRole('region',{name:'诊断对象目录',includeHidden:true})).toContainText('记忆修订 '+verified.body.memory_revision);
    releaseCounts();releaseDatabase();await overview.unrouteAll({behavior:'wait'});await database.unrouteAll({behavior:'wait'});
    await expect(counts).not.toContainText('语义 1 条');
    await expect(database.getByRole('region',{name:'查询结果',includeHidden:true})).toBeEmpty();
    for(const tab of [page,run,overview,database])await tab.getByRole('button',{name:'收起主对话',exact:true}).click();
    await overview.getByRole('button',{name:'刷新记忆计数',exact:true}).click();await expect(counts).toContainText('语义 0 条');
    await database.getByRole('button',{name:'执行',exact:true}).click();await expect(database.getByRole('region',{name:'查询结果',exact:true})).toContainText('0 行');
    expect((await other.get('/api/runs?filter=all')).body.runs.map(value=>value.run_id)).toEqual([run_id]);
    expect((await other.get('/api/memory/record?kind=semantic&id='+memoryId)).status).toBe(404);
  }finally{releaseCounts();releaseDatabase();for(const tab of others)await tab.close();await server.close();}
});
