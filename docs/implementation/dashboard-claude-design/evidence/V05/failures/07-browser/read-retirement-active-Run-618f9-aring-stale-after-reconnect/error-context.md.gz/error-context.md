# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: read-retirement.spec.js >> active Run evidence retires its response without clearing stale after reconnect
- Location: tests/browser/read-retirement.spec.js:162:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.page-body > [role=status]').filter({ hasText: /^过程证据共同来源 ·/ })
Expected substring: "读取于"
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.page-body > [role=status]').filter({ hasText: /^过程证据共同来源 ·/ }) with timeout 4000ms
  - waiting for locator('.page-body > [role=status]').filter({ hasText: /^过程证据共同来源 ·/ })

```

```yaml
- banner "导航面板":
  - link "Agent-Alfred 本地助手":
    - /url: /overview
  - navigation "主导航":
    - paragraph: 工作区
    - link "总览":
      - /url: /overview
    - link "收件箱":
      - /url: /inbox
    - link "运行":
      - /url: /runs
    - link "记忆":
      - /url: /memory
    - paragraph: Agent 配置
    - link "模型":
      - /url: /models
    - link "连接":
      - /url: /connections
    - link "行为":
      - /url: /behaviour
    - link "工具":
      - /url: /tools
    - paragraph: 诊断
    - link "用量账本":
      - /url: /ops
    - link "数据库":
      - /url: /database
  - paragraph: 本地优先 · 共享运行宿主
- button "打开主对话" [expanded]
- region "运行与连接摘要":
  - paragraph: 正在保存 · Web
  - link "查看当前运行":
    - /url: /runs/d50c364234644ae589b2b07d133b01b5?filter=chat
- main:
  - heading "运行" [level=1]
  - link "返回运行列表":
    - /url: /runs?filter=all
  - button "在主对话中查看"
  - link "查看追踪导出":
    - /url: "#trace-export"
  - region "运行摘要":
    - heading "运行摘要" [level=2]
    - article:
      - term: 输入预览
      - definition: 运行来源退休验证
      - term: 准入
      - definition: 已获准
      - term: 阶段
      - definition: 已结束
      - term: 结果
      - definition: 回复完成
      - term: 记录
      - definition: 正在保存
      - term: Step 数
      - definition: 未提供
      - term: 耗时
      - definition: 未提供
      - term: 费用
      - definition: unknown · 费用未知
      - term: Run ID
      - definition: d50c364234644ae589b2b07d133b01b5
      - term: 用途
      - definition: 普通聊天（chat）
      - term: 所属分组
      - definition: 会话运行
      - group: 运行摘要明细
    - status: 运行摘要 · 读取于 10:31:30 AM
    - button "刷新运行摘要"
  - region "运行过程":
    - heading "过程证据" [level=2]
    - paragraph: 事件发布顺序
    - status: 过程证据共同来源 · 读取于 10:31:30 AM
    - button "刷新过程证据"
    - paragraph: 实时过程由 SSE 提供
    - group: 本次输入
  - region "本次执行路径":
    - button "本次执行路径"
    - status: 服务已连接；结构仅在手动读取时更新。
    - status: 尚未读取；展开后读取。
  - group: 用量
  - region "追踪导出":
    - heading "追踪导出" [level=2]
    - status: 连接或记忆边界已变化，旧导出不可恢复；可重新手动生成。
    - group:
      - text: 追踪导出操作
      - combobox "导出模式":
        - option "分享净化" [selected]
        - option "保留诊断正文"
      - paragraph: 默认移除自由正文；净化与源追踪完整性分别说明。
      - button "生成追踪导出"
- region "MainBar":
  - heading "主对话" [level=2]
  - button "收起主对话"
  - region "当前运行":
    - strong: 正在保存
    - paragraph: 运行来源退休验证
    - text: Web · 2026-10-11T02:31:30Z · Step 1
    - link "查看当前运行":
      - /url: http://127.0.0.1:17924/runs/d50c364234644ae589b2b07d133b01b5?filter=chat
  - text: 会话
  - button "新建会话" [disabled]
  - region "主对话":
    - button "当前运行保存后继续读取" [disabled]
    - article:
      - text: 请求预览（未取得完整请求）
      - paragraph: 运行来源退休验证
      - paragraph: 离线模型回复
      - text: 已完成 正在保存
  - text: 消息
  - textbox "消息":
    - /placeholder: 写下消息；/skills 指定流程…
  - button "发送" [disabled]
  - paragraph: 当前运行尚未收尾；不会排队发送。
- status: 正在保存
- alert
```

# Test source

```ts
  93  |     await expect(status).toContainText("增量通知缺口");
  94  |   }
  95  |   expect(await page.evaluate(() => new Set(window.hostInstances).size)).toBe(1);
  96  |   expect(
  97  |     await page.evaluate(
  98  |       (index) => window.nativeStreams[index].readyState,
  99  |       previousStream,
  100 |     ),
  101 |   ).toBe(2);
  102 |   expect(
  103 |     await page.evaluate(
  104 |       () =>
  105 |         window.nativeStreams.filter(
  106 |           (source) => source.readyState !== EventSource.CLOSED,
  107 |         ).length,
  108 |     ),
  109 |   ).toBe(1);
  110 |   return gap ? "增量通知缺口，快照待刷新" : "连接中断，保留旧快照";
  111 | }
  112 | 
  113 | for (const gap of [false, true])
  114 |   test(`real Session response is retired across ${gap ? "broker replay gap" : "disconnect"} and same-instance reconnect`, async ({
  115 |     page,
  116 |     context,
  117 |   }) => {
  118 |     const server = await localServer();
  119 |     let held;
  120 |     try {
  121 |       await observeStream(page);
  122 |       await page.goto(server.origin + "/inbox");
  123 |       const list = page.getByRole("region", { name: "会话列表" });
  124 |       await expect(list.locator("[data-source-id]")).toHaveCount(1);
  125 |       const entry = await (
  126 |         await page.request.get(server.origin + "/api/entry")
  127 |       ).json();
  128 |       const created = await page.request.post(server.origin + "/api/sessions", {
  129 |         headers: { "x-agent-alfred-csrf": entry.csrf_token },
  130 |         data: {},
  131 |       });
  132 |       expect(created.status()).toBe(201);
  133 |       const session = (await created.json()).session_id;
  134 |       held = await holdResponse(page, "**/api/sessions?**");
  135 |       const refresh = list.getByRole("button", {
  136 |         name: "刷新会话",
  137 |         exact: true,
  138 |       });
  139 |       await refresh.click();
  140 |       await held.received;
  141 |       const reason = await interruptRead(page, context, list, gap);
  142 |       await held.release();
  143 |       await page.evaluate(() => new Promise(requestAnimationFrame));
  144 |       await expect(list.locator("[data-source-id]")).toHaveCount(1);
  145 |       await expect(list).toContainText(reason);
  146 |       await expect(refresh).toBeEnabled();
  147 |       await refresh.click();
  148 |       await expect(list.locator("[data-source-id]")).toHaveCount(2);
  149 |       await expect(
  150 |         list.locator('[data-source-id="' + session + '"]'),
  151 |       ).toHaveCount(1);
  152 |       await expect(list).not.toContainText(reason);
  153 |     } finally {
  154 |       await context.setOffline(false);
  155 |       if (held) await held.release();
  156 |       await server.close();
  157 |     }
  158 |   });
  159 | 
  160 | for (const gap of [false, true])
  161 |   for (const source of ["summary", "evidence"])
  162 |     test(`active Run ${source} retires its response without clearing stale after ${gap ? "broker replay gap" : "reconnect"}`, async ({
  163 |       page,
  164 |       context,
  165 |     }) => {
  166 |       const server = await memoryServer({
  167 |         script: "tests/browser/trace_export_server.py",
  168 |       });
  169 |       let held;
  170 |       try {
  171 |         await observeStream(page);
  172 |         await page.goto(server.origin + "/inbox");
  173 |         await page
  174 |           .getByRole("button", { name: "新建会话", exact: true })
  175 |           .click();
  176 |         await server.send("recording-hold-fail");
  177 |         await page
  178 |           .getByRole("textbox", { name: "消息", exact: true })
  179 |           .fill("运行来源退休验证");
  180 |         const accepted = page.waitForResponse(
  181 |           (r) =>
  182 |             new URL(r.url()).pathname === "/api/runs" &&
  183 |             r.request().method() === "POST",
  184 |         );
  185 |         await page.getByRole("button", { name: "发送", exact: true }).click();
  186 |         const { run_id } = await (await accepted).json();
  187 |         await server.send("await-recording");
  188 |         await page.goto(server.origin + "/runs/" + encodeURIComponent(run_id));
  189 |         const statuses = page.locator(".page-body > [role=status]");
  190 |         const status = statuses.filter({
  191 |           hasText: source === "summary" ? /^运行摘要 ·/ : /^过程证据共同来源 ·/,
  192 |         });
> 193 |         await expect(status).toContainText("读取于");
      |                              ^ Error: expect(locator).toContainText(expected) failed
  194 |         const observed = await status.textContent();
  195 |         await page.clock.setFixedTime(new Date(Date.now() + 120000));
  196 |         const pattern =
  197 |           source === "summary"
  198 |             ? "**/api/runs/locate/**"
  199 |             : "**/api/run-evidence?**";
  200 |         held = await holdResponse(page, pattern);
  201 |         const refresh = page.getByRole("button", {
  202 |           name: source === "summary" ? "刷新运行摘要" : "刷新过程证据",
  203 |           exact: true,
  204 |         });
  205 |         await refresh.click();
  206 |         await held.received;
  207 |         const reason = await interruptRead(page, context, status, gap);
  208 |         await held.release();
  209 |         await page.evaluate(() => new Promise(requestAnimationFrame));
  210 |         await expect(status).toHaveText(
  211 |           observed +
  212 |             " · " +
  213 |             reason +
  214 |             (gap && source === "evidence"
  215 |               ? " · 增量通知缺口，过程快照待刷新"
  216 |               : ""),
  217 |         );
  218 |         await expect(refresh).toBeEnabled();
  219 |         await refresh.click();
  220 |         await expect(status).not.toContainText(reason);
  221 |         await expect(status).not.toHaveText(observed);
  222 |       } finally {
  223 |         await context.setOffline(false);
  224 |         if (held) await held.release();
  225 |         await server.send("release-recording");
  226 |         await server.close();
  227 |       }
  228 |     });
  229 | 
```