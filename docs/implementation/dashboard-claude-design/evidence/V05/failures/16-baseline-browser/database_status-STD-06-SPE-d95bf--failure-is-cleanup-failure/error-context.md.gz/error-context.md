# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: database_status.spec.js >> STD-06/SPEC-12: actual worker stop failure is cleanup failure
- Location: tests/browser/database_status.spec.js:95:1

# Error details

```
Test timeout of 15000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner "导航面板" [ref=e2]:
    - link "Agent-Alfred 本地助手" [ref=e3] [cursor=pointer]:
      - /url: /overview
      - text: Agent-Alfred
      - generic [ref=e4]: 本地助手
    - navigation "主导航" [ref=e5]:
      - paragraph [ref=e6]: 工作区
      - link "总览" [ref=e7] [cursor=pointer]:
        - /url: /overview
      - link "收件箱" [ref=e8] [cursor=pointer]:
        - /url: /inbox
      - link "运行" [ref=e9] [cursor=pointer]:
        - /url: /runs
      - link "记忆" [ref=e10] [cursor=pointer]:
        - /url: /memory
      - paragraph [ref=e11]: Agent 配置
      - link "模型" [ref=e12] [cursor=pointer]:
        - /url: /models
      - link "连接" [ref=e13] [cursor=pointer]:
        - /url: /connections
      - link "行为" [ref=e14] [cursor=pointer]:
        - /url: /behaviour
      - link "工具" [ref=e15] [cursor=pointer]:
        - /url: /tools
      - paragraph [ref=e16]: 诊断
      - link "用量账本" [ref=e17] [cursor=pointer]:
        - /url: /ops
      - link "数据库" [ref=e18] [cursor=pointer]:
        - /url: /database
    - paragraph [ref=e19]: 本地优先 · 共享运行宿主
  - generic [ref=e20]:
    - generic "壳层状态与操作" [ref=e21]:
      - button "打开主对话" [expanded] [ref=e22] [cursor=pointer]
      - region "运行与连接摘要" [ref=e23]:
        - paragraph [ref=e24]: 尚未选择会话
    - main [ref=e25]:
      - heading "数据库" [level=1] [ref=e26]
      - generic [ref=e27]:
        - paragraph [ref=e28]: 查询受保护的临时数据。SQL 的 WHERE／LIMIT 不缩小准备范围。结果有上限，不是数据库总量。
        - region "诊断对象目录" [ref=e29]:
          - paragraph [ref=e30]: 当前实例固定。记忆修订 11 · 保护规则版本 5
          - paragraph [ref=e31]: 可用性：已核验可用
          - paragraph [ref=e32]: 执行预算 5 秒 · 最多 1000 行／64 列／2 MiB JSON
          - group [ref=e33]:
            - generic "对象目录" [ref=e34] [cursor=pointer]
          - group [ref=e35]:
            - generic "完整限制与寿命" [ref=e36] [cursor=pointer]
        - generic [ref=e37]: SQL 草稿
        - textbox "SQL" [ref=e38]:
          - /placeholder: SELECT * FROM diag_sessions LIMIT 20
          - text: SELECT * FROM diag_sessions
        - paragraph [ref=e39]: Enter 换行。仅点击执行才提交；查询中可编辑下一份草稿。
        - generic [ref=e40]:
          - button "执行" [disabled] [ref=e41]
          - button "取消" [disabled] [ref=e42]
          - button "核验查询与可用性" [ref=e43] [cursor=pointer]
          - button "复制 SQL" [ref=e44] [cursor=pointer]
        - paragraph [ref=e45]: 查询清理尚未确认释放；请核验查询与可用性。
        - paragraph [ref=e46]: 记忆或保护版本变化：已清除结果及提交关联；草稿保留，核验后仍需显式执行。
        - region "查询与资源状态" [ref=e47]:
          - generic [ref=e48]:
            - heading "执行" [level=3] [ref=e49]
            - paragraph [ref=e50]: 失效
          - generic [ref=e51]:
            - heading "正文" [level=3] [ref=e52]
            - paragraph [ref=e53]: 正文已清除；晚到响应不会恢复。
          - generic [ref=e54]:
            - heading "清理" [level=3] [ref=e55]
            - paragraph [ref=e56]: 清理失败
        - region "已提交查询"
        - button "复制本页结果" [disabled] [ref=e57]
        - status [ref=e58]: 尚无有效结果可复制。
        - region "查询结果"
  - region "MainBar" [ref=e59]:
    - generic [ref=e60]:
      - heading "主对话" [level=2] [ref=e61]
      - button "收起主对话" [ref=e62] [cursor=pointer]
    - generic [ref=e63]:
      - generic [ref=e64]: 尚未选择会话
      - button "新建会话" [ref=e65] [cursor=pointer]
    - region "主对话" [ref=e66]
    - generic [ref=e67]:
      - generic [ref=e68]: 消息
      - textbox "消息" [disabled] [ref=e69]:
        - /placeholder: 写下消息；/skills 指定流程…
      - button "发送" [disabled] [ref=e70]
    - paragraph [ref=e71]: 请显式新建或继续会话。
  - status [ref=e72]: 就绪
  - alert [ref=e73]
```