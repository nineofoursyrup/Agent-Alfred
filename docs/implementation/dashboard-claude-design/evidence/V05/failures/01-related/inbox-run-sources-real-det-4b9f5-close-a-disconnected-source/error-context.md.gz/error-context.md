# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: inbox-run-sources.spec.js >> real detail snapshots expire without polling and disclose a disconnected source
- Location: tests/browser/inbox-run-sources.spec.js:311:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.page-body > [role=status]').filter({ hasText: '过程证据共同来源 · 读取于' })
Expected: 1
Received: 0
Timeout:  4000ms

Call log:
  - Expect "toHaveCount" locator('.page-body > [role=status]').filter({ hasText: '过程证据共同来源 · 读取于' }) with timeout 4000ms
  - waiting for locator('.page-body > [role=status]').filter({ hasText: '过程证据共同来源 · 读取于' })
    12 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner "导航面板" [ref=e2]:
    - link "Agent-Alfred 本地助手" [ref=e3] [cursor=pointer]:
      - /url: /overview
      - text: Agent-Alfred
      - generic [ref=e4]: 本地助手
    - navigation "主导航" [ref=e5]:
      - paragraph [ref=e6]: 工作区
      - link "总览" [ref=e7] [cursor=pointer]:
        - /url: /overview
      - link "收件箱" [ref=e8] [cursor=pointer]:
        - /url: /inbox
      - link "运行" [ref=e9] [cursor=pointer]:
        - /url: /runs
      - link "记忆" [ref=e10] [cursor=pointer]:
        - /url: /memory
      - paragraph [ref=e11]: Agent 配置
      - link "模型" [ref=e12] [cursor=pointer]:
        - /url: /models
      - link "连接" [ref=e13] [cursor=pointer]:
        - /url: /connections
      - link "行为" [ref=e14] [cursor=pointer]:
        - /url: /behaviour
      - link "工具" [ref=e15] [cursor=pointer]:
        - /url: /tools
      - paragraph [ref=e16]: 诊断
      - link "用量账本" [ref=e17] [cursor=pointer]:
        - /url: /ops
      - link "数据库" [ref=e18] [cursor=pointer]:
        - /url: /database
    - paragraph [ref=e19]: 本地优先 · 共享运行宿主
  - generic [ref=e20]:
    - generic "壳层状态与操作" [ref=e21]:
      - button "打开主对话" [expanded] [ref=e22] [cursor=pointer]
      - region "运行与连接摘要" [ref=e23]:
        - paragraph [ref=e24]: 连接中断或正在同步
    - main [ref=e25]:
      - heading "运行" [active] [level=1] [ref=e26]
      - generic [ref=e27]:
        - generic [ref=e28]:
          - link "返回运行列表" [ref=e29] [cursor=pointer]:
            - /url: /runs?filter=all
          - button "切换到此会话并在主对话中查看" [disabled] [ref=e30]
          - link "查看追踪导出" [ref=e31] [cursor=pointer]:
            - /url: "#trace-export"
        - region "运行摘要" [ref=e32]:
          - heading "运行摘要" [level=2] [ref=e34]
          - article [ref=e35]:
            - generic [ref=e36]:
              - generic [ref=e38]:
                - term [ref=e39]: 用途
                - definition [ref=e40]: 手动聚合（aggregation）
              - generic [ref=e41]:
                - generic [ref=e42]:
                  - term [ref=e43]: 结果
                  - definition [ref=e44]: 已完成
                - generic [ref=e45]:
                  - term [ref=e46]: 记录
                  - definition [ref=e47]: 记录状态未知
                - generic [ref=e48]:
                  - term [ref=e49]: Step 数
                  - definition [ref=e50]: 未提供
                - generic [ref=e51]:
                  - term [ref=e52]: 耗时
                  - definition [ref=e53]: 1.0 s
                - generic [ref=e54]:
                  - term [ref=e55]: 费用
                  - definition [ref=e56]:
                    - generic [ref=e57]: unknown · 费用未知
            - generic [ref=e59]:
              - generic [ref=e60]:
                - term [ref=e61]: Run ID
                - definition
              - generic [ref=e62]:
                - term [ref=e63]: 所属分组
                - definition [ref=e64]: 会话运行
              - generic [ref=e65]:
                - term [ref=e66]: 来源
                - definition [ref=e67]: cli
              - generic [ref=e68]:
                - term [ref=e69]: 入口
                - definition [ref=e70]: 未知
              - generic [ref=e71]:
                - term [ref=e72]: 会话
                - definition
              - generic [ref=e73]:
                - term [ref=e74]: 接受时间
                - definition [ref=e75]: 2026-10-01T00:00:00Z
              - generic [ref=e76]:
                - term [ref=e77]: 开始时间
                - definition [ref=e78]: 2026-10-01T00:00:01Z
              - generic [ref=e79]:
                - term [ref=e80]: 结束时间
                - definition [ref=e81]: 2026-10-01T00:00:02Z
              - generic [ref=e82]:
                - term [ref=e83]: 准入
                - definition [ref=e84]: 已获准
              - generic [ref=e85]:
                - term [ref=e86]: 阶段
                - definition [ref=e87]: 已结束
              - generic [ref=e88]:
                - term [ref=e89]: 记录来源
                - definition [ref=e90]: unknown
              - generic [ref=e91]:
                - term [ref=e92]: 聚合
                - definition [ref=e93]: Graph 未知 · 草稿状态未知 ·
          - generic [ref=e94]:
            - status [ref=e95]: 运行摘要 · 读取于 9:59:08 AM · 连接中断，保留旧快照
            - button "刷新运行摘要" [disabled] [ref=e96]
        - region "运行过程" [ref=e97]:
          - generic [ref=e98]:
            - generic [ref=e99]:
              - generic [ref=e100]:
                - heading "过程证据" [level=2] [ref=e101]
                - paragraph [ref=e102]: 事件发布顺序
              - generic [ref=e103]:
                - status [ref=e104]: 过程证据共同来源 · 读取于 9:59:09 AM · 连接中断，保留旧快照
                - button "刷新过程证据" [disabled] [ref=e105]
            - paragraph [ref=e107]: 过程记录不可用
          - group [ref=e108]:
            - generic "本次输入" [ref=e109]
        - region "本次执行路径" [ref=e111]:
          - button "本次执行路径" [ref=e112] [cursor=pointer]
          - status [ref=e113]: 服务连接已断开；保留的图仅为旧快照。
          - status [ref=e114]: 尚未读取；展开后读取。
        - group [ref=e115]:
          - generic "用量" [ref=e116]
        - region "追踪导出" [ref=e118]:
          - heading "追踪导出" [level=2] [ref=e120]
          - generic [ref=e121]:
            - status [ref=e122]: 连接或记忆边界已变化，旧导出不可恢复；可重新手动生成。
            - group [ref=e123]:
              - generic "追踪导出操作" [ref=e124]
              - combobox "导出模式" [ref=e125]:
                - option "分享净化" [selected]
                - option "保留诊断正文"
              - paragraph [ref=e126]: 默认移除自由正文；净化与源追踪完整性分别说明。
              - button "生成追踪导出" [disabled] [ref=e127]
  - region "MainBar" [ref=e128]:
    - generic [ref=e129]:
      - heading "主对话" [level=2] [ref=e130]
      - button "收起主对话" [ref=e131] [cursor=pointer]
    - complementary "本标签页连接状态" [ref=e132]:
      - paragraph [ref=e133]: 连接已断开；已清除临时文字，正在重新连接。
      - text: 仅影响本标签页
      - button "关闭连接提示" [ref=e134] [cursor=pointer]
    - generic [ref=e135]:
      - generic [ref=e136]: 尚未选择会话
      - button "新建会话" [ref=e137] [cursor=pointer]
    - region "主对话" [ref=e138]
    - generic [ref=e139]:
      - generic [ref=e140]: 消息
      - textbox "消息" [disabled] [ref=e141]:
        - /placeholder: 写下消息；/skills 指定流程…
      - button "发送" [disabled] [ref=e142]
    - paragraph [ref=e143]: 请显式新建或继续会话。
  - status [ref=e144]: 就绪
  - alert [ref=e145]
```

# Test source

```ts
  231 |             ]),
  232 |           ),
  233 |       ).toEqual(keys);
  234 |       await expect(list.getByRole("link", { name: "查看运行" })).toHaveCount(
  235 |         keys.length,
  236 |       );
  237 |     }
  238 |     await list.locator(".run-list-body").evaluate((element) => element.removeAttribute("style"));
  239 |     for (const width of [390, 320]) {
  240 |       await page.setViewportSize({ width, height: 844 });
  241 |       expect(
  242 |         await page.evaluate(
  243 |           () => document.documentElement.scrollWidth <= innerWidth,
  244 |         ),
  245 |       ).toBe(true);
  246 |     }
  247 |     await list
  248 |       .getByRole("link", { name: "查看运行", exact: true })
  249 |       .first()
  250 |       .click();
  251 |     const fields = page.getByRole("region", { name: "运行摘要" }).locator("dt");
  252 |     for (const width of [1440, 320]) {
  253 |       await page.setViewportSize({ width, height: 900 });
  254 |       await expect(fields.first()).toBeVisible();
  255 |       await expect
  256 |         .poll(() =>
  257 |           fields.evaluateAll((items) => [
  258 |             ...new Set(items.map((item) => getComputedStyle(item).fontSize)),
  259 |           ]),
  260 |         )
  261 |         .toEqual(["11px"]);
  262 |     }
  263 |   } finally {
  264 |     await server.close();
  265 |   }
  266 | });
  267 | 
  268 | test("all Runs return keeps its source filter through one bounded read", async ({
  269 |   page,
  270 | }) => {
  271 |   const server = await localServer(seed(60));
  272 |   try {
  273 |     const reads = [];
  274 |     page.on("request", (request) => {
  275 |       if (request.method() === "GET") reads.push(request.url());
  276 |     });
  277 |     await page.goto(server.origin + "/runs?filter=all");
  278 |     const list = page.getByRole("region", { name: "运行列表" });
  279 |     const target = list.locator('a[href="/runs/?filter=all"]');
  280 |     await expect(list.locator("[data-source-id]")).toHaveCount(25);
  281 |     for (let loaded = 25; loaded < 125; loaded += 25) {
  282 |       await list.getByRole("button", { name: "更多运行", exact: true }).click();
  283 |       await expect(list.locator("[data-source-id]")).toHaveCount(loaded + 25);
  284 |     }
  285 |     await target.click();
  286 |     await expect(page.getByRole("region", { name: "运行摘要" })).toContainText(
  287 |       "aggregation",
  288 |     );
  289 |     const start = reads.length;
  290 |     await page.getByRole("link", { name: "返回来源", exact: true }).click();
  291 |     await expect(
  292 |       list.locator('[data-source-highlighted="true"]'),
  293 |     ).toHaveAttribute("data-source-id", "");
  294 |     await expect(target).toBeFocused();
  295 |     await expect(page.getByRole("combobox", { name: "运行筛选" })).toHaveValue(
  296 |       "all",
  297 |     );
  298 |     const locations = reads
  299 |       .slice(start)
  300 |       .filter((url) => new URL(url).pathname === "/api/runs/locate/");
  301 |     expect(locations).toHaveLength(1);
  302 |     expect(new URL(locations[0]).searchParams.get("filter")).toBe("all");
  303 |     expect(
  304 |       reads.slice(start).filter((url) => new URL(url).pathname === "/api/runs"),
  305 |     ).toHaveLength(0);
  306 |   } finally {
  307 |     await server.close();
  308 |   }
  309 | });
  310 | 
  311 | test("real detail snapshots expire without polling and disclose a disconnected source", async ({
  312 |   page,
  313 | }) => {
  314 |   const server = await localServer(seed(4));
  315 |   let stopped = false;
  316 |   try {
  317 |     await page.clock.install();
  318 |     const reads = [];
  319 |     page.on("request", (request) => {
  320 |       if (
  321 |         ["/api/run-evidence", "/api/runs/locate/"].includes(
  322 |           new URL(request.url()).pathname,
  323 |         )
  324 |       )
  325 |         reads.push(request.url());
  326 |     });
  327 |     await page.goto(server.origin + "/runs/");
  328 |     const statuses = page.locator(".page-body > [role=status]");
  329 |     await expect(
  330 |       statuses.filter({ hasText: "过程证据共同来源 · 读取于" }),
> 331 |     ).toHaveCount(1);
      |       ^ Error: expect(locator).toHaveCount(expected) failed
  332 |     const count = reads.length;
  333 |     await page.clock.fastForward(16 * 60 * 1000);
  334 |     await expect(statuses.filter({ hasText: "已过期，请刷新" })).toHaveCount(2);
  335 |     expect(reads.length).toBe(count);
  336 |     await server.close();
  337 |     stopped = true;
  338 |     await expect(
  339 |       statuses.filter({ hasText: "连接中断，保留旧快照" }),
  340 |     ).toHaveCount(2);
  341 |     await expect(page.getByRole("region", { name: "运行摘要" })).toContainText(
  342 |       "aggregation",
  343 |     );
  344 |   } finally {
  345 |     if (!stopped) await server.close();
  346 |   }
  347 | });
  348 | 
```