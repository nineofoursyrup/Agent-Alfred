# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accounting.spec.js >> A24 A32 A33: snapshot expiry, offline body, reconnect prune and page cleanup
- Location: tests/browser/accounting.spec.js:112:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/离线副本/)
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/离线副本/) with timeout 4000ms
  - waiting for getByText(/离线副本/)

```

```yaml
- banner "导航面板":
  - link "Agent-Alfred 本地助手":
    - /url: /overview
  - navigation "主导航":
    - paragraph: 工作区
    - link "总览":
      - /url: /overview
    - link "收件箱":
      - /url: /inbox
    - link "运行":
      - /url: /runs
    - link "记忆":
      - /url: /memory
    - paragraph: Agent 配置
    - link "模型":
      - /url: /models
    - link "连接":
      - /url: /connections
    - link "行为":
      - /url: /behaviour
    - link "工具":
      - /url: /tools
    - paragraph: 诊断
    - link "用量账本":
      - /url: /ops
    - link "数据库":
      - /url: /database
  - paragraph: 本地优先 · 共享运行宿主
- button "打开主对话" [expanded]
- region "运行与连接摘要":
  - paragraph: 回复完成 · 已保存
  - link "查看最近运行结果":
    - /url: /runs/0fa442387f104b6191df730797db0390
- main:
  - heading "用量账本" [level=1]
  - form "账目筛选":
    - heading "待查询条件" [level=2]
    - text: 时间范围
    - combobox "时间范围":
      - option "近七个自然日" [selected]
      - option "今天"
      - option "近三十个自然日"
      - option "自定义半开区间"
      - option "全部历史"
    - text: IANA 时区
    - textbox "IANA 时区": Asia/Shanghai
    - text: 开始日期（含）
    - textbox "开始日期（含）"
    - text: 自定义期间使用当地日期 结束日期（不含）
    - textbox "结束日期（不含）"
    - text: 结束日为排他边界 会话 ID
    - textbox "会话 ID"
    - text: 运行用途
    - combobox "运行用途":
      - option "全部用途" [selected]
      - option "普通聊天"
      - option "手动聚合"
      - option "模型推理探针"
      - option "记忆提炼"
    - text: 工具身份
    - textbox "工具身份":
      - /placeholder: 来源与能力身份
    - text: 包含匹配工具的完整 Run Run ID
    - textbox "Run ID":
      - /placeholder: 精确 Run ID
    - text: 使用完整不透明标识
    - status: 筛选只在点击“刷新账目”时应用。
    - button "刷新账目"
  - status: 固定账目快照；后台变化后请显式刷新。
  - status
  - region "当前账目快照":
    - heading "当前账目快照" [level=2]
    - paragraph: 半开期间 [2026-10-04T16:00:00+00:00, 2026-10-11T16:00:00+00:00) · 时区 Asia/Shanghai · Session 全部 · 用途 全部 · 工具身份 全部 · 精确 Run 全部
    - paragraph: 计算时刻 2026-10-11T03:19:26Z · 有效至 2026-10-11T03:34:26Z
    - group: 快照与价格身份
  - paragraph: 工具筛选展示包含该工具的完整 Run；模型 USD 与工具服务／单位分列，不能归因给单一工具。
  - region "账目汇总":
    - heading "分项汇总" [level=2]
    - paragraph: Run 1 · 模型 Attempt 4 · 账目覆盖不足 Run 0
    - paragraph: 精确费用 USD 0.500 · 估算费用 USD 0 · 费用未知 Attempt 0
    - paragraph: 工具请求 2 · 已确认启动 2 · 明确未启动 0 · 启动未确认 0
    - paragraph: 精确 Attempt 4 · 估算 Attempt 0 · 使用陈旧价格 0 · 涉及阶梯价 0
    - paragraph: 估算价格来源：无
    - paragraph: 工具计量状态：不计费 2 · 已报告计量 0 · 结果未知，请核验原操作 0 · 历史未记录 0
    - group: Token 用量与缺失覆盖
    - paragraph: 仅统计持久 Run 与可读账目；无 Run 的旧消息不计入。账目覆盖不证明正式回复已保存，完整记录状态请进入运行过程核对。
  - region "Run 账目索引":
    - table "Run 账目索引":
      - caption: Run 账目索引
      - rowgroup:
        - row "Run / Session 用途与状态 归属时间 账目与过程覆盖 操作":
          - columnheader "Run / Session"
          - columnheader "用途与状态"
          - columnheader "归属时间"
          - columnheader "账目与过程覆盖"
          - columnheader "操作"
      - rowgroup:
        - row "0fa442387f104b6191df730797db0390 / 8303911316ad4a8285965de247849b97 普通聊天 · finished · completed 2026-10-11T03:19:26Z（开始时间） 账目覆盖无已报告缺口 · 未报告过程缺口 查看账目 0fa442387f104b6191df730797db0390":
          - cell "0fa442387f104b6191df730797db0390 / 8303911316ad4a8285965de247849b97"
          - cell "普通聊天 · finished · completed"
          - cell "2026-10-11T03:19:26Z（开始时间）"
          - cell "账目覆盖无已报告缺口 · 未报告过程缺口"
          - cell "查看账目 0fa442387f104b6191df730797db0390":
            - button "查看账目 0fa442387f104b6191df730797db0390"
  - region "运行账目明细":
    - heading "Run 0fa442387f104b6191df730797db0390" [level=2]
    - link "进入运行过程（保留账目快照）":
      - /url: /runs/0fa442387f104b6191df730797db0390?ops_timezone=Asia%2FShanghai&ops_range=custom&ops_start=2026-10-05&ops_end=2026-10-12&snapshot_id=23bcb85cbb644a479a9382a6824fead0
    - paragraph: 所属 snapshot_id 23bcb85cbb644a479a9382a6824fead0
    - paragraph: 未报告过程缺口
    - region "模型 Attempt":
      - table "模型 Attempt":
        - caption: 模型 Attempt
        - rowgroup:
          - row "Attempt 模型身份 结果 费用 用量摘要":
            - columnheader "Attempt"
            - columnheader "模型身份"
            - columnheader "结果"
            - columnheader "费用"
            - columnheader "用量摘要"
        - rowgroup:
          - row "8503a9c83a4646c5a4786211b83d82c0 opencode-go / deepseek-v4-flash committed 精确费用 USD 0.125 输入总量 未报告 · 输出 4":
            - cell "8503a9c83a4646c5a4786211b83d82c0"
            - cell "opencode-go / deepseek-v4-flash"
            - cell "committed"
            - cell "精确费用 USD 0.125"
            - cell "输入总量 未报告 · 输出 4"
          - row "a6d219af6823416e862069998bced128 opencode-go / deepseek-v4-flash committed 精确费用 USD 0.125 输入总量 未报告 · 输出 4":
            - cell "a6d219af6823416e862069998bced128"
            - cell "opencode-go / deepseek-v4-flash"
            - cell "committed"
            - cell "精确费用 USD 0.125"
            - cell "输入总量 未报告 · 输出 4"
          - row "4f6918fde3434ad8abfda844ba2b48e5 opencode-go / deepseek-v4-flash committed 精确费用 USD 0.125 输入总量 未报告 · 输出 4":
            - cell "4f6918fde3434ad8abfda844ba2b48e5"
            - cell "opencode-go / deepseek-v4-flash"
            - cell "committed"
            - cell "精确费用 USD 0.125"
            - cell "输入总量 未报告 · 输出 4"
          - row "2034abffe26f4f2cad99189c3857858f opencode-go / deepseek-v4-flash committed 精确费用 USD 0.125 输入总量 未报告 · 输出 4":
            - cell "2034abffe26f4f2cad99189c3857858f"
            - cell "opencode-go / deepseek-v4-flash"
            - cell "committed"
            - cell "精确费用 USD 0.125"
            - cell "输入总量 未报告 · 输出 4"
    - group: Token 与四维价格：8503a9c83a4646c5a4786211b83d82c0
    - group: Token 与四维价格：a6d219af6823416e862069998bced128
    - group: Token 与四维价格：4f6918fde3434ad8abfda844ba2b48e5
    - group: Token 与四维价格：2034abffe26f4f2cad99189c3857858f
    - article:
      - heading "create_event · browser-create" [level=3]
      - paragraph: 当前已注册 · builtin / create_event
      - paragraph: 当次结果：已确认启动 · 成功 ·
      - paragraph: 工具计量 不计费 · 保存投影不证明模型已收到
      - button "展开模型结果投影"
      - button "完整脱敏审计"
      - button "模型提交参数（脱敏）"
      - button "核验原操作当前结果"
      - region "当前核验":
        - heading "当前核验（独立当前读数）" [level=4]
        - paragraph: 状态 历史未记录 · 读取时刻 2026-10-11T03:19:26Z
        - paragraph: 操作 5ed7ed949b4258128a8a971c29f2a339 · 核验时刻 未记录 · 证据来源 未记录
    - article:
      - heading "query_events · browser-query" [level=3]
      - paragraph: 当前已注册 · builtin / query_events
      - paragraph: 当次结果：已确认启动 · 成功 ·
      - paragraph: 工具计量 不计费 · 保存投影不证明模型已收到
      - button "展开模型结果投影"
      - button "完整脱敏审计"
      - button "模型提交参数（脱敏）"
      - button "核验原操作当前结果"
    - paragraph: model · 字节 [0, 30) / 30 · 人工历史，只保留当前段
    - text: "{\"id\": 1, \"status\": \"created\"}"
    - button "下一段" [disabled]
- region "MainBar":
  - heading "主对话" [level=2]
  - button "收起主对话"
  - text: 会话
  - button "新建会话"
  - region "主对话":
    - article:
      - paragraph: 创建工具测试日程
      - paragraph: "已查询到工具测试日程 系统操作回执： {\"id\": 1, \"status\": \"created\"}"
      - text: 已保存
  - text: 消息
  - textbox "消息":
    - /placeholder: 写下消息；/skills 指定流程…
  - button "发送" [disabled]
  - paragraph: Enter 发送 · Shift+Enter 换行
- status: 就绪
- alert
```

# Test source

```ts
  29  | import {memoryServer} from './memory-server.js';
  30  | 
  31  | test('A23: refresh cannot accept another page from the previous snapshot', async ({page}) => {
  32  |   const server = await fixture();
  33  |   let release; const gate = new Promise(resolve => {release=resolve;});
  34  |   try {
  35  |     await server.send('bulk'); await page.goto(server.origin+'/ops');
  36  |     await expect(page.getByRole('button',{name:/查看账目 /})).toHaveCount(50);
  37  |     await page.route('**/api/ops/snapshots',async route => {const response=await route.fetch(); await gate; await route.fulfill({response});});
  38  |     await page.getByRole('button',{name:'刷新账目'}).click();
  39  |     await expect(page.getByRole('button',{name:'下一页',exact:true})).toBeDisabled();
  40  |     release();
  41  |     await expect(page.getByText('固定账目快照；后台变化后请显式刷新。')).toBeVisible();
  42  |     await page.getByRole('button',{name:'下一页',exact:true}).click();
  43  |     await expect(page.getByRole('button',{name:/查看账目 /})).toHaveCount(55);
  44  |   } finally {release(); await server.close();}
  45  | });
  46  | 
  47  | test('A06: a late successful authorization receipt does not replace newer pending state', async ({page,context}) => {
  48  |   const server=await fixture(), other=await context.newPage();
  49  |   let release, saved; const gate=new Promise(resolve=>{release=resolve;});
  50  |   const persisted=new Promise(resolve=>{saved=resolve;});
  51  |   try {
  52  |     await page.goto(server.origin+'/tools');
  53  |     await externalCard(page).getByRole('button',{name:'展开详情',exact:true}).click();
  54  |     await page.route('**/api/tools/authorization',async route=>{const response=await route.fetch(); saved(); await gate; await route.fulfill({response});});
  55  |     await externalCard(page).getByLabel('external_fixture 授权草稿').selectOption('allowed');
  56  |     await externalCard(page).getByRole('button',{name:'保存授权',exact:true}).click(); await persisted;
  57  |     await other.goto(server.origin+'/tools');
  58  |     await externalCard(other).getByRole('button',{name:'展开详情',exact:true}).click();
  59  |     await server.send('apply-fail');
  60  |     await externalCard(other).getByLabel('external_fixture 授权草稿').selectOption('denied');
  61  |     await externalCard(other).getByRole('button',{name:'保存授权',exact:true}).click();
  62  |     await expect(other.getByText(/生效：pending/)).toBeVisible(); release();
  63  |     await expect(page.getByText(/生效：pending/)).toBeVisible();
  64  |     await expect(page.getByText(/授权已生效/)).toHaveCount(0);
  65  |     await expect(externalCard(page).getByLabel('external_fixture 授权草稿')).toHaveValue('allowed');
  66  |   } finally {release(); await other.close(); await server.close();}
  67  | });
  68  | 
  69  | async function fixture() {return memoryServer({script:'tests/browser/ops_server.py'});}
  70  | const externalCard = page => page.locator('article').filter({has:page.getByRole('heading',{name:'external_fixture',exact:true})});
  71  | 
  72  | test('A04 A05 A06 A08: two tabs keep drafts, reject busy, and distinguish lost receipt from application', async ({page,context}) => {
  73  |   const server=await fixture(); const other=await context.newPage();
  74  |   try {
  75  |     await page.goto(server.origin+'/tools'); await other.goto(server.origin+'/tools');
  76  |     await externalCard(page).getByRole('button',{name:'展开详情',exact:true}).click();
  77  |     await externalCard(other).getByRole('button',{name:'展开详情',exact:true}).click();
  78  |     const card=externalCard(page), second=externalCard(other);
  79  |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  80  |     await second.getByLabel('external_fixture 授权草稿').selectOption('denied');
  81  |     await server.send('busy');
  82  |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  83  |     await expect(page.getByText(/保存未完成：mutation_in_flight/)).toBeVisible();
  84  |     await server.send('idle');
  85  |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  86  |     await expect(card).toContainText('服务端当前保存值：allowed');
  87  |     await other.getByRole('button',{name:'核对当前授权'}).click();
  88  |     await expect(second).toContainText('草稿基于版本 0');
  89  |     await second.getByRole('button',{name:'保存授权',exact:true}).click();
  90  |     await expect(other.getByText(/authorization_conflict/)).toBeVisible();
  91  |     await expect(second.getByLabel('external_fixture 授权草稿')).toHaveValue('denied');
  92  |     await second.getByRole('button',{name:'基于当前版本继续编辑'}).click();
  93  |     let posts=0;
  94  |     await other.route('**/api/tools/authorization',async route => {posts++; await route.fetch(); await route.abort('failed');});
  95  |     await second.getByRole('button',{name:'保存授权',exact:true}).click();
  96  |     await expect(other.getByText(/提交结果尚未确认/)).toBeVisible();
  97  |     await expect(second).toContainText('服务端当前保存值：denied'); expect(posts).toBe(1);
  98  |     await other.unroute('**/api/tools/authorization');
  99  |     await page.getByRole('button',{name:'核对当前授权'}).click();
  100 |     await expect(card).toContainText('服务端当前保存值：denied');
  101 |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  102 |     await server.send('apply-fail');
  103 |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  104 |     await expect(page.getByText(/已保存，尚未生效/)).toBeVisible();
  105 |     await expect(card).toContainText('authorization_not_applied');
  106 |     await server.send('apply-heal');
  107 |     await page.getByRole('button',{name:'重新应用已保存授权'}).click();
  108 |     await expect(card).toContainText('模型暴露：real');
  109 |   } finally {await other.close(); await server.close();}
  110 | });
  111 | 
  112 | test('A24 A32 A33: snapshot expiry, offline body, reconnect prune and page cleanup', async ({page,context}) => {
  113 |   const server=await fixture();
  114 |   try {
  115 |     await page.goto(server.origin+'/inbox');
  116 |     await page.getByRole('button',{name:'新建会话',exact:true}).click();
  117 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  118 |     await page.getByLabel('消息',{exact:true}).fill('创建工具测试日程');
  119 |     await page.getByRole('button',{name:'发送',exact:true}).click();
  120 |     await expect(page.getByRole('region',{name:'主对话'})).toContainText('已查询到工具测试日程');
  121 |     await page.getByRole('link',{name:'用量账本',exact:true}).click();
  122 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  123 |     await page.getByRole('button',{name:'展开模型结果投影'}).first().click();
  124 |     const preview=page.getByLabel('历史正文当前段');
  125 |     await expect(preview).toContainText('created');
  126 |     await page.getByRole('button',{name:'核验原操作当前结果',exact:true}).first().click();
  127 |     await expect(page.getByText(/当前核验（独立当前读数）/)).toHaveCount(1);
  128 |     await context.setOffline(true);
> 129 |     await expect(page.getByText(/离线副本/)).toBeVisible();
      |                                          ^ Error: expect(locator).toBeVisible() failed
  130 |     await expect(preview).toContainText('created');
  131 |     await server.send('prune');
  132 |     await context.setOffline(false);
  133 |     await expect(page.getByText(/历史不可读：trace_pruned/)).toBeVisible();
  134 |     await expect(preview).toBeEmpty();
  135 |     await page.getByRole('button',{name:'核验原操作当前结果',exact:true}).first().click();
  136 |     await expect(page.getByText(/当前核验（独立当前读数）/)).toHaveCount(2);
  137 |     await server.send('expire');
  138 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  139 |     await expect(page.getByText(/旧快照已失效/)).toBeVisible();
  140 |     await expect(page.getByLabel('账目汇总')).toContainText('Run 1');
  141 |     await page.getByRole('button',{name:'刷新账目'}).click();
  142 |     await expect(page.getByText('固定账目快照；后台变化后请显式刷新。')).toBeVisible();
  143 |   } finally {await context.setOffline(false); await server.close();}
  144 | });
  145 | 
  146 | import {writeFile} from 'node:fs/promises';
  147 | import {join} from 'node:path';
  148 | 
  149 | for (const trigger of ['focus', 'reconnect']) test(`A07: ${trigger} detects malformed authorization without claiming applied`, async ({page, context}) => {
  150 |   const server = await fixture();
  151 |   try {
  152 |     await page.goto(server.origin+'/tools');
  153 |     const card = externalCard(page);
  154 |     await card.getByRole('button',{name:'展开详情',exact:true}).click();
  155 |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  156 |     await card.getByRole('button', {name:'保存授权',exact:true}).click();
  157 |     await expect(card).toContainText('模型暴露：real');
  158 |     if (trigger === 'reconnect') {
  159 |       await context.setOffline(true);
  160 |       await expect(page.getByText(/离线，当前生效状态待核验/)).toBeVisible();
  161 |     }
  162 |     await writeFile(join(server.directory, 'tool_authorizations.json'), 'broken after load');
  163 |     if (trigger === 'focus') await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  164 |     else await context.setOffline(false);
  165 |     await expect(page.getByText(/配置：authorization_unreadable/)).toBeVisible();
  166 |     await expect(page.getByText(/生效：pending/)).toBeVisible();
  167 |     await expect(card).toContainText('模型暴露：hidden');
  168 |     await expect(card.getByRole('button', {name:'保存授权',exact:true})).toBeDisabled();
  169 |   } finally {await context.setOffline(false); await server.close();}
  170 | });
  171 | 
  172 | test('A23 A24: expired Ops to Run snapshot has explicit refresh preserving normalized filters', async ({page}) => {
  173 |   const server = await fixture();
  174 |   try {
  175 |     await page.goto(server.origin+'/inbox');
  176 |     await page.getByRole('button', {name:'新建会话',exact:true}).click();
  177 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  178 |     await page.getByLabel('消息', {exact:true}).fill('创建工具测试日程');
  179 |     await page.getByRole('button', {name:'发送',exact:true}).click();
  180 |     await expect(page.getByRole('region', {name:'主对话'})).toContainText('已查询到工具测试日程');
  181 |     await page.getByRole('link', {name:'工具',exact:true}).click();
  182 |     await page.locator('article').filter({has:page.getByRole('heading',{name:'create_event',exact:true})})
  183 |       .getByRole('link',{name:'查看包含该工具的运行'}).click();
  184 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  185 |     let href = await page.getByRole('link', {name:'进入运行过程（保留账目快照）'}).getAttribute('href');
  186 |     const oldSnapshot = new URL(href, server.origin).searchParams.get('snapshot_id');
  187 |     const before = await (await page.request.get(server.origin+'/api/ops?snapshot_id='+oldSnapshot)).json();
  188 |     const runId = before.runs[0].run_id;
  189 |     // Use every filter, then edit a draft without submitting it: the Run link
  190 |     // must carry the normalized snapshot filters, never these unsaved controls.
  191 |     await page.getByLabel('时间范围',{exact:true}).selectOption('custom');
  192 |     await page.getByLabel('IANA 时区',{exact:true}).fill('America/New_York');
  193 |     await page.getByLabel('开始日期（含）',{exact:true}).fill('2020-01-01');
  194 |     await page.getByLabel('结束日期（不含）',{exact:true}).fill('2030-01-01');
  195 |     await page.getByLabel('会话 ID',{exact:true}).fill(before.runs[0].session_id);
  196 |     await page.getByLabel('运行用途',{exact:true}).selectOption('chat');
  197 |     await page.getByLabel('Run ID',{exact:true}).fill(runId);
  198 |     const refreshed = page.waitForResponse(r => r.url().endsWith('/api/ops/snapshots'));
  199 |     await page.getByRole('button',{name:'刷新账目',exact:true}).click();
  200 |     const fixed = await (await refreshed).json();
  201 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  202 |     const link = page.getByRole('link',{name:'进入运行过程（保留账目快照）'});
  203 |     await expect(link).toBeVisible();
  204 |     await page.getByLabel('工具身份',{exact:true}).fill('unsaved-draft');
  205 |     await server.send('expire');
  206 |     const failedRead = page.waitForResponse(r => r.url().includes('/api/run-evidence?'));
  207 |     await link.click();
  208 |     expect((await failedRead).status()).toBe(410);
  209 |     await expect(page.getByText('账目快照已失效；尚未核验当前过程记录。',{exact:true})).toBeVisible();
  210 |     await expect(page.getByText('过程记录不可用',{exact:true})).toHaveCount(0);
  211 |     const ordinary = await page.request.get(server.origin+'/api/run-evidence?run_id='+runId);
  212 |     expect(ordinary.status()).toBe(200);
  213 |     expect((await ordinary.json()).trace_status).toBe('available');
  214 |     let snapshots = 0;
  215 |     page.on('request', r => {if (r.url().endsWith('/api/ops/snapshots')) snapshots++;});
  216 |     await page.getByRole('link',{name:'返回账本核对筛选并刷新',exact:true}).click();
  217 |     await expect(page.getByText('账目快照已失效；已保留原筛选，请显式刷新。',{exact:true})).toBeVisible();
  218 |     await expect(page.getByLabel('工具身份',{exact:true})).toHaveValue(fixed.filters.tool);
  219 |     await expect(page.getByLabel('会话 ID',{exact:true})).toHaveValue(fixed.filters.session_id);
  220 |     await expect(page.getByLabel('运行用途',{exact:true})).toHaveValue('chat');
  221 |     await expect(page.getByLabel('Run ID',{exact:true})).toHaveValue(runId);
  222 |     await expect(page.getByLabel('开始日期（含）',{exact:true})).toHaveValue('2020-01-01');
  223 |     expect(snapshots).toBe(0);
  224 |     const newRead = page.waitForResponse(r => r.url().endsWith('/api/ops/snapshots'));
  225 |     await page.getByRole('button',{name:'刷新账目',exact:true}).click();
  226 |     const renewed = await (await newRead).json();
  227 |     expect(renewed.filters).toEqual(fixed.filters);
  228 |     expect(renewed.snapshot_id).not.toBe(fixed.snapshot_id);
  229 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
```