# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accounting.spec.js >> A07: reconnect detects malformed authorization without claiming applied
- Location: tests/browser/accounting.spec.js:149:47

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/离线，当前生效状态待核验/)
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/离线，当前生效状态待核验/) with timeout 4000ms
  - waiting for getByText(/离线，当前生效状态待核验/)

```

```yaml
- banner "导航面板":
  - link "Agent-Alfred 本地助手":
    - /url: /overview
  - navigation "主导航":
    - paragraph: 工作区
    - link "总览":
      - /url: /overview
    - link "收件箱":
      - /url: /inbox
    - link "运行":
      - /url: /runs
    - link "记忆":
      - /url: /memory
    - paragraph: Agent 配置
    - link "模型":
      - /url: /models
    - link "连接":
      - /url: /connections
    - link "行为":
      - /url: /behaviour
    - link "工具":
      - /url: /tools
    - paragraph: 诊断
    - link "用量账本":
      - /url: /ops
    - link "数据库":
      - /url: /database
  - paragraph: 本地优先 · 共享运行宿主
- button "打开主对话" [expanded]
- region "运行与连接摘要":
  - paragraph: 尚未选择会话
- main:
  - heading "工具" [level=1]
  - paragraph: 配置：ok · 保存版本 1 · 生效：applied
  - status: 当前目录已核对；连接观测、保存与生效分别显示。
  - status
  - paragraph: MCP 目录：未配置服务器
  - button "核对当前授权"
  - button "重新应用已保存授权"
  - link "连接、凭据与 MCP 维护":
    - /url: /connections
  - paragraph: 从 MainBar 明确提出工具请求；本页查看来源、能力和授权。人格 read_persona / update_persona 保留完整版本、覆盖限制与冲突，修改从下一 Run 生效。
  - region "内置工具":
    - heading "内置工具" [level=2]
    - paragraph: builtin
    - paragraph
    - article:
      - heading "create_event" [level=3]
      - paragraph: 来源 builtin · 能力 create_event
      - paragraph: Create a local calendar entry; time requires UTC offset.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22create_event%22%5D
    - article:
      - heading "create_skill" [level=3]
      - paragraph: 来源 builtin · 能力 create_skill
      - paragraph: Create a new user Skill; requires restart to load. Existing user names are protected; builtin overrides need user confirmation.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22create_skill%22%5D
    - article:
      - heading "delete_memory" [level=3]
      - paragraph: 来源 builtin · 能力 delete_memory
      - paragraph: Delete one explicit memory ID and version.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22delete_memory%22%5D
    - article:
      - heading "draft_message" [level=3]
      - paragraph: 来源 builtin · 能力 draft_message
      - paragraph: Create a local Markdown draft; never send it.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22draft_message%22%5D
    - article:
      - heading "get_memory" [level=3]
      - paragraph: 来源 builtin · 能力 get_memory
      - paragraph: Read one memory and its current version.
      - paragraph: 副作用：local_read · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22get_memory%22%5D
    - article:
      - heading "query_events" [level=3]
      - paragraph: 来源 builtin · 能力 query_events
      - paragraph: Query local calendar entries by absolute time.
      - paragraph: 副作用：local_read · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22query_events%22%5D
    - article:
      - heading "query_memory" [level=3]
      - paragraph: 来源 builtin · 能力 query_memory
      - paragraph: Find explicit memory targets; clarify ambiguous matches.
      - paragraph: 副作用：local_read · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22query_memory%22%5D
    - article:
      - heading "read_persona" [level=3]
      - paragraph: 来源 builtin · 能力 read_persona
      - paragraph: Read the complete effective persona and its version.
      - paragraph: 副作用：local_read · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22read_persona%22%5D
    - article:
      - heading "save_fact" [level=3]
      - paragraph: 来源 builtin · 能力 save_fact
      - paragraph: Save a fact only when the user explicitly asks to save it.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22save_fact%22%5D
    - article:
      - heading "update_memory" [level=3]
      - paragraph: 来源 builtin · 能力 update_memory
      - paragraph: Update one memory using its observed version.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22update_memory%22%5D
    - article:
      - heading "update_persona" [level=3]
      - paragraph: 来源 builtin · 能力 update_persona
      - paragraph: Replace the managed persona using the read version. Preserve instructions the user did not ask to change. Next Run applies it.
      - paragraph: 副作用：local_write · 可用性：configured
      - paragraph: 本地工具，不需要外部授权
      - paragraph: 授权：不适用
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22builtin%22%2C%22update_persona%22%5D
  - region "集成 · tavily":
    - heading "集成 · tavily" [level=2]
    - paragraph: tavily
    - paragraph
    - article:
      - heading "web_search" [level=3]
      - paragraph: 来源 tavily · 能力 web_search
      - paragraph: 搜索网络并返回外部来源标题、链接与片段。
      - paragraph: 副作用：external · 可用性：unconfigured
      - paragraph: 连接观测：unconfigured
      - paragraph: 已保存授权：unset · 实际应用：applied
      - paragraph: 模型暴露：guidance
      - paragraph: 阻止原因：configuration_required
      - button "展开详情"
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22tavily%22%2C%22web_search%22%5D
      - link "连接维护":
        - /url: /connections
  - region "未知来源 · test-service":
    - heading "未知来源 · test-service" [level=2]
    - paragraph: test-service
    - paragraph
    - article:
      - heading "external_fixture" [level=3]
      - paragraph: 来源 test-service · 能力 test-capability
      - paragraph: Browser fixture only
      - paragraph: 副作用：external · 可用性：configured
      - paragraph: 连接观测：unverified
      - paragraph: 已保存授权：allowed · 实际应用：applied
      - paragraph: 模型暴露：real
      - paragraph: 阻止原因：无已报告阻止原因
      - paragraph: 服务端确认操作，授权已生效。
      - button "收起详情" [expanded]
      - link "查看包含该工具的运行":
        - /url: /ops?tool=%5B%22test-service%22%2C%22test-capability%22%5D
      - link "连接维护":
        - /url: /connections
      - paragraph: 完整能力身份：["test-service","test-capability"]；完整来源：test-service；能力：test-capability
      - paragraph: Browser fixture only
      - paragraph: 来源以注册身份为准，不按名称或描述推断。
      - paragraph: 连接观测：未提供独立时间／方式；不推断认证成功。
      - paragraph: 服务端当前保存值：allowed · 保存版本 1
      - text: 授权草稿
      - combobox "external_fixture 授权草稿":
        - option "未决定"
        - option "允许" [selected]
        - option "拒绝"
      - button "保存授权"
- region "MainBar":
  - heading "主对话" [level=2]
  - button "收起主对话"
  - text: 尚未选择会话
  - button "新建会话"
  - region "主对话"
  - text: 消息
  - textbox "消息" [disabled]:
    - /placeholder: 写下消息；/skills 指定流程…
  - button "发送" [disabled]
  - paragraph: 请显式新建或继续会话。
- status: 就绪
- alert
```

# Test source

```ts
  60  |     await externalCard(other).getByLabel('external_fixture 授权草稿').selectOption('denied');
  61  |     await externalCard(other).getByRole('button',{name:'保存授权',exact:true}).click();
  62  |     await expect(other.getByText(/生效：pending/)).toBeVisible(); release();
  63  |     await expect(page.getByText(/生效：pending/)).toBeVisible();
  64  |     await expect(page.getByText(/授权已生效/)).toHaveCount(0);
  65  |     await expect(externalCard(page).getByLabel('external_fixture 授权草稿')).toHaveValue('allowed');
  66  |   } finally {release(); await other.close(); await server.close();}
  67  | });
  68  | 
  69  | async function fixture() {return memoryServer({script:'tests/browser/ops_server.py'});}
  70  | const externalCard = page => page.locator('article').filter({has:page.getByRole('heading',{name:'external_fixture',exact:true})});
  71  | 
  72  | test('A04 A05 A06 A08: two tabs keep drafts, reject busy, and distinguish lost receipt from application', async ({page,context}) => {
  73  |   const server=await fixture(); const other=await context.newPage();
  74  |   try {
  75  |     await page.goto(server.origin+'/tools'); await other.goto(server.origin+'/tools');
  76  |     await externalCard(page).getByRole('button',{name:'展开详情',exact:true}).click();
  77  |     await externalCard(other).getByRole('button',{name:'展开详情',exact:true}).click();
  78  |     const card=externalCard(page), second=externalCard(other);
  79  |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  80  |     await second.getByLabel('external_fixture 授权草稿').selectOption('denied');
  81  |     await server.send('busy');
  82  |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  83  |     await expect(page.getByText(/保存未完成：mutation_in_flight/)).toBeVisible();
  84  |     await server.send('idle');
  85  |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  86  |     await expect(card).toContainText('服务端当前保存值：allowed');
  87  |     await other.getByRole('button',{name:'核对当前授权'}).click();
  88  |     await expect(second).toContainText('草稿基于版本 0');
  89  |     await second.getByRole('button',{name:'保存授权',exact:true}).click();
  90  |     await expect(other.getByText(/authorization_conflict/)).toBeVisible();
  91  |     await expect(second.getByLabel('external_fixture 授权草稿')).toHaveValue('denied');
  92  |     await second.getByRole('button',{name:'基于当前版本继续编辑'}).click();
  93  |     let posts=0;
  94  |     await other.route('**/api/tools/authorization',async route => {posts++; await route.fetch(); await route.abort('failed');});
  95  |     await second.getByRole('button',{name:'保存授权',exact:true}).click();
  96  |     await expect(other.getByText(/提交结果尚未确认/)).toBeVisible();
  97  |     await expect(second).toContainText('服务端当前保存值：denied'); expect(posts).toBe(1);
  98  |     await other.unroute('**/api/tools/authorization');
  99  |     await page.getByRole('button',{name:'核对当前授权'}).click();
  100 |     await expect(card).toContainText('服务端当前保存值：denied');
  101 |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  102 |     await server.send('apply-fail');
  103 |     await card.getByRole('button',{name:'保存授权',exact:true}).click();
  104 |     await expect(page.getByText(/已保存，尚未生效/)).toBeVisible();
  105 |     await expect(card).toContainText('authorization_not_applied');
  106 |     await server.send('apply-heal');
  107 |     await page.getByRole('button',{name:'重新应用已保存授权'}).click();
  108 |     await expect(card).toContainText('模型暴露：real');
  109 |   } finally {await other.close(); await server.close();}
  110 | });
  111 | 
  112 | test('A24 A32 A33: snapshot expiry, offline body, reconnect prune and page cleanup', async ({page,context}) => {
  113 |   const server=await fixture();
  114 |   try {
  115 |     await page.goto(server.origin+'/inbox');
  116 |     await page.getByRole('button',{name:'新建会话',exact:true}).click();
  117 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  118 |     await page.getByLabel('消息',{exact:true}).fill('创建工具测试日程');
  119 |     await page.getByRole('button',{name:'发送',exact:true}).click();
  120 |     await expect(page.getByRole('region',{name:'主对话'})).toContainText('已查询到工具测试日程');
  121 |     await page.getByRole('link',{name:'用量账本',exact:true}).click();
  122 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  123 |     await page.getByRole('button',{name:'展开模型结果投影'}).first().click();
  124 |     const preview=page.getByLabel('历史正文当前段');
  125 |     await expect(preview).toContainText('created');
  126 |     await page.getByRole('button',{name:'核验原操作当前结果',exact:true}).first().click();
  127 |     await expect(page.getByText(/当前核验（独立当前读数）/)).toHaveCount(1);
  128 |     await context.setOffline(true);
  129 |     await expect(page.getByText(/离线副本/)).toBeVisible();
  130 |     await expect(preview).toContainText('created');
  131 |     await server.send('prune');
  132 |     await context.setOffline(false);
  133 |     await expect(page.getByText(/历史不可读：trace_pruned/)).toBeVisible();
  134 |     await expect(preview).toBeEmpty();
  135 |     await page.getByRole('button',{name:'核验原操作当前结果',exact:true}).first().click();
  136 |     await expect(page.getByText(/当前核验（独立当前读数）/)).toHaveCount(2);
  137 |     await server.send('expire');
  138 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  139 |     await expect(page.getByText(/旧快照已失效/)).toBeVisible();
  140 |     await expect(page.getByLabel('账目汇总')).toContainText('Run 1');
  141 |     await page.getByRole('button',{name:'刷新账目'}).click();
  142 |     await expect(page.getByText('固定账目快照；后台变化后请显式刷新。')).toBeVisible();
  143 |   } finally {await context.setOffline(false); await server.close();}
  144 | });
  145 | 
  146 | import {writeFile} from 'node:fs/promises';
  147 | import {join} from 'node:path';
  148 | 
  149 | for (const trigger of ['focus', 'reconnect']) test(`A07: ${trigger} detects malformed authorization without claiming applied`, async ({page, context}) => {
  150 |   const server = await fixture();
  151 |   try {
  152 |     await page.goto(server.origin+'/tools');
  153 |     const card = externalCard(page);
  154 |     await card.getByRole('button',{name:'展开详情',exact:true}).click();
  155 |     await card.getByLabel('external_fixture 授权草稿').selectOption('allowed');
  156 |     await card.getByRole('button', {name:'保存授权',exact:true}).click();
  157 |     await expect(card).toContainText('模型暴露：real');
  158 |     if (trigger === 'reconnect') {
  159 |       await context.setOffline(true);
> 160 |       await expect(page.getByText(/离线，当前生效状态待核验/)).toBeVisible();
      |                                                    ^ Error: expect(locator).toBeVisible() failed
  161 |     }
  162 |     await writeFile(join(server.directory, 'tool_authorizations.json'), 'broken after load');
  163 |     if (trigger === 'focus') await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  164 |     else await context.setOffline(false);
  165 |     await expect(page.getByText(/配置：authorization_unreadable/)).toBeVisible();
  166 |     await expect(page.getByText(/生效：pending/)).toBeVisible();
  167 |     await expect(card).toContainText('模型暴露：hidden');
  168 |     await expect(card.getByRole('button', {name:'保存授权',exact:true})).toBeDisabled();
  169 |   } finally {await context.setOffline(false); await server.close();}
  170 | });
  171 | 
  172 | test('A23 A24: expired Ops to Run snapshot has explicit refresh preserving normalized filters', async ({page}) => {
  173 |   const server = await fixture();
  174 |   try {
  175 |     await page.goto(server.origin+'/inbox');
  176 |     await page.getByRole('button', {name:'新建会话',exact:true}).click();
  177 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  178 |     await page.getByLabel('消息', {exact:true}).fill('创建工具测试日程');
  179 |     await page.getByRole('button', {name:'发送',exact:true}).click();
  180 |     await expect(page.getByRole('region', {name:'主对话'})).toContainText('已查询到工具测试日程');
  181 |     await page.getByRole('link', {name:'工具',exact:true}).click();
  182 |     await page.locator('article').filter({has:page.getByRole('heading',{name:'create_event',exact:true})})
  183 |       .getByRole('link',{name:'查看包含该工具的运行'}).click();
  184 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  185 |     let href = await page.getByRole('link', {name:'进入运行过程（保留账目快照）'}).getAttribute('href');
  186 |     const oldSnapshot = new URL(href, server.origin).searchParams.get('snapshot_id');
  187 |     const before = await (await page.request.get(server.origin+'/api/ops?snapshot_id='+oldSnapshot)).json();
  188 |     const runId = before.runs[0].run_id;
  189 |     // Use every filter, then edit a draft without submitting it: the Run link
  190 |     // must carry the normalized snapshot filters, never these unsaved controls.
  191 |     await page.getByLabel('时间范围',{exact:true}).selectOption('custom');
  192 |     await page.getByLabel('IANA 时区',{exact:true}).fill('America/New_York');
  193 |     await page.getByLabel('开始日期（含）',{exact:true}).fill('2020-01-01');
  194 |     await page.getByLabel('结束日期（不含）',{exact:true}).fill('2030-01-01');
  195 |     await page.getByLabel('会话 ID',{exact:true}).fill(before.runs[0].session_id);
  196 |     await page.getByLabel('运行用途',{exact:true}).selectOption('chat');
  197 |     await page.getByLabel('Run ID',{exact:true}).fill(runId);
  198 |     const refreshed = page.waitForResponse(r => r.url().endsWith('/api/ops/snapshots'));
  199 |     await page.getByRole('button',{name:'刷新账目',exact:true}).click();
  200 |     const fixed = await (await refreshed).json();
  201 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  202 |     const link = page.getByRole('link',{name:'进入运行过程（保留账目快照）'});
  203 |     await expect(link).toBeVisible();
  204 |     await page.getByLabel('工具身份',{exact:true}).fill('unsaved-draft');
  205 |     await server.send('expire');
  206 |     const failedRead = page.waitForResponse(r => r.url().includes('/api/run-evidence?'));
  207 |     await link.click();
  208 |     expect((await failedRead).status()).toBe(410);
  209 |     await expect(page.getByText('账目快照已失效；尚未核验当前过程记录。',{exact:true})).toBeVisible();
  210 |     await expect(page.getByText('过程记录不可用',{exact:true})).toHaveCount(0);
  211 |     const ordinary = await page.request.get(server.origin+'/api/run-evidence?run_id='+runId);
  212 |     expect(ordinary.status()).toBe(200);
  213 |     expect((await ordinary.json()).trace_status).toBe('available');
  214 |     let snapshots = 0;
  215 |     page.on('request', r => {if (r.url().endsWith('/api/ops/snapshots')) snapshots++;});
  216 |     await page.getByRole('link',{name:'返回账本核对筛选并刷新',exact:true}).click();
  217 |     await expect(page.getByText('账目快照已失效；已保留原筛选，请显式刷新。',{exact:true})).toBeVisible();
  218 |     await expect(page.getByLabel('工具身份',{exact:true})).toHaveValue(fixed.filters.tool);
  219 |     await expect(page.getByLabel('会话 ID',{exact:true})).toHaveValue(fixed.filters.session_id);
  220 |     await expect(page.getByLabel('运行用途',{exact:true})).toHaveValue('chat');
  221 |     await expect(page.getByLabel('Run ID',{exact:true})).toHaveValue(runId);
  222 |     await expect(page.getByLabel('开始日期（含）',{exact:true})).toHaveValue('2020-01-01');
  223 |     expect(snapshots).toBe(0);
  224 |     const newRead = page.waitForResponse(r => r.url().endsWith('/api/ops/snapshots'));
  225 |     await page.getByRole('button',{name:'刷新账目',exact:true}).click();
  226 |     const renewed = await (await newRead).json();
  227 |     expect(renewed.filters).toEqual(fixed.filters);
  228 |     expect(renewed.snapshot_id).not.toBe(fixed.snapshot_id);
  229 |     await page.getByRole('button',{name:/查看账目 /}).first().click();
  230 |     const evidenceRead = page.waitForResponse(r => r.url().includes('/api/run-evidence?'));
  231 |     await page.getByRole('link',{name:'进入运行过程（保留账目快照）'}).click();
  232 |     const response = await evidenceRead;
  233 |     expect(response.status()).toBe(200);
  234 |     expect(new URL(response.url()).searchParams.get('snapshot_id')).toBe(renewed.snapshot_id);
  235 |     expect((await response.json()).trace_status).toBe('available');
  236 |   } finally {await server.close();}
  237 | });
  238 | 
```