# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accounting-migration.spec.js >> S09 direct source reload and read retry never create a replacement snapshot
- Location: tests/browser/accounting-migration.spec.js:313:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/连接中断；财务内容/)
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/连接中断；财务内容/) with timeout 4000ms
  - waiting for getByText(/连接中断；财务内容/)

```

```yaml
- banner "导航面板":
  - link "Agent-Alfred 本地助手":
    - /url: /overview
  - navigation "主导航":
    - paragraph: 工作区
    - link "总览":
      - /url: /overview
    - link "收件箱":
      - /url: /inbox
    - link "运行":
      - /url: /runs
    - link "记忆":
      - /url: /memory
    - paragraph: Agent 配置
    - link "模型":
      - /url: /models
    - link "连接":
      - /url: /connections
    - link "行为":
      - /url: /behaviour
    - link "工具":
      - /url: /tools
    - paragraph: 诊断
    - link "用量账本":
      - /url: /ops
    - link "数据库":
      - /url: /database
  - paragraph: 本地优先 · 共享运行宿主
- button "打开主对话" [expanded]
- region "运行与连接摘要":
  - paragraph: 尚未选择会话
- main:
  - heading "用量账本" [level=1]
  - form "账目筛选":
    - heading "待查询条件" [level=2]
    - text: 时间范围
    - combobox "时间范围":
      - option "近七个自然日"
      - option "今天"
      - option "近三十个自然日"
      - option "自定义半开区间"
      - option "全部历史" [selected]
    - text: IANA 时区
    - textbox "IANA 时区": UTC
    - text: 开始日期（含）
    - textbox "开始日期（含）"
    - text: 自定义期间使用当地日期 结束日期（不含）
    - textbox "结束日期（不含）"
    - text: 结束日为排他边界 会话 ID
    - textbox "会话 ID"
    - text: 运行用途
    - combobox "运行用途":
      - option "全部用途" [selected]
      - option "普通聊天"
      - option "手动聚合"
      - option "模型推理探针"
      - option "记忆提炼"
    - text: 工具身份
    - textbox "工具身份":
      - /placeholder: 来源与能力身份
    - text: 包含匹配工具的完整 Run Run ID
    - textbox "Run ID":
      - /placeholder: 精确 Run ID
    - text: 使用完整不透明标识
    - status: 筛选只在点击“刷新账目”时应用。
    - button "刷新账目" [disabled]
  - status: 正在核验原账目快照…
  - status
  - paragraph: 工具筛选展示包含该工具的完整 Run；模型 USD 与工具服务／单位分列，不能归因给单一工具。
- region "MainBar":
  - heading "主对话" [level=2]
  - button "收起主对话"
  - text: 尚未选择会话
  - button "新建会话"
  - region "主对话"
  - text: 消息
  - textbox "消息" [disabled]:
    - /placeholder: 写下消息；/skills 指定流程…
  - button "发送" [disabled]
  - paragraph: 请显式新建或继续会话。
- status: 就绪
- alert
```

# Test source

```ts
  236 |     const p=panel.getBoundingClientRect(),r=link?.getBoundingClientRect();
  237 |     return {scrollTop:panel.scrollTop,panel:{top:p.top,bottom:p.bottom,height:p.height},link:r?{top:r.top,bottom:r.bottom,height:r.height}:null,
  238 |       anchorOffset:r?r.top-p.top:null,focused:document.activeElement===link,visibleInPanel:!!r&&r.top>=p.top&&r.bottom<=p.bottom};
  239 |   });
  240 |   try{
  241 |     await page.setViewportSize(viewport);
  242 |     await server.send('bulk');
  243 |     const created=page.waitForResponse(response=>response.url().endsWith('/api/ops/snapshots'));
  244 |     await page.goto(server.origin+'/ops?range=7d&timezone=Asia%2FShanghai&purpose=chat');
  245 |     const snapshot=await(await created).json(),rows=page.getByRole('button',{name:/查看账目 /});
  246 |     await expect(rows).toHaveCount(50);
  247 |     await page.getByRole('button',{name:'下一页',exact:true}).click();await expect(rows).toHaveCount(55);
  248 |     await rows.last().click();
  249 |     const entry=page.getByRole('link',{name:'进入运行过程（保留账目快照）',exact:true});
  250 |     const href=await entry.getAttribute('href'),runId=decodeURIComponent(new URL(href,server.origin).pathname.slice(6));
  251 |     let posts=0;const reads=[],origins=[];
  252 |     page.on('request',request=>{const url=new URL(request.url());if(url.pathname==='/api/ops')reads.push(url.href);if(url.pathname==='/api/ops/snapshots')posts++;});
  253 |     for(const intent of ['none','focus','scroll']){
  254 |       await entry.scrollIntoViewIfNeeded();await entry.focus();
  255 |       const beforePosition=await position();expect(beforePosition.visibleInPanel).toBe(true);
  256 |       await entry.click();await expect(page).toHaveURL(server.origin+href);
  257 |       await expect(page.getByRole('region',{name:'运行摘要',exact:true})).toContainText(runId);
  258 |       const origin=await page.evaluate(()=>history.state.alfredShell.source.returnSource);origins.push(origin);
  259 |       expect(origin).toMatchObject({kind:'ops',snapshot_id:snapshot.snapshot_id,process_instance_id:snapshot.process_instance_id,filters:snapshot.filters,offset:50,run_id:runId,trigger:{kind:'detail-link',run_id:runId,href}});
  260 |       const back=page.getByRole('link',{name:'返回来源',exact:true});await expect(back).toHaveAttribute('href',origin.route);
  261 |       const before=reads.length;
  262 |       if(intent!=='none')pending=await holdPages(page,intent==='scroll'?'**/api/ops/detail?**':'**/api/ops?**');
  263 |       await back.click();
  264 |       let intentPosition;
  265 |       if(intent!=='none'){
  266 |         await expect.poll(()=>pending.length).toBe(1);
  267 |         if(intent==='focus')await page.getByLabel('Run ID',{exact:true}).fill('未提交的焦点草稿');
  268 |         else{
  269 |           const panel=page.locator('#page'),rect=await panel.boundingBox();
  270 |           const previous=await panel.evaluate(element=>element.scrollTop);
  271 |           await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);
  272 |           await page.mouse.wheel(0,240);
  273 |           await expect.poll(()=>panel.evaluate(element=>element.scrollTop)).toBeGreaterThan(previous);
  274 |         }
  275 |         intentPosition=await position();pending[0].release();
  276 |       }
  277 |       await expect(rows).toHaveCount(5);
  278 |       await expect(page.getByRole('region',{name:'当前账目快照'})).toContainText(snapshot.snapshot_id);
  279 |       await expect(entry).toHaveAttribute('href',href);
  280 |       await expect(page.getByRole('region',{name:'运行账目明细'})).toContainText(runId);
  281 |       // Await rendering and browser scroll delivery before measuring the actual reading position.
  282 |       await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  283 |       const afterPosition=await position();observations.push({intent,before:beforePosition,intentPosition,after:afterPosition});
  284 |       await writeFile(testInfo.outputPath('source-position-observations.json'),JSON.stringify({viewport,observations},null,2));
  285 |       await page.screenshot({path:testInfo.outputPath(`source-return-${intent}.png`)});
  286 |       expect(reads.slice(before)).toHaveLength(1);
  287 |       const read=new URL(reads[before]);expect(read.searchParams.get('snapshot_id')).toBe(snapshot.snapshot_id);expect(read.searchParams.get('offset')).toBe('50');
  288 |       await expect(page.getByLabel('IANA 时区',{exact:true})).toHaveValue('Asia/Shanghai');
  289 |       await expect(page.getByLabel('运行用途',{exact:true})).toHaveValue('chat');
  290 |       await expect(page.getByLabel('时间范围',{exact:true})).toHaveValue('custom');
  291 |       if(intent==='focus'){
  292 |         await expect(page.getByLabel('Run ID',{exact:true})).toBeFocused();await expect(page.getByLabel('Run ID',{exact:true})).toHaveValue('未提交的焦点草稿');
  293 |         expect(afterPosition.scrollTop).toBeCloseTo(intentPosition.scrollTop,0);
  294 |       }else if(intent==='scroll'){
  295 |         await expect(entry).not.toBeFocused();expect(afterPosition.scrollTop).toBeCloseTo(intentPosition.scrollTop,0);
  296 |       }else{
  297 |         await expect(entry).toBeFocused();expect(afterPosition.visibleInPanel).toBe(true);
  298 |         // Fractional typography can leave a half-pixel content anchor;
  299 |         // Chromium at DPR 1 quantizes scrollTop to integer CSS pixels.
  300 |         const contentOffset=afterPosition.scrollTop+afterPosition.anchorOffset;
  301 |         const requestedScrollTop=contentOffset-beforePosition.anchorOffset;
  302 |         expect(afterPosition.scrollTop).toBe(Math.round(requestedScrollTop));
  303 |       }
  304 |       expect(posts).toBe(0);
  305 |       await page.unrouteAll({behavior:'wait'});pending=[];
  306 |     }
  307 |     // Position is per visit; the fixed snapshot/filter/Run identity remains the same.
  308 |     for(const origin of origins)expect(origin).toMatchObject({kind:origins[0].kind,route:origins[0].route,snapshot_id:origins[0].snapshot_id,process_instance_id:origins[0].process_instance_id,filters:origins[0].filters,offset:50,run_id:runId,trigger:origins[0].trigger});
  309 |     await writeFile(testInfo.outputPath('migrated-source-roundtrip.json'),JSON.stringify({viewport,snapshot:snapshot.snapshot_id,filters:snapshot.filters,origins,reads,posts,observations},null,2));
  310 |   }finally{for(const item of pending)item.release();await page.unrouteAll({behavior:'wait'});await server.close();}
  311 | });
  312 | 
  313 | test('S09 direct source reload and read retry never create a replacement snapshot', async ({page,context}) => {
  314 |   const server=await memoryServer({script:'tests/browser/ops_server.py'});
  315 |   let release=()=>{};
  316 |   try {
  317 |     await page.goto(server.origin+'/ops?range=all&timezone=UTC');
  318 |     const identity=await page.getByRole('region',{name:'当前账目快照'}).getByText(/snapshot_id /).textContent();
  319 |     const snapshot=identity.match(/snapshot_id (\S+)/)[1];
  320 |     let posts=0,reads=0;
  321 |     page.on('request',request=>{const path=new URL(request.url()).pathname;if(path==='/api/ops/snapshots')posts++;if(path==='/api/ops')reads++;});
  322 |     await page.route('**/api/ops?**',route=>route.abort('failed'));
  323 |     await page.goto(server.origin+'/ops?range=all&timezone=UTC&snapshot_id='+snapshot);
  324 |     await expect(page.getByText(/原快照核验失败/)).toBeVisible();
  325 |     expect(posts).toBe(0);expect(reads).toBe(1);
  326 |     await page.unroute('**/api/ops?**');
  327 |     await page.getByRole('button',{name:'重新核验原快照',exact:true}).click();
  328 |     await expect(page.getByRole('region',{name:'当前账目快照'})).toContainText(snapshot);
  329 |     expect(posts).toBe(0);expect(reads).toBe(2);
  330 |     await page.reload();
  331 |     await expect(page.getByRole('region',{name:'当前账目快照'})).toContainText(snapshot);
  332 |     expect(posts).toBe(0);expect(reads).toBe(3);
  333 |     let captured;const capturedRead=new Promise(resolve=>{captured=resolve;});const gate=new Promise(resolve=>{release=resolve;});
  334 |     await page.route('**/api/ops?**',async route=>{const response=await route.fetch();captured();await gate;await route.fulfill({response}).catch(error=>{if(!String(error).includes('Route is already handled'))throw error;});});
  335 |     await page.reload();await capturedRead;
> 336 |     await context.setOffline(true);await expect(page.getByText(/连接中断；财务内容/)).toBeVisible();
      |                                                                              ^ Error: expect(locator).toBeVisible() failed
  337 |     release();await page.unroute('**/api/ops?**');await context.setOffline(false);
  338 |     const retry=page.getByRole('button',{name:'重新核验原快照',exact:true});
  339 |     await expect(retry).toBeEnabled();await retry.click();
  340 |     await expect(page.getByRole('region',{name:'当前账目快照'})).toContainText(snapshot);
  341 |     expect(posts).toBe(0);
  342 |   } finally {release();try{await context.setOffline(false);}finally{await server.close();}}
  343 | });
  344 | 
  345 | test('S09 a new process retires a held financial response and clears body without replacing the old ledger',async({page})=>{
  346 |   const server=await memoryServer({script:'tests/browser/ops_migration_server.py'});
  347 |   let release;const gate=new Promise(resolve=>{release=resolve;});
  348 |   try{
  349 |     await server.send('long');
  350 |     await page.goto(server.origin+'/ops?range=all&timezone=UTC');
  351 |     await page.getByRole('button',{name:/查看账目 /}).click();
  352 |     await page.getByRole('button',{name:'完整脱敏审计',exact:true}).click();
  353 |     const preview=page.getByLabel('历史正文当前段');await expect(preview).toContainText('<script>');
  354 |     const scope=page.getByRole('region',{name:'当前账目快照'}),fixed=await scope.textContent();
  355 |     let captured;const persisted=new Promise(resolve=>{captured=resolve;});
  356 |     await page.route('**/api/ops/snapshots',async route=>{const response=await route.fetch();captured();await gate;await route.fulfill({response});});
  357 |     await page.getByRole('button',{name:'刷新账目',exact:true}).click();await persisted;
  358 |     await server.restart();
  359 |     await expect(page.getByText(/旧快照已失效/)).toBeVisible();
  360 |     await expect(preview).toBeEmpty();
  361 |     await expect(page.getByText(/实例已变化；历史正文需重新核验/)).toBeVisible();
  362 |     release();
  363 |     await expect(scope).toHaveText(fixed);
  364 |     await expect(page.getByRole('button',{name:/查看账目 /})).toBeDisabled();
  365 |     await expect(page.getByRole('button',{name:'刷新账目',exact:true})).toBeEnabled();
  366 |     await page.getByRole('button',{name:'核验原操作当前结果',exact:true}).click();
  367 |     await expect(page.getByRole('region',{name:'当前核验',exact:true})).toContainText('读取时刻');
  368 |     await page.getByRole('button',{name:'完整脱敏审计',exact:true}).click();
  369 |     await expect(preview).toContainText('<script>');
  370 |     await expect(scope).toHaveText(fixed);
  371 |   }finally{release();await server.close();}
  372 | });
  373 | 
```