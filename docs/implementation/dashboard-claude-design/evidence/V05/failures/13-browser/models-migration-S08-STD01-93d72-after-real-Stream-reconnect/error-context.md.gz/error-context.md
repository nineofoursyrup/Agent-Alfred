# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: models-migration.spec.js >> S08 STD01 retired save cannot clear a successor request after real Stream reconnect
- Location: tests/browser/models-migration.spec.js:347:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-model=\'opencode-go:deepseek-v4-flash\']').getByText(/连接中断，保存结果未确认/)
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('[data-model=\'opencode-go:deepseek-v4-flash\']').getByText(/连接中断，保存结果未确认/) with timeout 4000ms
  - waiting for locator('[data-model=\'opencode-go:deepseek-v4-flash\']').getByText(/连接中断，保存结果未确认/)

```

```yaml
- banner "导航面板":
  - link "Agent-Alfred 本地助手":
    - /url: /overview
  - navigation "主导航":
    - paragraph: 工作区
    - link "总览":
      - /url: /overview
    - link "收件箱":
      - /url: /inbox
    - link "运行":
      - /url: /runs
    - link "记忆":
      - /url: /memory
    - paragraph: Agent 配置
    - link "模型":
      - /url: /models
    - link "连接":
      - /url: /connections
    - link "行为":
      - /url: /behaviour
    - link "工具":
      - /url: /tools
    - paragraph: 诊断
    - link "用量账本":
      - /url: /ops
    - link "数据库":
      - /url: /database
  - paragraph: 本地优先 · 共享运行宿主
- button "打开主对话" [expanded]
- region "运行与连接摘要":
  - paragraph: 尚未选择会话
- main:
  - heading "模型" [level=1]
  - status: 设置 revision 0；单项保存，各项互不代存。
  - button "核对当前模型设置"
  - region "模型指派":
    - heading "模型指派" [level=2]
    - paragraph: 主模型：opencode-go / deepseek-v4-flash
    - paragraph: 辅助小模型：跟随主模型
    - paragraph: 辅助小模型用于记忆检索门、Skill 自动选择与消息分类。
  - heading "anthropic" [level=2]
  - paragraph: 连接：未配置
  - paragraph: 目录：尚未获取；上次成功 尚无
  - button "展开此端点"
  - button "刷新目录"
  - paragraph: 暂无候选；目录尚未获取、失败或为空均不代表当前无指派。
  - heading "openai" [level=2]
  - paragraph: 连接：已配置未测试
  - paragraph: 目录：尚未获取；上次成功 尚无
  - button "展开此端点"
  - button "刷新目录"
  - paragraph: 暂无候选；目录尚未获取、失败或为空均不代表当前无指派。
  - heading "xai" [level=2]
  - paragraph: 连接：未配置
  - paragraph: 目录：尚未获取；上次成功 尚无
  - button "展开此端点"
  - button "刷新目录"
  - paragraph: 暂无候选；目录尚未获取、失败或为空均不代表当前无指派。
  - heading "deepseek" [level=2]
  - paragraph: 连接：未配置
  - paragraph: 目录：尚未获取；上次成功 尚无
  - button "展开此端点"
  - button "刷新目录"
  - paragraph: 暂无候选；目录尚未获取、失败或为空均不代表当前无指派。
  - heading "opencode" [level=2]
  - paragraph: 连接：已配置未测试
  - paragraph: 目录：尚未获取；上次成功 尚无
  - button "展开此端点"
  - button "刷新目录"
  - article:
    - heading "deepseek-v4-flash" [level=3]
    - paragraph: deepseek-v4-flash
    - paragraph: 支持状态：支持
    - paragraph: 未钉选
    - paragraph
    - group: 模型详情
  - article:
    - heading "qwen3.7-max" [level=3]
    - paragraph: qwen3.7-max
    - paragraph: 支持状态：支持
    - paragraph: 未钉选
    - paragraph
    - group: 模型详情
  - article:
    - heading "grok-4.6" [level=3]
    - paragraph: grok-4.6
    - paragraph: "支持状态：unsupported_wire_style: responses unsupported_wire_style: responses"
    - paragraph: 未钉选
    - paragraph
    - group: 模型详情
  - heading "opencode-go" [level=2]
  - paragraph: 连接：已配置未测试
  - paragraph: 目录：新鲜；上次成功 2026-10-11T03:09:10Z
  - button "展开此端点"
  - button "刷新目录"
  - article:
    - heading "目录模型名称" [level=3]
    - paragraph: deepseek-v4-flash
    - paragraph: 支持状态：支持
    - paragraph: 已钉选 · 当前主模型
    - paragraph: 提交中
    - group:
      - text: 模型详情
      - paragraph: endpoint_id：opencode-go
      - paragraph: model_id：deepseek-v4-flash
      - paragraph: 候选来源：builtin / catalog / pinned；支持依据：builtin_table
      - paragraph: 线路：openai；线路依据：builtin_table
      - button "取消钉选" [disabled]
      - paragraph: 已指派，不能取消钉选。
      - button "指派为主模型"
      - button "指派为检索门"
      - text: 显示名
      - textbox "显示名": A
      - paragraph: 当前保存值：空（无覆盖）
      - paragraph
      - button "保存显示名" [disabled]
      - status: 正在提交；后续编辑不会改写本次请求。
      - text: 线路形状
      - combobox "线路形状":
        - option "内置（当前，无复位操作）" [disabled] [selected]
        - option "openai"
        - option "anthropic"
      - paragraph: 当前线路：openai · builtin_table；用户选择仍是未验证声明。
      - paragraph
      - button "保存线路" [disabled]
      - status
      - text: uncached_input
      - textbox "uncached_input":
        - /placeholder: 留空沿价格链查找
      - paragraph: 当前保存值：空（无覆盖） · USD / 百万 Token；用户覆盖价，空不是 0。
      - paragraph
      - button "保存 uncached_input"
      - status
      - text: cache_read
      - textbox "cache_read":
        - /placeholder: 留空沿价格链查找
      - paragraph: 当前保存值：空（无覆盖） · USD / 百万 Token；用户覆盖价，空不是 0。
      - paragraph
      - button "保存 cache_read"
      - status
      - text: cache_write
      - textbox "cache_write":
        - /placeholder: 留空沿价格链查找
      - paragraph: 当前保存值：空（无覆盖） · USD / 百万 Token；用户覆盖价，空不是 0。
      - paragraph
      - button "保存 cache_write"
      - status
      - text: output
      - textbox "output":
        - /placeholder: 留空沿价格链查找
      - paragraph: 当前保存值：空（无覆盖） · USD / 百万 Token；用户覆盖价，空不是 0。
      - paragraph
      - button "保存 output"
      - status
      - region "真实调用测试":
        - heading "真实调用测试" [level=4]
        - paragraph: opencode-go / deepseek-v4-flash · 仅按已保存设置测试；可能产生费用，未保存编辑不会纳入。
        - button "测试真实调用（可能计费）"
  - article:
    - heading "qwen3.7-max" [level=3]
    - paragraph: qwen3.7-max
    - paragraph: 支持状态：支持
    - paragraph: 未钉选
    - paragraph
    - group: 模型详情
  - article:
    - heading "grok-4.6" [level=3]
    - paragraph: grok-4.6
    - paragraph: "支持状态：unsupported_wire_style: responses unsupported_wire_style: responses"
    - paragraph: 未钉选
    - paragraph
    - group: 模型详情
- region "MainBar":
  - heading "主对话" [level=2]
  - button "收起主对话"
  - text: 尚未选择会话
  - button "新建会话"
  - region "主对话"
  - text: 消息
  - textbox "消息" [disabled]:
    - /placeholder: 写下消息；/skills 指定流程…
  - button "发送" [disabled]
  - paragraph: 请显式新建或继续会话。
- status: 就绪
- alert
```

# Test source

```ts
  266 |     const row=page.locator("[data-model='opencode-go:qwen3.7-max']");
  267 |     await row.getByText('模型详情',{exact:true}).click();
  268 |     await row.getByRole('button',{name:'钉选',exact:true}).click();
  269 |     await expect(row.getByRole('textbox',{name:'显示名',exact:true})).toBeVisible();
  270 |     await row.getByRole('textbox',{name:'显示名',exact:true}).fill('拒绝后必须保留');
  271 |     await page.route('**/api/settings',async route=>{if(route.request().postDataJSON().op==='unpin')await route.fulfill({status:409,contentType:'application/json',body:JSON.stringify({code:'mutation_in_flight'})});else await route.continue();});
  272 |     await row.getByRole('button',{name:'取消钉选',exact:true}).click();
  273 |     await page.getByRole('button',{name:'放弃并离开',exact:true}).click();
  274 |     await expect(row.getByRole('textbox',{name:'显示名',exact:true})).toHaveValue('拒绝后必须保留');
  275 |   }finally{await context.close();await s.close();}
  276 | });
  277 | 
  278 | test('S08 unknown unpin unlocks fields only after a connected current read and keeps its receipt',async({browser})=>{
  279 |   const s=await server(),context=await browser.newContext({baseURL:s.origin});let releaseUnpin=()=>{},releaseRead=()=>{};
  280 |   try {
  281 |     const page=await context.newPage();await page.goto(s.origin+'/models');
  282 |     const row=page.locator("[data-model='opencode-go:qwen3.7-max']");
  283 |     await row.getByText('模型详情',{exact:true}).click();await row.getByRole('button',{name:'钉选',exact:true}).click();
  284 |     const input=row.getByRole('textbox',{name:'显示名',exact:true}),style=row.getByRole('combobox',{name:'线路形状',exact:true});
  285 |     const price=row.getByRole('textbox',{name:'output',exact:true}),refresh=page.getByRole('button',{name:'核对当前模型设置',exact:true});
  286 |     await input.fill('取消钉选前的草稿');
  287 |     let gotUnpin,gotRead,posts=0,mode='hold',reads=0;
  288 |     const unpinStarted=new Promise(resolve=>gotUnpin=resolve),unpinHeld=new Promise(resolve=>releaseUnpin=resolve);
  289 |     const readStarted=new Promise(resolve=>gotRead=resolve),readHeld=new Promise(resolve=>releaseRead=resolve);
  290 |     await page.route('**/api/settings',async route=>{posts++;gotUnpin();await unpinHeld;await route.abort().catch(()=>{});});
  291 |     await page.route('**/api/models',async route=>{
  292 |       reads++;if(mode==='fail'){await route.abort();return;}
  293 |       const response=await route.fetch();
  294 |       if(mode==='hold'){gotRead();await readHeld;}
  295 |       await route.fulfill({response}).catch(()=>{});
  296 |     });
  297 |     await refresh.click();await readStarted; // This read predates the unknown outcome.
  298 |     await row.getByRole('button',{name:'取消钉选',exact:true}).click();
  299 |     await page.getByRole('button',{name:'放弃并离开',exact:true}).click();await unpinStarted;
  300 |     for(const field of [input,style,price])await expect(field).toBeDisabled();
  301 |     await page.evaluate(()=>window.dispatchEvent(new Event('offline')));
  302 |     await expect(row.locator('.model-row-state')).toContainText('原操作结果未确认');
  303 |     const oldRead=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/models');releaseRead();await oldRead;
  304 |     for(const field of [input,style,price])await expect(field).toBeDisabled();
  305 |     mode='pass';const offlineRead=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/models');await refresh.click();await offlineRead;
  306 |     for(const field of [input,style,price])await expect(field).toBeDisabled();
  307 |     mode='fail';const beforeReconnect=reads;await page.evaluate(()=>window.dispatchEvent(new Event('online')));
  308 |     await expect.poll(()=>reads).toBeGreaterThan(beforeReconnect);
  309 |     await expect(page.getByText(/模型设置读取失败/)).toBeVisible();
  310 |     for(const field of [input,style,price])await expect(field).toBeDisabled();
  311 |     mode='pass';await refresh.click();
  312 |     for(const field of [input,style,price])await expect(field).toBeEnabled();
  313 |     await expect(input).toHaveValue('取消钉选前的草稿');await expect(row.locator('.model-row-state')).toContainText('原操作结果未确认');
  314 |     await input.fill('核对后继续编辑');await style.selectOption('openai');await price.fill('0');
  315 |     const lateFailure=page.waitForEvent('requestfailed',request=>new URL(request.url()).pathname==='/api/settings');releaseUnpin();await lateFailure;
  316 |     await expect(input).toHaveValue('核对后继续编辑');await expect(style).toHaveValue('openai');await expect(price).toHaveValue('0');
  317 |     await expect(row.locator('.model-row-state')).toContainText('原操作结果未确认');expect(posts).toBe(1);
  318 |     const current=await (await page.request.get('/api/models')).json();
  319 |     expect(current.endpoints.flatMap(group=>group.models).find(model=>model.endpoint_id==='opencode-go' && model.model_id==='qwen3.7-max').pinned).toBe(true);
  320 |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  321 |   }finally{releaseUnpin();releaseRead();await context.close();await s.close();}
  322 | });
  323 | 
  324 | test('S08 each saved field is independent and uses the public HTTP value',async({browser})=>{
  325 |   const s=await server(),context=await browser.newContext({baseURL:s.origin});
  326 |   try {
  327 |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);const posts=[];
  328 |     page.on('request',r=>{if(new URL(r.url()).pathname==='/api/settings' && r.method()==='POST')posts.push(r.postDataJSON());});
  329 |     for(const dimension of ['uncached_input','cache_read','cache_write','output'])await row.getByRole('textbox',{name:dimension,exact:true}).fill('0');
  330 |     await row.getByRole('combobox',{name:'线路形状',exact:true}).selectOption('anthropic');
  331 |     expect(posts).toHaveLength(0);
  332 |     await row.getByRole('button',{name:'保存线路',exact:true}).click();
  333 |     await expect.poll(async()=>(await saved(page)).wire_style).toBe('anthropic');
  334 |     expect((await saved(page)).price_override).toBeNull();
  335 |     for(const [index,dimension] of ['uncached_input','cache_read','cache_write','output'].entries()) {
  336 |       await row.getByRole('button',{name:'保存 '+dimension,exact:true}).click();
  337 |       await expect.poll(async()=>(await saved(page)).price_override?.[dimension]).toBe('0');
  338 |       expect(posts).toHaveLength(index+2);
  339 |     }
  340 |     expect(posts.map(p=>p.op)).toEqual(['style','price','price','price','price']);
  341 |     expect(posts.slice(1).map(p=>p.dimension)).toEqual(['uncached_input','cache_read','cache_write','output']);
  342 |     await expect(row.getByText(/未验证声明/)).toBeVisible();
  343 |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  344 |   }finally{await context.close();await s.close();}
  345 | });
  346 | 
  347 | test('S08 STD01 retired save cannot clear a successor request after real Stream reconnect',async({browser})=>{
  348 |   const s=await server(),context=await browser.newContext({baseURL:s.origin});
  349 |   let releaseA=()=>{},releaseB=()=>{};
  350 |   try {
  351 |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  352 |     const input=row.getByRole('textbox',{name:'显示名',exact:true});
  353 |     const save=row.getByRole('button',{name:'保存显示名',exact:true});
  354 |     const posts=[];let gotA,gotB;
  355 |     const recvA=new Promise(resolve=>gotA=resolve),recvB=new Promise(resolve=>gotB=resolve);
  356 |     const heldA=new Promise(resolve=>releaseA=resolve),heldB=new Promise(resolve=>releaseB=resolve);
  357 |     await page.route('**/api/settings',async route=>{
  358 |       const request=route.request().postDataJSON();posts.push(request);
  359 |       const response=await route.fetch();expect(response.status()).toBe(200);
  360 |       if(request.display_name==='A'){gotA();await heldA;}
  361 |       if(request.display_name==='B'){gotB();await heldB;}
  362 |       await route.fulfill({response}).catch(()=>{});
  363 |     });
  364 |     await input.fill('A');await save.click();await recvA;
  365 |     await context.setOffline(true);
> 366 |     await expect(row.getByText(/连接中断，保存结果未确认/)).toBeVisible();
      |                                                 ^ Error: expect(locator).toBeVisible() failed
  367 |     await context.setOffline(false);
  368 |     await expect(row.getByText('当前保存值：A',{exact:true})).toBeVisible();
  369 |     await row.getByRole('button',{name:'基于当前版本继续编辑',exact:true}).click();
  370 |     await input.fill('B');await save.click();await recvB;await expect(save).toBeDisabled();
  371 |     const arrived=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/settings' && r.request().postDataJSON().display_name==='A');
  372 |     releaseA();await arrived;
  373 |     await input.fill('C');
  374 |     await expect(save).toBeDisabled();
  375 |     await expect(row.locator('.model-row-state')).toContainText('提交中');
  376 |     expect(posts.map(p=>[p.display_name,p.expected_revision])).toEqual([['A',0],['B',1]]);
  377 |     releaseB();
  378 |     await expect(row.getByText('已确认保存；还有新编辑',{exact:true})).toBeVisible();
  379 |     await expect(input).toHaveValue('C');await expect(save).toBeEnabled();
  380 |     expect((await saved(page)).display_name_override).toBe('B');
  381 |     expect(posts).toHaveLength(2);
  382 |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  383 |   }finally{releaseA();releaseB();await context.setOffline(false);await context.close();await s.close();}
  384 | });
  385 | 
  386 | test('S08 STD02 model action focus survives refresh and completion without stealing a new intent',async({browser})=>{
  387 |   const s=await server(),context=await browser.newContext({baseURL:s.origin});let release=()=>{};
  388 |   try {
  389 |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  390 |     const input=row.getByRole('textbox',{name:'显示名',exact:true});
  391 |     const save=row.getByRole('button',{name:'保存显示名',exact:true});
  392 |     const other=page.locator("[data-model='opencode-go:qwen3.7-max']");
  393 |     await other.getByText('模型详情',{exact:true}).click();await other.getByRole('button',{name:'钉选',exact:true}).click();
  394 |     await expect(other.getByRole('textbox',{name:'显示名',exact:true})).toBeVisible();
  395 |     for(const button of [save,other.getByRole('button',{name:'保存显示名',exact:true}),row.getByRole('button',{name:'保存 output',exact:true}),row.getByRole('button',{name:'指派为主模型',exact:true}),row.getByRole('button',{name:'测试真实调用（可能计费）',exact:true}),page.locator('[data-endpoint="opencode-go"]').getByRole('button',{name:'刷新目录',exact:true})]) {
  396 |       await button.focus();
  397 |       const reread=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/models');
  398 |       await page.evaluate(()=>window.dispatchEvent(new Event('focus')));await reread;
  399 |       await expect(button).toBeFocused();
  400 |     }
  401 |     let entered,posts=0;let received=new Promise(resolve=>entered=resolve);let held=new Promise(resolve=>release=resolve);
  402 |     await page.route('**/api/settings',async route=>{posts++;const response=await route.fetch();entered();await held;await route.fulfill({response}).catch(()=>{});});
  403 |     await input.fill('focused action');await save.click();await received;await expect(save).toBeDisabled();
  404 |     release();await expect(row.getByText('已确认保存',{exact:true})).toBeVisible();await expect(save).toBeFocused();
  405 |     received=new Promise(resolve=>entered=resolve);held=new Promise(resolve=>release=resolve);
  406 |     await input.fill('MainBar owns focus');await save.click();await received;
  407 |     const chat=page.getByRole('button',{name:'新建会话',exact:true});await chat.focus();
  408 |     release();await expect(row.getByText('已确认保存',{exact:true})).toBeVisible();await expect(chat).toBeFocused();
  409 |     received=new Promise(resolve=>entered=resolve);held=new Promise(resolve=>release=resolve);
  410 |     await input.fill('page has retired');await save.click();await received;
  411 |     await input.fill('new unsaved input before retirement');
  412 |     await page.locator('nav a[href="/connections"]').click();await page.getByRole('button',{name:'放弃并离开',exact:true}).click();
  413 |     const reread=page.getByRole('button',{name:'重新读取 .env',exact:true});await reread.focus();
  414 |     const finished=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/settings');release();await finished;
  415 |     await expect(reread).toBeFocused();expect(posts).toBe(3);
  416 |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  417 |   }finally{release();await context.close();await s.close();}
  418 | });
  419 | 
  420 | 
  421 | test('S11 clear final price changes the next probe and Ops while the old snapshot stays fixed',async({browser})=>{
  422 |   const s=await server(),context=await browser.newContext({baseURL:s.origin});
  423 |   try{
  424 |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  425 |     const price=row.getByRole('textbox',{name:'output',exact:true}),save=row.getByRole('button',{name:'保存 output',exact:true});
  426 |     await price.fill('0');await save.click();await expect.poll(async()=>(await saved(page)).price_override?.output).toBe('0');
  427 |     async function probe(){
  428 |       const accepted=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/runs'&&r.request().method()==='POST');
  429 |       await row.getByRole('button',{name:'测试真实调用（可能计费）',exact:true}).click();
  430 |       const response=await accepted;expect(response.status()).toBe(202);const {run_id}=await response.json();
  431 |       await expect.poll(async()=>(await(await page.request.get('/api/runs?filter=all')).json()).runs.some(run=>run.run_id===run_id)).toBe(true);
  432 |       return run_id;
  433 |     }
  434 |     const first=await probe();
  435 |     const {csrf_token}=await(await page.request.get('/api/entry')).json();
  436 |     const snapshot=await(await page.request.post('/api/ops/snapshots',{headers:{'x-agent-alfred-csrf':csrf_token},data:{range:'all',timezone:'UTC'}})).json();
  437 |     const detailPath='/api/ops/detail?'+new URLSearchParams({snapshot_id:snapshot.snapshot_id,run_id:first});
  438 |     const frozen=await(await page.request.get(detailPath)).json();
  439 |     expect(frozen.run.attempts[0].cost.state).toBe('estimated');
  440 |     // Fixture emits 1,000 uncached + 1,000 output tokens: .22/million input, zero output override.
  441 |     expect(frozen.run.attempts[0].cost.amount).toBe('0.00022');
  442 |     expect(frozen.run.attempts[0].cost.price_components.find(part=>part.dimension==='output').unit_price).toBe('0');
  443 |     await price.fill('');await save.click();await expect.poll(async()=>(await saved(page)).price_override).toBeNull();
  444 |     const second=await probe();expect(second).not.toBe(first);
  445 |     expect(await(await page.request.get(detailPath)).json()).toEqual(frozen);
  446 |     await row.getByRole('link',{name:'查看探针 Run '+second,exact:true}).click();
  447 |     await expect(page.getByRole('region',{name:'运行摘要',exact:true})).toContainText(second);
  448 |     await expect(page.locator('#page')).toContainText('USD 0.00088');
  449 |     await page.locator('nav a[href="/ops"]').click();
  450 |     await page.getByRole('button',{name:'查看账目 '+second,exact:true}).click();
  451 |     await expect(page.getByRole('table',{name:'模型 Attempt'})).toContainText('settings-probe');
  452 |     await expect(page.getByRole('table',{name:'模型 Attempt'})).toContainText('估算费用 USD 0.00088');
  453 |     const before=await page.getByRole('region',{name:'当前账目快照'}).textContent();
  454 |     await page.getByRole('link',{name:'进入运行过程（保留账目快照）',exact:true}).click();
  455 |     await page.getByRole('link',{name:'返回来源',exact:true}).click();
  456 |     await expect(page.getByRole('region',{name:'当前账目快照'})).toHaveText(before);
  457 |     await expect(page.getByRole('link',{name:'进入运行过程（保留账目快照）',exact:true})).toBeFocused();
  458 |     expect((await(await fetch(s.control)).json()).model_calls).toHaveLength(2);
  459 |     expect(await(await page.request.get(detailPath)).json()).toEqual(frozen);
  460 |   }finally{await context.close();await s.close();}
  461 | });
  462 | 
```