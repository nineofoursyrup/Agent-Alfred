# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: read-retirement.spec.js >> active Run summary retires its response without clearing stale after reconnect
- Location: tests/browser/read-retirement.spec.js:162:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.page-body > [role=status]').filter({ hasText: /^运行摘要 ·/ })
Expected substring: "连接中断，保留旧快照"
Received string:    "运行摘要 · 读取于 10:54:12 AM"
Timeout: 4000ms

Call log:
  - Expect "toContainText" locator('.page-body > [role=status]').filter({ hasText: /^运行摘要 ·/ }) with timeout 4000ms
  - waiting for locator('.page-body > [role=status]').filter({ hasText: /^运行摘要 ·/ })
    12 × locator resolved to <p role="status" class="run-read-status">运行摘要 · 读取于 10:54:12 AM</p>
       - unexpected value "运行摘要 · 读取于 10:54:12 AM"

```

```yaml
- status: 运行摘要 · 读取于 10:54:12 AM
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { localServer } from "./local-server.js";
  3   | import { memoryServer } from "./memory-server.js";
  4   | 
  5   | // Only delay delivery of a successful response from the real service. The
  6   | // production reader, source identity and returned body are not substituted.
  7   | async function holdResponse(page, pattern) {
  8   |   let release, fetched, delivered;
  9   |   const gate = new Promise((resolve) => {
  10  |     release = resolve;
  11  |   });
  12  |   const received = new Promise((resolve) => {
  13  |     fetched = resolve;
  14  |   });
  15  |   const delivery = new Promise((resolve) => {
  16  |     delivered = resolve;
  17  |   });
  18  |   await page.route(
  19  |     pattern,
  20  |     async (route) => {
  21  |       const response = await route.fetch();
  22  |       fetched();
  23  |       await gate;
  24  |       await route.fulfill({ response }).catch(() => {});
  25  |       delivered();
  26  |     },
  27  |     { times: 1 },
  28  |   );
  29  |   return {
  30  |     received,
  31  |     async release() {
  32  |       release();
  33  |       await delivery;
  34  |     },
  35  |   };
  36  | }
  37  | 
  38  | // Observe the native stream without replacing payloads or application handlers.
  39  | async function observeStream(page) {
  40  |   await page.addInitScript(() => {
  41  |     window.nativeStreams = [];
  42  |     window.transportNotices = [];
  43  |     window.hostInstances = [];
  44  |     const Native = window.EventSource;
  45  |     window.EventSource = class extends Native {
  46  |       constructor(url) {
  47  |         super(url);
  48  |         window.nativeStreams.push(this);
  49  |         super.addEventListener("transport_notice", (event) =>
  50  |           window.transportNotices.push(JSON.parse(event.data)),
  51  |         );
  52  |         super.addEventListener("state_patch", (event) =>
  53  |           window.hostInstances.push(JSON.parse(event.data).process_instance_id),
  54  |         );
  55  |       }
  56  |     };
  57  |   });
  58  | }
  59  | 
  60  | async function interruptRead(page, context, status, gap) {
  61  |   const previousStream = await page.evaluate(
  62  |     () => window.nativeStreams.length - 1,
  63  |   );
  64  |   // A malformed Last-Event-ID is an actual server replay-gap input. Native
  65  |   // EventSource reconnects and receives the broker's real notice + snapshot.
  66  |   if (gap)
  67  |     await page.route(
  68  |       "**/api/events**",
  69  |       (route) =>
  70  |         route.continue({
  71  |           headers: {
  72  |             ...route.request().headers(),
  73  |             "last-event-id": "s03-invalid-cursor",
  74  |           },
  75  |         }),
  76  |       { times: 1 },
  77  |     );
  78  |   await context.setOffline(true);
> 79  |   await expect(status).toContainText("连接中断，保留旧快照");
      |                        ^ Error: expect(locator).toContainText(expected) failed
  80  |   await context.setOffline(false);
  81  |   await expect(page.locator("#shell-status")).not.toContainText("连接中断");
  82  |   if (gap) {
  83  |     await expect
  84  |       .poll(() =>
  85  |         page.evaluate(() =>
  86  |           window.transportNotices.some(
  87  |             (item) =>
  88  |               item.code === "replay_gap" && item.gap_reason === "malformed",
  89  |           ),
  90  |         ),
  91  |       )
  92  |       .toBe(true);
  93  |     await expect(status).toContainText("增量通知缺口");
  94  |   }
  95  |   expect(await page.evaluate(() => new Set(window.hostInstances).size)).toBe(1);
  96  |   expect(
  97  |     await page.evaluate(
  98  |       (index) => window.nativeStreams[index].readyState,
  99  |       previousStream,
  100 |     ),
  101 |   ).toBe(2);
  102 |   expect(
  103 |     await page.evaluate(
  104 |       () =>
  105 |         window.nativeStreams.filter(
  106 |           (source) => source.readyState !== EventSource.CLOSED,
  107 |         ).length,
  108 |     ),
  109 |   ).toBe(1);
  110 |   return gap ? "增量通知缺口，快照待刷新" : "连接中断，保留旧快照";
  111 | }
  112 | 
  113 | for (const gap of [false, true])
  114 |   test(`real Session response is retired across ${gap ? "broker replay gap" : "disconnect"} and same-instance reconnect`, async ({
  115 |     page,
  116 |     context,
  117 |   }) => {
  118 |     const server = await localServer();
  119 |     let held;
  120 |     try {
  121 |       await observeStream(page);
  122 |       await page.goto(server.origin + "/inbox");
  123 |       const list = page.getByRole("region", { name: "会话列表" });
  124 |       await expect(list.locator("[data-source-id]")).toHaveCount(1);
  125 |       const entry = await (
  126 |         await page.request.get(server.origin + "/api/entry")
  127 |       ).json();
  128 |       const created = await page.request.post(server.origin + "/api/sessions", {
  129 |         headers: { "x-agent-alfred-csrf": entry.csrf_token },
  130 |         data: {},
  131 |       });
  132 |       expect(created.status()).toBe(201);
  133 |       const session = (await created.json()).session_id;
  134 |       held = await holdResponse(page, "**/api/sessions?**");
  135 |       const refresh = list.getByRole("button", {
  136 |         name: "刷新会话",
  137 |         exact: true,
  138 |       });
  139 |       await refresh.click();
  140 |       await held.received;
  141 |       const reason = await interruptRead(page, context, list, gap);
  142 |       await held.release();
  143 |       await page.evaluate(() => new Promise(requestAnimationFrame));
  144 |       await expect(list.locator("[data-source-id]")).toHaveCount(1);
  145 |       await expect(list).toContainText(reason);
  146 |       await expect(refresh).toBeEnabled();
  147 |       await refresh.click();
  148 |       await expect(list.locator("[data-source-id]")).toHaveCount(2);
  149 |       await expect(
  150 |         list.locator('[data-source-id="' + session + '"]'),
  151 |       ).toHaveCount(1);
  152 |       await expect(list).not.toContainText(reason);
  153 |     } finally {
  154 |       await context.setOffline(false);
  155 |       if (held) await held.release();
  156 |       await server.close();
  157 |     }
  158 |   });
  159 | 
  160 | for (const gap of [false, true])
  161 |   for (const source of ["summary", "evidence"])
  162 |     test(`active Run ${source} retires its response without clearing stale after ${gap ? "broker replay gap" : "reconnect"}`, async ({
  163 |       page,
  164 |       context,
  165 |     }) => {
  166 |       const server = await memoryServer({
  167 |         script: "tests/browser/trace_export_server.py",
  168 |       });
  169 |       let held;
  170 |       try {
  171 |         await observeStream(page);
  172 |         await page.goto(server.origin + "/inbox");
  173 |         await page
  174 |           .getByRole("button", { name: "新建会话", exact: true })
  175 |           .click();
  176 |         await server.send("recording-hold-fail");
  177 |         await page
  178 |           .getByRole("textbox", { name: "消息", exact: true })
  179 |           .fill("运行来源退休验证");
```