# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tools-migration.spec.js >> S07 unreadable catalog keeps draft and local status; unavailable MCP is visible without inventing a connection
- Location: tests/browser/tools-migration.spec.js:378:1

# Error details

```
Error: Traceback (most recent call last):
  File "/Users/nineofour/Agent-Alfred-v05/tests/browser/mcp_server.py", line 181, in <module>
    main()
    ~~~~^^
  File "/Users/nineofour/Agent-Alfred-v05/tests/browser/mcp_server.py", line 146, in main
    server = ThreadingHTTPServer(
        ("127.0.0.1", int(os.environ.get("ALFRED_BROWSER_TEST_PORT", "17736")) + 8),
        Handler,
    )
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/socketserver.py", line 457, in __init__
    self.server_bind()
    ~~~~~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/http/server.py", line 148, in server_bind
    socketserver.TCPServer.server_bind(self)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/socketserver.py", line 478, in server_bind
    self.socket.bind(self.server_address)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^
OSError: [Errno 48] Address already in use

```

# Test source

```ts
  1  | import {spawn} from 'node:child_process';
  2  | import {createInterface} from 'node:readline';
  3  | import {once} from 'node:events';
  4  | 
  5  | // Controls change only the loopback fixture's input files and IO barriers.
  6  | // Discovery, identity, authorization and cleanup remain the real Host paths.
  7  | export async function mcpServer(args=[]) {
  8  |   const child=spawn('.venv/bin/python',['tests/browser/mcp_server.py',...args]);
  9  |   const lines=createInterface({input:child.stdout});
  10 |   let errors='';child.stderr.on('data',data=>errors+=data);
  11 |   const exited=once(child,'exit');
  12 |   const value=await Promise.race([once(lines,'line').then(([line])=>JSON.parse(line)),
> 13 |     exited.then(()=>{throw new Error(errors);})]);
     |                            ^ Error: Traceback (most recent call last):
  14 |   return {...value, async close(){child.kill('SIGTERM');await exited;lines.close();if(child.exitCode!==0)throw new Error(errors);}};
  15 | }
  16 | 
  17 | export const control=async(server,body)=>(await fetch(server.control,
  18 |   body?{method:'POST',body:JSON.stringify(body)}:{})).json();
  19 | 
```