# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overview.spec.js >> Gap and disconnect retire slow real reads even after a same-instance reconnect
- Location: tests/browser/overview.spec.js:339:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByLabel('期间指标')
Expected substring: "离线副本"
Received string:    "期间指标总览期间今天最近七个自然日最近三十个自然日IANA 时区应用时区刷新期间指标正在刷新，保留原快照 · 有新运行事实，期间快照待刷新 · 来源观察：2026-10-11T02:53:51Z运行记录数1 条 Run 记录模型费用精确 USD 0.125已记录 Attempt 2 次 · 费用未知 0 次精确金额来自端点报告，未经外部账单核对。模型账目完整模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai本次期间与来源当地日期 [2026-10-05, 2026-10-12)（结束日期不含） · Asia/Shanghai确定时间 [2026-10-04T16:00:00+00:00, 2026-10-11T16:00:00+00:00)；先按 Run 开始时间，无开始时间时按受理时间归属。精确十进制 USD 0.125（2 次） · 估算十进制 USD 0（0 次）包含当前库内所有 Session、用途、准入状态和结局；未关联 Run 的旧消息不计入。Run 的全部已记录 Attempt 消耗随 Run 归属，不是供应商按扣费日分摊的账单。持久 Run／Attempt 账目 · 计算 2026-10-11T02:53:51Z · 有效至 2026-10-11T03:08:51Z来源 e62bbed96a5c4ff99306ee2b24497fea · 价格 dac08245330a9d08fc698c0350119532b56e9fafc44788a93ea0ef7904514043 · 实例 7c1b8376e225404491d02625e2d5d110查看本期账目（按原期间重新读取）账本会创建新快照；新增记录或价格变化可能改变金额。"
Timeout: 4000ms

Call log:
  - Expect "toContainText" getByLabel('期间指标') with timeout 4000ms
  - waiting for getByLabel('期间指标')
    12 × locator resolved to <section aria-label="期间指标" class="overview-period">…</section>
       - unexpected value "期间指标总览期间今天最近七个自然日最近三十个自然日IANA 时区应用时区刷新期间指标正在刷新，保留原快照 · 有新运行事实，期间快照待刷新 · 来源观察：2026-10-11T02:53:51Z运行记录数1 条 Run 记录模型费用精确 USD 0.125已记录 Attempt 2 次 · 费用未知 0 次精确金额来自端点报告，未经外部账单核对。模型账目完整模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai本次期间与来源当地日期 [2026-10-05, 2026-10-12)（结束日期不含） · Asia/Shanghai确定时间 [2026-10-04T16:00:00+00:00, 2026-10-11T16:00:00+00:00)；先按 Run 开始时间，无开始时间时按受理时间归属。精确十进制 USD 0.125（2 次） · 估算十进制 USD 0（0 次）包含当前库内所有 Session、用途、准入状态和结局；未关联 Run 的旧消息不计入。Run 的全部已记录 Attempt 消耗随 Run 归属，不是供应商按扣费日分摊的账单。持久 Run／Attempt 账目 · 计算 2026-10-11T02:53:51Z · 有效至 2026-10-11T03:08:51Z来源 e62bbed96a5c4ff99306ee2b24497fea · 价格 dac08245330a9d08fc698c0350119532b56e9fafc44788a93ea0ef7904514043 · 实例 7c1b8376e225404491d02625e2d5d110查看本期账目（按原期间重新读取）账本会创建新快照；新增记录或价格变化可能改变金额。"

```

```yaml
- region "期间指标":
  - heading "期间指标" [level=2]
  - text: 总览期间
  - combobox "总览期间":
    - option "今天"
    - option "最近七个自然日" [selected]
    - option "最近三十个自然日"
  - text: IANA 时区
  - textbox "IANA 时区": Asia/Shanghai
  - button "应用时区"
  - button "刷新期间指标" [disabled]
  - status: 正在刷新，保留原快照 · 有新运行事实，期间快照待刷新 · 来源观察：2026-10-11T02:53:51Z
  - article:
    - heading "运行记录数" [level=3]
    - paragraph: 1 条 Run 记录
  - article:
    - heading "模型费用" [level=3]
    - paragraph: 精确 USD 0.125
    - paragraph: 已记录 Attempt 2 次 · 费用未知 0 次
    - paragraph: 精确金额来自端点报告，未经外部账单核对。
    - paragraph: 模型账目完整
    - paragraph: 模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。
  - paragraph: 本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai
  - group: 本次期间与来源
  - link "查看本期账目（按原期间重新读取）":
    - /url: /ops?range=custom&timezone=Asia%2FShanghai&start=2026-10-05&end=2026-10-12
  - paragraph: 账本会创建新快照；新增记录或价格变化可能改变金额。
```

# Test source

```ts
  251 | 
  252 | test('Repeated Overview reads preserve another Ops snapshot and trace pruning keeps accounting', async ({page}) => {
  253 |   const server=await fixture();
  254 |   try {
  255 |     await server.send('runs 2');await server.send('retain-ops');
  256 |     await page.goto(server.origin+'/overview');
  257 |     const period=page.getByLabel('期间指标');
  258 |     await expect(period).toContainText('2 条 Run 记录');
  259 |     await server.send('prune');
  260 |     for(let i=0;i<9;i++) {
  261 |       await page.getByRole('button',{name:'刷新全部来源'}).click();
  262 |       await expect(page.getByRole('button',{name:'刷新期间指标'})).toBeEnabled();
  263 |       await expect(period).toContainText('精确 USD 0.25');
  264 |       await server.send('check-ops');
  265 |     }
  266 |     await expect(page.locator('.overview-run')).toHaveCount(2);
  267 |     await expect(page.getByLabel('全历史最近运行')).toContainText('已保存');
  268 |   } finally {await server.close();}
  269 | });
  270 | 
  271 | test('Source navigation records only identity and restores Overview after a real reread', async ({page}) => {
  272 |   const server=await fixture();
  273 |   let release=()=>{};
  274 |   try {
  275 |     await server.send('runs 1');await page.goto(server.origin+'/overview?range=30d&timezone=Asia%2FShanghai');
  276 |     const row=page.locator('.overview-run').first();await expect(row).toBeVisible();
  277 |     const id=await row.getAttribute('data-run-id');
  278 |     await page.locator('#new-session').click();const input=page.locator('#message');await input.fill('总览往返草稿');
  279 |     const selectedSession=await page.evaluate(()=>sessionStorage.getItem('alfred.session'));
  280 |     let streams=0,periodReads=0,recentReads=0,posts=0;
  281 |     page.on('request',r=>{if(r.url().includes('/api/events'))streams++;if(r.url().includes('/api/overview/period?'))periodReads++;if(r.url().includes('/api/overview/recent-runs?'))recentReads++;if(r.method()==='POST')posts++;});
  282 |     await page.evaluate(()=>{window.overviewSources=[];const push=history.pushState.bind(history);history.pushState=(value,...args)=>{window.overviewSources.push(value.alfredShell?.source);return push(value,...args);};});
  283 |     await row.getByRole('link').click();await expect(page).toHaveURL(/\/runs\//);
  284 |     await expect(page.getByRole('region',{name:'运行摘要',exact:true})).toContainText(id);
  285 |     await expect(page.getByRole('button',{name:'切换到此会话并在主对话中查看',exact:true})).toBeVisible();
  286 |     expect(await page.evaluate(()=>sessionStorage.getItem('alfred.session'))).toBe(selectedSession);
  287 |     await expect(input).toHaveValue('总览往返草稿');
  288 |     const source=await page.evaluate(()=>window.overviewSources.at(-1).returnSource);
  289 |     expect(source).toMatchObject({kind:'overview',anchor:id,range:'30d',timezone:'Asia/Shanghai'});
  290 |     expect(JSON.stringify(source)).not.toContain('总览往返草稿');
  291 |     // Exercise the migrated Run controller's opaque returnSource port.
  292 |     await page.getByRole('link',{name:'返回来源',exact:true}).click();
  293 |     await expect(page.getByLabel('期间指标')).toContainText('1 条 Run 记录');
  294 |     await expect(page.locator('.overview-run').getByRole('link')).toBeFocused();
  295 |     await expect(input).toHaveValue('总览往返草稿');
  296 |     expect(periodReads).toBe(1);expect(recentReads).toBe(1);expect(streams).toBe(0);expect(posts).toBe(0);
  297 |     expect(await page.evaluate(()=>sessionStorage.getItem('alfred.session'))).toBe(selectedSession);
  298 |     const architectureMemory=page.getByLabel('静态架构说明').getByRole('link',{name:'记忆',exact:true});
  299 |     await architectureMemory.click();await expect(page).toHaveURL(/\/memory(?:\?|$)/);
  300 |     expect(await page.evaluate(()=>window.overviewSources.at(-1).returnSource.section)).toBe('静态架构说明');
  301 |     await page.goBack();
  302 |     await expect(architectureMemory).toBeFocused();
  303 |     await expect(page.getByRole('link',{name:'查看当前记忆（重新读取）'})).not.toBeFocused();
  304 | 
  305 |     // A later real user intent retires the pending restore of a data-backed Run anchor.
  306 |     await row.getByRole('link').click();await expect(page).toHaveURL(/\/runs\//);
  307 |     let fetched;const received=new Promise(resolve=>fetched=resolve),gate=new Promise(resolve=>release=resolve);
  308 |     await page.route('**/api/overview/recent-runs?**',async route=>{const response=await route.fetch();fetched();await gate;await route.fulfill({response}).catch(()=>{});});
  309 |     await page.goBack();await received;
  310 |     await input.click();await input.fill('返回后继续输入');
  311 |     release();await expect(page.locator('.overview-run')).toHaveCount(1);
  312 |     await expect(input).toBeFocused();await expect(input).toHaveValue('返回后继续输入');expect(streams).toBe(0);
  313 |   } finally {release();await server.close();}
  314 | });
  315 | 
  316 | // Retain native EventSource and real Host events; only frame delivery is controlled.
  317 | async function observeStream(page) {
  318 |   await page.addInitScript(()=>{
  319 |     window.sources=[];
  320 |     const Native=window.EventSource;
  321 |     window.EventSource=class extends Native {
  322 |       constructor(url){super(url);window.sources.push(this);}
  323 |       addEventListener(kind,callback,options){
  324 |         super.addEventListener(kind,event=>{
  325 |           if(kind==='state_patch'){
  326 |             const body=JSON.parse(event.data);
  327 |             if(body.active_run?.recording_state==='pending')window.lastPending=body;
  328 |             if(window.holdIdle&&body.coordinator_state==='idle'){
  329 |               (window.heldIdle??=[]).push(()=>callback(event));return;
  330 |             }
  331 |           }
  332 |           callback(event);
  333 |         },options);
  334 |       }
  335 |     };
  336 |   });
  337 | }
  338 | 
  339 | test('Gap and disconnect retire slow real reads even after a same-instance reconnect', async ({page,context}) => {
  340 |   const server=await fixture();
  341 |   let release=()=>{};
  342 |   try {
  343 |     await observeStream(page);await server.send('runs 1');await page.goto(server.origin+'/overview');
  344 |     const period=page.getByLabel('期间指标');await expect(period).toContainText('1 条 Run 记录');
  345 |     for(const interruption of ['gap','disconnect']) {
  346 |       await server.send('runs 1');
  347 |       let fetched;const received=new Promise(resolve=>fetched=resolve),gate=new Promise(resolve=>release=resolve);
  348 |       await page.route('**/api/overview/period?**',async route=>{const response=await route.fetch();fetched();await gate;await route.fulfill({response}).catch(()=>{});});
  349 |       await page.getByRole('button',{name:'刷新期间指标'}).click();await received;
  350 |       if(interruption==='gap') {await emit(page,'transport_notice',{code:'deltas_dropped'});await expect(period).toContainText('事件有缺口');}
> 351 |       else {await context.setOffline(true);await expect(period).toContainText('离线副本');await context.setOffline(false);await expect(period).toContainText('连接已恢复');}
      |                                                                 ^ Error: expect(locator).toContainText(expected) failed
  352 |       release();await page.unroute('**/api/overview/period?**');
  353 |       await expect(period).toContainText('1 条 Run 记录');
  354 |       await expect(period).not.toContainText('2 条 Run 记录');
  355 |       await expect(period).not.toContainText('3 条 Run 记录');
  356 |     }
  357 |     await page.getByRole('button',{name:'刷新期间指标'}).click();
  358 |     await expect(period).toContainText('3 条 Run 记录');
  359 |   } finally {release();await context.setOffline(false);await server.close();}
  360 | });
  361 | 
  362 | test('Overview keeps opaque colliding identities and reference layouts readable', async ({page},testInfo) => {
  363 |   const server=await fixture();
  364 |   try {
  365 |     await server.send('runs 2');await server.send('opaque-runs');
  366 |     await page.emulateMedia({reducedMotion:'reduce'});await page.goto(server.origin+'/overview');
  367 |     await expect(page.locator('.overview-run')).toHaveCount(2);
  368 |     const ids=await page.locator('.overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId));
  369 |     expect(ids[0]).not.toBe(ids[1]);
  370 |     for(const row of await page.locator('.overview-run').all()) {
  371 |       const id=await row.getAttribute('data-run-id');
  372 |       await expect(row.getByRole('link')).toHaveText('Run '+id);
  373 |       await expect(row.getByRole('link')).toHaveAttribute('href','/runs/'+encodeURIComponent(id));
  374 |     }
  375 |     await expect(page.getByLabel('全历史最近运行')).toContainText('未知用途：future-purpose');
  376 |     for(const [width,height] of [[1440,900],[1280,800],[390,844],[320,800],[1099,900],[1100,900]]) {
  377 |       await page.setViewportSize({width,height});
  378 |       await expect(page.getByRole('heading',{name:'总览',exact:true})).toBeVisible();
  379 |       const geometry=await page.evaluate(()=>({body:document.body.scrollWidth,viewport:innerWidth,page:document.querySelector('#page').clientWidth,pageScroll:document.querySelector('#page').scrollWidth,animation:getComputedStyle(document.querySelector('.overview-diagram')).animationName}));
  380 |       expect(geometry.body).toBeLessThanOrEqual(geometry.viewport);expect(geometry.pageScroll).toBeLessThanOrEqual(geometry.page+1);expect(geometry.animation).toBe('none');
  381 |       await page.locator('#page').evaluate(node=>node.scrollTop=0);
  382 |       await page.screenshot({path:testInfo.outputPath(`overview-${width}.png`)});
  383 |       if([1440,1280,390,320].includes(width)){
  384 |         await page.getByRole('heading',{name:'静态架构说明',exact:true}).scrollIntoViewIfNeeded();await page.screenshot({path:testInfo.outputPath(`architecture-${width}.png`)});
  385 |         await page.getByRole('heading',{name:'全历史最近运行',exact:true}).scrollIntoViewIfNeeded();await page.screenshot({path:testInfo.outputPath(`recent-${width}.png`)});
  386 |       }
  387 |     }
  388 |     await page.setViewportSize({width:1440,height:900});
  389 |     for(const wanted of [679,680]) {
  390 |       const actual=await page.locator('.page-body').evaluate(node=>node.getBoundingClientRect().width);
  391 |       const previous=page.viewportSize();await page.setViewportSize({width:previous.width+wanted-actual,height:900});
  392 |       const widths=await page.locator('.overview-period-cards').evaluate(node=>({page:document.querySelector('.page-body').getBoundingClientRect().width,columns:getComputedStyle(node).gridTemplateColumns.split(' ').length}));
  393 |       expect(widths.page).toBe(wanted);expect(widths.columns).toBe(wanted===679?1:2);
  394 |     }
  395 |     await page.getByRole('button',{name:'刷新期间指标'}).focus();await expect(page.getByRole('button',{name:'刷新期间指标'})).toBeFocused();
  396 |   } finally {await server.close();}
  397 | });
  398 | 
  399 | 
  400 | test('A real recorded read merges into the held current slot without duplicate or old pending downgrade', async ({page}) => {
  401 |   const server=await fixture();
  402 |   let recentReads=0;page.on('request',request=>{if(request.url().includes('/api/overview/recent-runs?'))recentReads++;});
  403 |   try {
  404 |     await observeStream(page);await server.send('runs 5');
  405 |     await page.route('**/api/overview/recent-runs?**',route=>route.abort());
  406 |     await page.goto(server.origin+'/overview');
  407 |     await expect(page.getByLabel('全历史最近运行')).toContainText('读取失败');
  408 |     await expect(page.locator('.overview-run')).toHaveCount(0);
  409 |     const entry=await (await page.request.get(server.origin+'/api/entry')).json();const headers={'x-agent-alfred-csrf':entry.csrf_token};
  410 |     const session=await (await page.request.post(server.origin+'/api/sessions',{headers,data:{}})).json();
  411 |     await page.evaluate(()=>window.holdIdle=true);await server.send('hold-recording');
  412 |     const accepted=await (await page.request.post(server.origin+'/api/runs',{headers,data:{session_id:session.session_id,message:'held durable overlap'}})).json();
  413 |     await server.send('wait-recording');
  414 |     const current=page.getByLabel('当前运行槽');await expect(current).toContainText('正在保存');
  415 |     const currentHref='/runs/'+encodeURIComponent(accepted.run_id);
  416 |     await expect(current.getByRole('link')).toHaveAttribute('href',currentHref);
  417 |     await server.send('release-recording');
  418 |     await page.unroute('**/api/overview/recent-runs?**');
  419 |     await page.getByRole('button',{name:'刷新最近运行'}).click();await expect(current).toContainText('已保存');
  420 |     await expect(current.getByRole('link')).toHaveText('Run '+accepted.run_id.slice(0,12)+'…');
  421 |     // New peers must refresh the label even when current identity and recorded state stay unchanged.
  422 |     await server.send('collide-run '+accepted.run_id);
  423 |     const legacyId=accepted.run_id.slice(0,12)+'-legacy-history';
  424 |     await page.getByRole('button',{name:'刷新最近运行'}).click();
  425 |     await expect(page.locator('.overview-history .overview-run')).toHaveCount(5);
  426 |     const ids=await page.locator('.overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId));
  427 |     expect(new Set(ids).size).toBe(6);expect(ids.filter(id=>id===accepted.run_id)).toHaveLength(1);
  428 |     const legacy=page.locator('.overview-history .overview-run').filter({has:page.getByRole('link',{name:'Run '+legacyId,exact:true})});
  429 |     await expect(current.getByRole('link')).toHaveText('Run '+accepted.run_id);
  430 |     await expect(current.getByRole('link')).toHaveAttribute('href',currentHref);
  431 |     await expect(legacy.getByRole('link')).toHaveAttribute('href','/runs/'+encodeURIComponent(legacyId));
  432 |     expect(new Set(await page.locator('.overview-run>a').allTextContents()).size).toBe(6);
  433 |     const historicalIds=await page.locator('.overview-history .overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId));
  434 |     const readsBeforeRelease=recentReads;
  435 |     const old=await page.evaluate(()=>window.lastPending);expect(old).toBeTruthy();await emit(page,'state_patch',old);
  436 |     await expect(current).toContainText('已保存');await expect(current).not.toContainText('正在保存');
  437 |     await expect.poll(()=>page.evaluate(()=>window.heldIdle?.length||0)).toBeGreaterThan(0);
  438 |     await page.evaluate(()=>{window.holdIdle=false;for(const deliver of window.heldIdle.splice(0))deliver();});
  439 |     await expect(current.locator('.overview-run')).toHaveCount(0);
  440 |     await expect(page.locator('.overview-history .overview-run')).toHaveCount(5);
  441 |     expect(await page.locator('.overview-history .overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId))).toEqual(historicalIds);
  442 |     expect(recentReads).toBe(readsBeforeRelease);
  443 |     expect(historicalIds).not.toContain(accepted.run_id);
  444 |     await page.getByRole('button',{name:'刷新最近运行'}).click();
  445 |     await expect(page.locator('.overview-history .overview-run').first()).toHaveAttribute('data-run-id',accepted.run_id);
  446 |     expect(recentReads).toBe(readsBeforeRelease+1);
  447 |     const links=page.locator('.overview-history .overview-run>a');
  448 |     expect(new Set(await links.allTextContents()).size).toBe(5);
  449 |     await expect(links.first()).toHaveAttribute('href',currentHref);
  450 |   } finally {await server.send('release-recording');await server.close();}
  451 | });
```