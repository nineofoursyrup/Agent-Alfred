# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: models-migration.spec.js >> S08 unknown unpin unlocks fields only after a connected current read and keeps its receipt
- Location: tests/browser/models-migration.spec.js:278:1

# Error details

```
Error: Traceback (most recent call last):
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 598, in _bind
    server = OwnedResource.acquire(
        rollback,
    ...<6 lines>...
        close=close_bound,
    )
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/resource_rollback.py", line 414, in acquire
    initialize(owner)
    ~~~~~~~~~~^^^^^^^
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 847, in _initialize_bound_server
    factory(address, handler, owner)
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 882, in _default_server_factory
    _Server.__init__(server, address, handler)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/socketserver.py", line 457, in __init__
    self.server_bind()
    ~~~~~~~~~~~~~~~~^^
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/http/server.py", line 148, in server_bind
    socketserver.TCPServer.server_bind(self)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/lib/python3.14/socketserver.py", line 478, in server_bind
    self.socket.bind(self.server_address)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^
OSError: [Errno 48] Address already in use

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "/Users/nineofour/Agent-Alfred-v05/tests/browser/settings_server.py", line 125, in <module>
    main()
    ~~~~^^
  File "/Users/nineofour/Agent-Alfred-v05/tests/browser/settings_server.py", line 105, in main
    dashboard.start()
    ~~~~~~~~~~~~~~~^^
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/server.py", line 304, in start
    descriptor = self._start_locked()
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/server.py", line 373, in _start_locked
    descriptor = service.start(rollback_step_timeout=self._rollback_step_timeout)
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 570, in start
    rollback.raise_failure(exc)
    ~~~~~~~~~~~~~~~~~~~~~~^^^^^
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/resource_rollback.py", line 682, in raise_failure
    raise propagated
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 565, in start
    self._bind(rollback, release_server)
    ~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/nineofour/Agent-Alfred-v05/src/agent_alfred/gateway/web/lifecycle.py", line 609, in _bind
    raise PortUnavailable(
        DEFAULT_HOST, self._requested_port, _bind_error_reason(exc)
    ) from exc
agent_alfred.gateway.web.lifecycle.PortUnavailable: cannot bind 127.0.0.1:17928: address already in use; the port is never chosen automatically

```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import {spawn} from 'node:child_process';
  3   | import {createInterface} from 'node:readline';
  4   | import {once} from 'node:events';
  5   | 
  6   | async function server() {
  7   |   const child=spawn('.venv/bin/python',['tests/browser/settings_server.py']);
  8   |   const lines=createInterface({input:child.stdout});let errors='';child.stderr.on('data',d=>errors+=d);
> 9   |   const value=await Promise.race([once(lines,'line').then(([line])=>JSON.parse(line)),once(child,'exit').then(()=>{throw new Error(errors);})]);
      |                                                                                                                          ^ Error: Traceback (most recent call last):
  10  |   return {...value,async close(){const done=once(child,'exit');child.kill('SIGTERM');await done;lines.close();if(child.exitCode!==0)throw new Error(errors);}};
  11  | }
  12  | const selected=page=>page.locator("[data-model='opencode-go:deepseek-v4-flash']");
  13  | async function open(page, origin) {
  14  |   await page.goto(origin+'/models');
  15  |   await selected(page).getByText('模型详情',{exact:true}).click();
  16  | }
  17  | async function saved(page) {
  18  |   const data=await (await page.request.get('/api/models')).json();
  19  |   return data.endpoints.flatMap(group=>group.models).find(model=>model.endpoint_id==='opencode-go' && model.model_id==='deepseek-v4-flash');
  20  | }
  21  | 
  22  | for (const lost of [false,true])
  23  | test(`S11 model ${lost?'unknown':'pending'} save protects a successor equal to its old saved value`,async({browser})=>{
  24  |   const s=await server(),context=await browser.newContext({baseURL:s.origin});let release=()=>{};
  25  |   try{
  26  |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  27  |     const input=row.getByRole('textbox',{name:'显示名',exact:true}),save=row.getByRole('button',{name:'保存显示名',exact:true});
  28  |     await input.fill('A');await save.click();await expect(row.getByText('已确认保存',{exact:true})).toBeVisible();
  29  |     let received;const arrived=new Promise(resolve=>received=resolve),gate=new Promise(resolve=>release=resolve);const posts=[];
  30  |     await page.route('**/api/settings',async route=>{posts.push(route.request().postDataJSON());const response=await route.fetch();received();await gate;if(lost)await route.abort();else await route.fulfill({response});});
  31  |     await input.fill('B');await save.click();await arrived;
  32  |     if(lost){release();await expect(row.getByText('保存结果未确认。先核对当前值；不会自动重送。',{exact:true})).toBeVisible();}
  33  |     await input.fill('A');
  34  |     await page.locator('nav a[href="/overview"]').click();
  35  |     await expect(page.getByRole('button',{name:'留在此页',exact:true})).toBeFocused();
  36  |     await page.keyboard.press('Escape');await expect(input).toHaveValue('A');
  37  |     if(lost){await page.getByRole('button',{name:'核对当前模型设置',exact:true}).click();await expect(row.getByText('当前保存值：B',{exact:true})).toBeVisible();await expect(input).toHaveValue('A');}
  38  |     await input.fill('B'); // The submitted value itself is no unsaved successor.
  39  |     await page.locator('nav a[href="/overview"]').click();
  40  |     await expect(page).toHaveURL(/\/overview$/);await expect(page.getByRole('dialog')).toHaveCount(0);
  41  |     release();expect(posts.map(p=>[p.display_name,p.expected_revision])).toEqual([['B',1]]);
  42  |     expect((await saved(page)).display_name_override).toBe('B');
  43  |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  44  |   }finally{release();await context.close();await s.close();}
  45  | });
  46  | 
  47  | test('S08 real catalog label and explicit clearing survive HTTP read and page reentry',async({browser})=>{
  48  |   const s=await server(), context=await browser.newContext({baseURL:s.origin});
  49  |   try {
  50  |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  51  |     await expect(row.getByRole('heading',{name:'目录模型名称',exact:true})).toBeVisible();
  52  |     await expect(row.getByRole('textbox',{name:'显示名',exact:true})).toHaveValue('');
  53  |     const input=row.getByRole('textbox',{name:'显示名',exact:true});
  54  |     await input.fill('真实用户显示名');await row.getByRole('button',{name:'保存显示名',exact:true}).click();
  55  |     await expect.poll(async()=> (await saved(page)).display_name_override).toBe('真实用户显示名');
  56  |     await input.fill('');await row.getByRole('button',{name:'保存显示名',exact:true}).click();
  57  |     await expect.poll(async()=> (await saved(page)).display_name_override).toBeNull();
  58  |     await expect(row.getByRole('heading',{name:'目录模型名称',exact:true})).toBeVisible();
  59  |     const price=row.getByRole('textbox',{name:'output',exact:true});
  60  |     await price.fill('0');await row.getByRole('button',{name:'保存 output',exact:true}).click();
  61  |     await expect.poll(async()=> (await saved(page)).price_override?.output).toBe('0');
  62  |     await price.fill('');await row.getByRole('button',{name:'保存 output',exact:true}).click();
  63  |     await expect.poll(async()=> (await saved(page)).price_override).toBeNull();
  64  |     await page.locator('nav a[href="/connections"]').click();
  65  |     await page.locator('nav a[href="/models"]').click();
  66  |     await row.getByText('模型详情',{exact:true}).click();
  67  |     await expect(input).toHaveValue('');await expect(price).toHaveValue('');
  68  |     expect((await saved(page)).display_name).toBe('目录模型名称');
  69  |     expect((await (await fetch(s.control)).json()).model_calls).toHaveLength(0);
  70  |   }finally{await context.close();await s.close();}
  71  | });
  72  | 
  73  | test('S08 real two-tab conflict retains baseline and requires explicit adoption',async({browser})=>{
  74  |   const s=await server(), context=await browser.newContext({baseURL:s.origin});
  75  |   try {
  76  |     const a=await context.newPage(),b=await context.newPage();await open(a,s.origin);await open(b,s.origin);
  77  |     const first=selected(a),second=selected(b),draft=first.getByRole('textbox',{name:'显示名',exact:true});
  78  |     await draft.fill('原标签草稿');await second.getByRole('textbox',{name:'显示名',exact:true}).fill('另一标签已保存');
  79  |     await second.getByRole('button',{name:'保存显示名',exact:true}).click();
  80  |     await expect.poll(async()=> (await saved(b)).display_name_override).toBe('另一标签已保存');
  81  |     await first.getByRole('button',{name:'保存显示名',exact:true}).click();
  82  |     await expect(first.getByText(/stale_revision/)).toBeVisible();
  83  |     await expect(draft).toHaveValue('原标签草稿');
  84  |     await expect(first.getByText('当前保存值：另一标签已保存',{exact:true})).toBeVisible();
  85  |     await expect(first.getByRole('button',{name:'保存显示名',exact:true})).toBeDisabled();
  86  |     await first.getByRole('button',{name:'基于当前版本继续编辑',exact:true}).click();
  87  |     await first.getByRole('button',{name:'保存显示名',exact:true}).click();
  88  |     await expect.poll(async()=> (await saved(a)).display_name_override).toBe('原标签草稿');
  89  |   }finally{await context.close();await s.close();}
  90  | });
  91  | 
  92  | test('S08 SPEC F1 lost saved receipt requires a post-failure read before explicit adoption',async({browser})=>{
  93  |   const s=await server(),context=await browser.newContext({baseURL:s.origin});let release=()=>{};
  94  |   try {
  95  |     const page=await context.newPage();await open(page,s.origin);const row=selected(page);
  96  |     const input=row.getByRole('textbox',{name:'显示名',exact:true}),save=row.getByRole('button',{name:'保存显示名',exact:true});
  97  |     const adopt=row.getByRole('button',{name:'基于当前版本继续编辑',exact:true});
  98  |     const refresh=page.getByRole('button',{name:'核对当前模型设置',exact:true});
  99  |     await input.fill('A');await save.click();await expect(row.getByText('已确认保存',{exact:true})).toBeVisible();
  100 |     let received,held,got,mode='hold';const posts=[],reads=[];
  101 |     const barrier=()=>{received=new Promise(resolve=>got=resolve);held=new Promise(resolve=>release=resolve);};barrier();
  102 |     await page.route('**/api/models',async route=>{
  103 |       reads.push(mode);
  104 |       if(mode==='fail'){await route.abort();return;}
  105 |       const response=await route.fetch();got();await held;await route.fulfill({response}).catch(()=>{});
  106 |     });
  107 |     await page.route('**/api/settings',async route=>{
  108 |       const request=route.request().postDataJSON();const response=await route.fetch();posts.push({request,status:response.status()});
  109 |       if(request.display_name==='B')await route.abort();else await route.fulfill({response});
```