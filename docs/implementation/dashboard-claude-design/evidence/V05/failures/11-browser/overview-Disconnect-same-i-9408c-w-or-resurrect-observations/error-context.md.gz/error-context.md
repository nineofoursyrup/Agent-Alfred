# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overview.spec.js >> Disconnect, same-instance reconnect and restart cannot renew or resurrect observations
- Location: tests/browser/overview.spec.js:155:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByLabel('期间指标')
Expected substring: "离线副本"
Received string:    "期间指标总览期间今天最近七个自然日最近三十个自然日IANA 时区应用时区刷新期间指标来源观察：2026-10-11T02:53:40Z运行记录数1 条 Run 记录模型费用精确 USD 0.125已记录 Attempt 2 次 · 费用未知 0 次精确金额来自端点报告，未经外部账单核对。模型账目完整模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai本次期间与来源当地日期 [2026-10-05, 2026-10-12)（结束日期不含） · Asia/Shanghai确定时间 [2026-10-04T16:00:00+00:00, 2026-10-11T16:00:00+00:00)；先按 Run 开始时间，无开始时间时按受理时间归属。精确十进制 USD 0.125（2 次） · 估算十进制 USD 0（0 次）包含当前库内所有 Session、用途、准入状态和结局；未关联 Run 的旧消息不计入。Run 的全部已记录 Attempt 消耗随 Run 归属，不是供应商按扣费日分摊的账单。持久 Run／Attempt 账目 · 计算 2026-10-11T02:53:40Z · 有效至 2026-10-11T03:08:40Z来源 b72605a66f4e4503adad08aa3622175e · 价格 dac08245330a9d08fc698c0350119532b56e9fafc44788a93ea0ef7904514043 · 实例 1921b8f5f6454dd09d96246654e5710f查看本期账目（按原期间重新读取）账本会创建新快照；新增记录或价格变化可能改变金额。"
Timeout: 4000ms

Call log:
  - Expect "toContainText" getByLabel('期间指标') with timeout 4000ms
  - waiting for getByLabel('期间指标')
    12 × locator resolved to <section aria-label="期间指标" class="overview-period">…</section>
       - unexpected value "期间指标总览期间今天最近七个自然日最近三十个自然日IANA 时区应用时区刷新期间指标来源观察：2026-10-11T02:53:40Z运行记录数1 条 Run 记录模型费用精确 USD 0.125已记录 Attempt 2 次 · 费用未知 0 次精确金额来自端点报告，未经外部账单核对。模型账目完整模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai本次期间与来源当地日期 [2026-10-05, 2026-10-12)（结束日期不含） · Asia/Shanghai确定时间 [2026-10-04T16:00:00+00:00, 2026-10-11T16:00:00+00:00)；先按 Run 开始时间，无开始时间时按受理时间归属。精确十进制 USD 0.125（2 次） · 估算十进制 USD 0（0 次）包含当前库内所有 Session、用途、准入状态和结局；未关联 Run 的旧消息不计入。Run 的全部已记录 Attempt 消耗随 Run 归属，不是供应商按扣费日分摊的账单。持久 Run／Attempt 账目 · 计算 2026-10-11T02:53:40Z · 有效至 2026-10-11T03:08:40Z来源 b72605a66f4e4503adad08aa3622175e · 价格 dac08245330a9d08fc698c0350119532b56e9fafc44788a93ea0ef7904514043 · 实例 1921b8f5f6454dd09d96246654e5710f查看本期账目（按原期间重新读取）账本会创建新快照；新增记录或价格变化可能改变金额。"

```

```yaml
- region "期间指标":
  - heading "期间指标" [level=2]
  - text: 总览期间
  - combobox "总览期间":
    - option "今天"
    - option "最近七个自然日" [selected]
    - option "最近三十个自然日"
  - text: IANA 时区
  - textbox "IANA 时区": Asia/Shanghai
  - button "应用时区"
  - button "刷新期间指标"
  - status: 来源观察：2026-10-11T02:53:40Z
  - article:
    - heading "运行记录数" [level=3]
    - paragraph: 1 条 Run 记录
  - article:
    - heading "模型费用" [level=3]
    - paragraph: 精确 USD 0.125
    - paragraph: 已记录 Attempt 2 次 · 费用未知 0 次
    - paragraph: 精确金额来自端点报告，未经外部账单核对。
    - paragraph: 模型账目完整
    - paragraph: 模型 USD 分项不相加称总费用；工具计量另在用量账本按服务／单位查看。
  - paragraph: 本次当地日期 [2026-10-05, 2026-10-12) · Asia/Shanghai
  - group: 本次期间与来源
  - link "查看本期账目（按原期间重新读取）":
    - /url: /ops?range=custom&timezone=Asia%2FShanghai&start=2026-10-05&end=2026-10-12
  - paragraph: 账本会创建新快照；新增记录或价格变化可能改变金额。
```

# Test source

```ts
  64  |     await expect(page.getByLabel('结束日期（不含）')).toHaveValue('2026-03-09');
  65  |   } finally {await server.close();}
  66  | });
  67  | 
  68  | test('Unknown, proven zero, no consumption, tiny positive and damaged membership stay distinct', async ({page}) => {
  69  |   const server=await fixture();
  70  |   try {
  71  |     await server.send('mode unknown');await server.send('runs 1');
  72  |     await page.goto(server.origin+'/overview');
  73  |     const period=page.getByLabel('期间指标');
  74  |     await expect(period).toContainText('费用未知');
  75  |     await expect(period).not.toContainText('该范围零费用');
  76  |     await server.send('telemetry no-model');
  77  |     await page.getByRole('button',{name:'刷新期间指标',exact:true}).click();
  78  |     await expect(period).toContainText('该范围无模型消耗');
  79  |     await server.send('mode zero');await server.send('runs 1');
  80  |     await page.getByRole('button',{name:'刷新期间指标',exact:true}).click();
  81  |     await expect(period).toContainText('该范围零费用');
  82  |     await server.send('mode tiny');await server.send('runs 1');
  83  |     await page.getByRole('button',{name:'刷新期间指标',exact:true}).click();
  84  |     await expect(period).toContainText('精确 USD <0.0001');
  85  |     await period.getByText('本次期间与来源',{exact:true}).click();
  86  |     await expect(period).toContainText('0.000000001');
  87  |     await server.send('telemetry legacy-tool-gap');
  88  |     await page.getByRole('button',{name:'刷新期间指标',exact:true}).click();
  89  |     await expect(period).toContainText('其他账目覆盖不足');
  90  |     await expect(period).toContainText('模型账目完整');
  91  |     await server.send('telemetry bad-time');
  92  |     await page.getByRole('button',{name:'刷新期间指标',exact:true}).click();
  93  |     await expect(period).toContainText('已定位 0 条；另 3 条期间无法判定');
  94  |     await expect(period).not.toContainText('暂无运行记录');
  95  |     await expect(period).not.toContainText('该范围零费用');
  96  |     await server.send('telemetry interrupted');
  97  |     await page.getByRole('button',{name:'刷新最近运行'}).click();
  98  |     await expect(page.getByLabel('全历史最近运行')).toContainText('终态无法确认');
  99  |     await expect(page.getByLabel('全历史最近运行')).toContainText('记录状态未知');
  100 |     await expect(page.getByLabel('全历史最近运行')).not.toContainText('已保存');
  101 |   } finally {await server.close();}
  102 | });
  103 | 
  104 | test('Three sources fail independently, retire replaced ranges and allow local retries', async ({page}) => {
  105 |   const server=await fixture();
  106 |   let release;const gate=new Promise(resolve=>{release=resolve;});
  107 |   try {
  108 |     await server.send('runs 1');await server.send('memory 1');
  109 |     await page.route('**/api/overview/memory-counts?**',route=>route.abort());
  110 |     await page.goto(server.origin+'/overview');
  111 |     await expect(page.getByLabel('期间指标')).toContainText('1 条 Run 记录');
  112 |     await expect(page.getByLabel('当前记忆条目数')).toContainText('读取失败');
  113 |     await expect(page.locator('.overview-run')).toHaveCount(1);
  114 |     await page.unroute('**/api/overview/memory-counts?**');
  115 |     await page.getByRole('button',{name:'刷新记忆计数'}).click();
  116 |     await expect(page.getByLabel('当前记忆条目数')).toContainText('语义 1 条');
  117 |     await page.route('**/api/overview/period?**',async route=>{const response=await route.fetch();await gate;await route.fulfill({response}).catch(()=>{});});
  118 |     const requested=page.waitForRequest('**/api/overview/period?**');
  119 |     await page.getByRole('button',{name:'刷新期间指标'}).click();await requested;
  120 |     await page.getByLabel('总览期间').selectOption('today');
  121 |     await expect(page.getByLabel('期间指标')).not.toContainText('1 条 Run 记录');
  122 |     await expect(page.getByLabel('当前记忆条目数')).toContainText('语义 1 条');
  123 |     await page.unroute('**/api/overview/period?**');
  124 |     await page.getByLabel('总览期间').selectOption('30d');
  125 |     await expect(page.getByLabel('期间指标')).toContainText('1 条 Run 记录');
  126 |     const now=await page.getByLabel('期间指标').textContent();release();
  127 |     await expect(page.getByLabel('总览期间')).toHaveValue('30d');
  128 |     await expect(page.getByLabel('期间指标')).toHaveText(now);
  129 |   } finally {release();await server.close();}
  130 | });
  131 | 
  132 | test('Hidden Overview revokes a changed memory revision and rejects its delayed response', async ({page}) => {
  133 |   const server=await fixture();
  134 |   let release;const gate=new Promise(resolve=>{release=resolve;});
  135 |   let received;const fetched=new Promise(resolve=>{received=resolve;});
  136 |   try {
  137 |     await server.send('memory 1');await page.setViewportSize({width:390,height:844});
  138 |     await page.goto(server.origin+'/overview');
  139 |     const memory=page.getByLabel('当前记忆条目数');
  140 |     await expect(memory).toContainText('语义 1 条');
  141 |     await page.route('**/api/overview/memory-counts?**',async route=>{const response=await route.fetch();received();await gate;await route.fulfill({response}).catch(()=>{});});
  142 |     await page.getByRole('button',{name:'刷新记忆计数'}).click();await fetched;
  143 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();
  144 |     await server.send('memory 1');
  145 |     await expect(memory).toContainText('记忆修订已变化');
  146 |     await expect(memory).not.toContainText('语义 1 条');
  147 |     release();await page.goBack();
  148 |     await expect(memory).not.toContainText('语义 1 条');
  149 |     await page.unroute('**/api/overview/memory-counts?**');
  150 |     await page.getByRole('button',{name:'刷新记忆计数'}).click();
  151 |     await expect(memory).toContainText('语义 2 条');
  152 |   } finally {release();await server.close();}
  153 | });
  154 | 
  155 | test('Disconnect, same-instance reconnect and restart cannot renew or resurrect observations', async ({page,context}) => {
  156 |   const server=await fixture();
  157 |   try {
  158 |     await server.send('runs 1');await page.goto(server.origin+'/overview');
  159 |     const period=page.getByLabel('期间指标');
  160 |     await expect(period).toContainText('1 条 Run 记录');
  161 |     const observation=await period.locator('[role=status]').textContent();
  162 |     let requests=0;page.on('request',r=>{if(r.url().includes('/api/overview/'))requests++;});
  163 |     await context.setOffline(true);
> 164 |     await expect(period).toContainText('离线副本');
      |                          ^ Error: expect(locator).toContainText(expected) failed
  165 |     await context.setOffline(false);
  166 |     await expect(period).toContainText('连接已恢复，旧快照待刷新');
  167 |     expect(requests).toBe(0);
  168 |     await expect(period).toContainText(observation.replace('来源观察：',''));
  169 |     await server.restart();
  170 |     await expect(period).toContainText('实例已变化，请刷新');
  171 |     await expect(period).not.toContainText('1 条 Run 记录');
  172 |     expect(requests).toBe(0);
  173 |     await page.getByRole('button',{name:'刷新全部来源'}).click();
  174 |     await expect(period).toContainText('1 条 Run 记录');
  175 |   } finally {await context.setOffline(false);await server.close();}
  176 | });
  177 | 
  178 | test('Original observation expires despite a failed refresh and layout changes; earlier source expiry wins', async ({page}) => {
  179 |   const server=await fixture();
  180 |   try {
  181 |     await server.send('runs 1');await page.clock.install();await page.goto(server.origin+'/overview');
  182 |     const period=page.getByLabel('期间指标');
  183 |     await expect(period).toContainText('1 条 Run 记录');
  184 |     const before=await period.locator('[role=status]').textContent();
  185 |     await page.clock.fastForward(14*60000);
  186 |     await page.route('**/api/overview/period?**',route=>route.abort());
  187 |     await page.getByRole('button',{name:'刷新期间指标'}).click();
  188 |     await expect(period).toContainText('读取失败');
  189 |     await page.setViewportSize({width:390,height:844});
  190 |     await page.locator('#shell-toolbar [data-open-panel="mainbar"]').click();await page.goBack();
  191 |     await page.clock.fastForward(61000);
  192 |     await expect(period).toContainText('已过期');
  193 |     await expect(period).toContainText(before.replace('来源观察：',''));
  194 |     await page.unroute('**/api/overview/period?**');
  195 |     await page.clock.setSystemTime(new Date());
  196 |     await server.send('short-ttl');
  197 |     await page.getByRole('button',{name:'刷新期间指标'}).click();
  198 |     await expect(period).not.toContainText('已过期');
  199 |     await page.clock.fastForward(2100);
  200 |     await expect(period).toContainText('已过期');
  201 |   } finally {await server.close();}
  202 | });
  203 | 
  204 | test('Current saving Run shares one slot; ordinary completion only prompts a manual history refresh', async ({page}) => {
  205 |   const server=await fixture();
  206 |   try {
  207 |     await server.send('runs 6');await page.goto(server.origin+'/overview');
  208 |     await expect(page.locator('.overview-run')).toHaveCount(5);
  209 |     const ids=await page.locator('.overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId));
  210 |     const entry=await (await page.request.get(server.origin+'/api/entry')).json();
  211 |     const headers={'x-agent-alfred-csrf':entry.csrf_token};
  212 |     const created=await page.request.post(server.origin+'/api/sessions',{headers,data:{}});
  213 |     const session=await created.json();expect(created.status(),JSON.stringify(session)).toBe(201);
  214 |     await server.send('hold-recording');
  215 |     const sent=await page.request.post(server.origin+'/api/runs',{headers,data:{session_id:session.session_id,message:'held offline Run'}});
  216 |     const accepted=await sent.json();expect(sent.status(),JSON.stringify(accepted)).toBe(202);
  217 |     await server.send('wait-recording');
  218 |     const current=page.getByLabel('当前运行槽');
  219 |     await expect(current).toContainText('正在保存');
  220 |     await expect(current).toContainText('已完成');
  221 |     await expect(current.locator('.overview-run')).toHaveAttribute('data-run-id',accepted.run_id);
  222 |     expect(await page.locator('.overview-history .overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId))).toEqual(ids);
  223 |     await server.send('release-recording');
  224 |     await expect(current.locator('.overview-run')).toHaveCount(0);
  225 |     await expect(page.getByLabel('全历史最近运行')).toContainText('有新运行，刷新查看');
  226 |     expect(await page.locator('.overview-history .overview-run').evaluateAll(rows=>rows.map(row=>row.dataset.runId))).toEqual(ids);
  227 |     await page.getByRole('button',{name:'刷新最近运行'}).click();
  228 |     await expect(page.locator('.overview-history .overview-run').first()).toHaveAttribute('data-run-id',accepted.run_id);
  229 |     await expect(page.locator('.overview-history .overview-run')).toHaveCount(5);
  230 |     expect(await page.evaluate(()=>sessionStorage.getItem('alfred.session'))).toBeNull();
  231 |   } finally {await server.send('release-recording');await server.close();}
  232 | });
  233 | 
  234 | test('Invalid range and IANA timezone expose correction without blocking other sources', async ({page}) => {
  235 |   const server=await fixture();
  236 |   try {
  237 |     await server.send('runs 1');
  238 |     await page.goto(server.origin+'/overview?range=custom&timezone=Not_A_Zone');
  239 |     const period=page.getByLabel('期间指标');
  240 |     await expect(period).toContainText('期间不可用');
  241 |     await expect(page.locator('.overview-run')).toHaveCount(1);
  242 |     await page.getByLabel('总览期间').selectOption('today');
  243 |     await expect(period).toContainText('有效的 IANA 时区');
  244 |     await expect(period.getByRole('link',{name:'查看本期账目（按原期间重新读取）'})).toHaveCount(0);
  245 |     await page.getByLabel('IANA 时区', {exact:true}).fill('Asia/Shanghai');
  246 |     await page.getByRole('button',{name:'应用时区'}).click();
  247 |     await expect(period).toContainText('1 条 Run 记录');
  248 |     expect(new URL(page.url()).searchParams.get('timezone')).toBe('Asia/Shanghai');
  249 |   } finally {await server.close();}
  250 | });
  251 | 
  252 | test('Repeated Overview reads preserve another Ops snapshot and trace pruning keeps accounting', async ({page}) => {
  253 |   const server=await fixture();
  254 |   try {
  255 |     await server.send('runs 2');await server.send('retain-ops');
  256 |     await page.goto(server.origin+'/overview');
  257 |     const period=page.getByLabel('期间指标');
  258 |     await expect(period).toContainText('2 条 Run 记录');
  259 |     await server.send('prune');
  260 |     for(let i=0;i<9;i++) {
  261 |       await page.getByRole('button',{name:'刷新全部来源'}).click();
  262 |       await expect(page.getByRole('button',{name:'刷新期间指标'})).toBeEnabled();
  263 |       await expect(period).toContainText('精确 USD 0.25');
  264 |       await server.send('check-ops');
```