# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: models-migration.spec.js >> S08 saved model probe preserves drafts and links its real Attempt and cost
- Location: tests/browser/models-migration.spec.js:192:1

# Error details

```
Test timeout of 15000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner "导航面板" [ref=e2]:
    - link "Agent-Alfred 本地助手" [ref=e3] [cursor=pointer]:
      - /url: /overview
      - text: Agent-Alfred
      - generic [ref=e4]: 本地助手
    - navigation "主导航"
    - paragraph [ref=e5]: 本地优先 · 共享运行宿主
  - generic [ref=e6]:
    - generic "壳层状态与操作" [ref=e7]:
      - button "打开主对话" [ref=e8] [cursor=pointer]
      - region "运行与连接摘要"
    - main [ref=e9]:
      - heading "正在同步 Dashboard…" [level=1] [ref=e10]
  - region "MainBar" [ref=e11]:
    - generic [ref=e12]:
      - heading "主对话" [level=2] [ref=e13]
      - button "收起主对话" [ref=e14] [cursor=pointer]
    - generic [ref=e15]:
      - generic [ref=e16]: 尚未选择会话
      - button "新建会话" [disabled] [ref=e17]
    - region "主对话" [ref=e18]
    - generic [ref=e19]:
      - generic [ref=e20]: 消息
      - textbox "消息" [disabled] [ref=e21]:
        - /placeholder: 写下消息；/skills 指定流程…
      - button "发送" [disabled] [ref=e22]
    - paragraph
  - status [ref=e23]
  - alert [ref=e24]
```